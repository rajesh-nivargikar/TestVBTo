'Option Strict Off
'Option Explicit On

Imports System.Data.OleDb
Imports ADODB
Imports VBto

Public Module modConnection


	'=========================================================

    Public CurrentConnection As New VBtoConnection()
    Public rs As New VBtoRecordSet()
    Public rs2 As New VBtoRecordSet()

    Public Sub OpenConnection()
        CurrentConnection = New VBtoConnection()
        CurrentConnection.ConnectionString = ConnectionString : CurrentConnection.Open()
    End Sub

    Public Sub ExecuteSql(ByVal Statement As String)
        rs = New VBtoRecordSet()
        rs.Open(Statement, CurrentConnection) '- , ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockPessimistic
    End Sub

    Public Sub ExecuteSql2(ByVal Statement As String)
        rs2 = New VBtoRecordSet()
        rs2.Open(Statement, CurrentConnection) '- , ADODB.CursorTypeEnum.adOpenKeyset, ADODB.LockTypeEnum.adLockPessimistic
    End Sub






End Module