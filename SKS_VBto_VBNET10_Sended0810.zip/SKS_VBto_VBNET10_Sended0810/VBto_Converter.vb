' This is a part of the VBto Converter (www.vbto.net). Copyright (C) 2005-2018 StressSoft Company Ltd. All rights reserved.

Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Module VBto_Converter

    Public Function vbFormat(ByVal Expression As Object, ByVal Style As String) As String
        Return Compatibility.VB6.Format(Expression, Style)
    End Function

    Public Sub SubItemsSetText(ByVal itm As ListViewItem, ByVal SubItemIndex As Integer, ByVal SubItemText As String)
        ' UPGRADE_WARNING: Lower bound of collection ListViewItem has changed from 1 to 0
        ' Click for more: 'ms-help://MS.VSCC.v80/dv_commoner/local/redirect.htm?keyword="A3B628A0-A810-4AE2-BFA2-9E7A29EB9AD0"'
        Dim nAdd As Integer = SubItemIndex - itm.SubItems.Count
        If nAdd >= 0 Then
            While nAdd > 0
                nAdd = nAdd - 1
                itm.SubItems.Add("")
            End While
            itm.SubItems.Add(SubItemText)
        Else
            itm.SubItems(SubItemIndex).Text = SubItemText
        End If
    End Sub

    Public Function IsEmpty(ByVal obj As Object) As Boolean
        Return obj Is Nothing
    End Function

    Public Sub ShowAsMdiChild(ByVal pMdiChild As Form, ByVal pMdiParent As Form)
        pMdiChild.MdiParent = pMdiParent
        pMdiChild.Show()
        pMdiChild.BringToFront()
    End Sub
    Public Function FindMDIContainer() As Form
        For Each f As Form In Application.OpenForms
            If f.IsMdiContainer Then Return f
        Next
        Return Nothing
    End Function
    Dim pMdiParent As Form = Nothing
    Public Sub ShowAsMdiChild(ByVal pMdiChild As Form)
        If pMdiParent Is Nothing Then
            pMdiParent = FindMDIContainer()
        End If
        If pMdiParent IsNot Nothing Then
            ShowAsMdiChild(pMdiChild, pMdiParent)
        Else
            pMdiChild.Show()	'?
        End If
    End Sub

End Module	' VBto_Converter
