'Option Strict Off
'Option Explicit On

Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Module modFunctions


	'=========================================================

    Public Sub AppendAND(ByRef filter As String)
        If filter<>Nothing Then
            filter &= " AND "
        End If
    End Sub

    Public Function AddToCollection(ByVal col As Collection, ByVal Item As String) As Boolean
        AddToCollection = False
        If  Not Exists(col, Item) Then
            col.Add(Item, Item)
            AddToCollection = True
        End If
    End Function

    Public Function Exists(ByVal col As Collection, ByVal Index As String) As Boolean
        ' VBto upgrade warning: o As Object	OnWrite(CollectionItem)
        Dim o As Object = Nothing
        Try ' On Error GoTo Error
            o = col.Item(Index)
        Catch	' mError:
            ' ...
        End Try
        Exists = o<>Nothing
    End Function


    ' VBto upgrade warning: 'Return' As Variant --> As Double	OnWrite(Double, Short)
    Public Function DoubleValue(ByVal strValue As String) As Double
        If Len(strValue)<>0 Then
            DoubleValue = CDbl(strValue)
        Else
            DoubleValue = 0
        End If
    End Function

    ' VBto upgrade warning: parentForm As Form	OnWrite(frmOrderRequest, frmOrderReception)
    ' VBto upgrade warning: 'Return' As Variant --> As Boolean
    Public Function ValidateTextBoxDouble(ByVal txBox As TextBox, ByVal parentForm As Form) As Boolean
        Try ' On Error GoTo err
            DoubleValue(txBox.Text)
            ValidateTextBoxDouble = True
            Exit Function
        Catch	' err:
            ' ...
        End Try
        modMain.LogStatus("The value inserted is not valid", parentForm)
        txBox.Text = ""
        txBox.Focus()
        ValidateTextBoxDouble = False
    End Function

    ' VBto upgrade warning: parentForm As Form	OnWrite(frmOrderRequest, frmOrderReception)
    ' VBto upgrade warning: 'Return' As Variant --> As Boolean
    Public Function ValidateTextDouble(ByVal text As String, ByVal parentForm As Form) As Boolean
        Try ' On Error GoTo err
            DoubleValue(text)
            ValidateTextDouble = True
            Exit Function
        Catch	' err:
            ' ...
        End Try
        modMain.LogStatus("The value inserted is not valid", parentForm)
        ValidateTextDouble = False
    End Function

    Public Sub SelectAll(ByVal txtBox As TextBox)
        txtBox.SelectionStart = 0
        txtBox.SelectionLength = Len(txtBox)
    End Sub

'#Const defUse_UpCase = True
#If defUse_UpCase Then
    ' VBto upgrade warning: 'Return' As Variant --> As Integer
    Public Function UpCase(ByVal KeyAscii As Short) As Integer
        UpCase = Asc(UCase(Convert.ToString(Chr(KeyAscii))))
    End Function
#End If


    ' '''''''''''''''''''''''''''''''''
    ' '' Combobox related functions '''
    ' '''''''''''''''''''''''''''''''''

    Public Sub LoadCombo(ByVal Table As String, ByVal combo As ComboBox, ByVal field As String, Optional ByVal valueField As String = "")
        ExecuteSql("Select * From " & Table)
        combo.Items.Clear()
        If (valueField<>Nothing) Then
            While  Not rs.EOF
                combo.Items.Add(Convert.ToString(rs.Fields(field).Value))
                VB6.SetItemData(combo, (combo.Items.Count-1), rs.Fields(valueField).Value)
                rs.MoveNext()
            End While
        Else
            While  Not rs.EOF
                combo.Items.Add(Convert.ToString(rs.Fields(field).Value))
                rs.MoveNext()
            End While
        End If
        'If strDefault <> Empty Then
        ' combo = strDefault
        'End If
    End Sub


    Public Function ComboEmpty(ByVal combo As ComboBox, Optional ByVal strip As Object = Nothing, Optional ByVal Index As Short = 0) As Boolean
        If combo.SelectedIndex=-1 Then
            ComboEmpty = True
            MsgBox("Please select an option from the list", MsgBoxStyle.Exclamation)
            If Index<>Nothing Then
                'strip.SelectedItem = strip.Tabs(Index)
            End If
            combo.Focus()
        Else
            ComboEmpty = False
        End If
    End Function

    Public Function NoRecords(ByVal lstView As ListView, Optional ByVal Prompt As String = "") As Boolean
        If lstView.Items.Count=0 Or lstView.FocusedItem Is Nothing Then
            If Prompt<>Nothing Then
                MsgBox(Prompt, MsgBoxStyle.Exclamation)
            End If
            NoRecords = True
        Else
            NoRecords = False
        End If
    End Function

'#Const defUse_RcrdId = True
#If defUse_RcrdId Then
    ' VBto upgrade warning: 'Return' As String	OnWrite(String, Short)
    Public Function RcrdId(ByVal Table As String, Optional ByVal Identifier As String = "", Optional ByVal FldNo As String = "") As String
        Dim RcrdNo As Short
        ExecuteSql("Select * from " & Table & " order by " & FldNo & " ASC")
        If rs.EOF=False Then
            rs.MoveLast()
            RcrdNo = rs.Fields(FldNo).Value+1
        Else
            RcrdNo = 1
        End If
        If Identifier<>Nothing Then
            RcrdId = Identifier & RcrdNo & vbFormat(Today, "mm")
        Else
            RcrdId = RcrdNo
        End If
    End Function
#End If



    ' ''''''''''''''''''''''''''''''''''''''''
    Public Sub SearchShow(ByVal Table As String, ByVal fieldToSearch As String, ByVal itemToSearch As String)
        With frmSearch
            .Search(Table, fieldToSearch, itemToSearch)
            .ShowDialog()
        End With
    End Sub

'#Const defUse_ValBox = True
#If defUse_ValBox Then
    Public Function ValBox(ByVal Prompt As String, ByVal Icon As PictureBox, Optional ByVal Title As String = "", Optional ByVal mDefault As Double = 0, Optional ByVal Header As String = "Value Box") As Double
        'With frmValue
        '    If Title <> Empty Then
        '       .Caption = Title
        '    Else
        '        .Caption = App.Title
        '    End If
        '    .lblHeader.Caption = StrConv(Header, vbUpperCase)
        '    .imgIcon.Picture = Icon.Picture
        '    .lblPrompt.Caption = Prompt
        '    .Default Val(Default)
        '    .Show vbModal
        '    ValBox = Val(.txtValue.Text)
        '    Unload frmValue
        'End With
    End Function
#End If


    Public Function TextBoxEmpty(ByVal stext As TextBox, Optional ByVal TabObject As Object = Nothing, Optional ByVal TabIndex As Short = 0) As Boolean
        If Trim(stext.Text)=Nothing Or stext.Text="  /  /    " Then
            TextBoxEmpty = True
            MsgBox("You need to fill in all required fields", MsgBoxStyle.Exclamation)
            If TabIndex<>Nothing Then
                'TabObject.SelectedItem = TabObject.Tabs(TabIndex)
            End If
            stext.Focus()
        Else
            TextBoxEmpty = False
        End If
    End Function

'#Const defUse_TextBoxNumberEmpty = True
#If defUse_TextBoxNumberEmpty Then
    Public Function TextBoxNumberEmpty(ByVal textbox As TextBox) As Boolean
        'if the input is not a numeric then true
        If IsNumeric(textbox.Text)=False Then
            TextBoxNumberEmpty = True
            MsgBox("The field requires a numeric value.", MsgBoxStyle.Exclamation)
            textbox.Focus()
            SelectAll(textbox)
        Else
            TextBoxNumberEmpty = False
        End If
    End Function
#End If



'#Const defUse_SaveDetection = True
#If defUse_SaveDetection Then
    Private Sub SaveDetection(ByVal Reference As String, ByVal Title As String, ByVal Description As String, ByVal Table As String)
        ExecuteSql2("Select * from " & Table)
        rs2.AddNew()
        rs2.Fields("record_no").Value = Val(RcrdId(Table, , "record_no"))
        rs2.Fields("Reference").Value = Reference
        rs2.Fields("war_type").Value = Title
        rs2.Fields("Description").Value = Description
        rs2.Update()
    End Sub
#End If



'#Const defUse_ExecErr = True
#If defUse_ExecErr Then
    Public Function ExecErr(ByVal Prompt As String, Optional ByVal PromptFld As String = "", Optional ByVal Table As String = "", Optional ByVal RcrdFld As String = "", Optional ByVal RcrdStr As String = "") As String
        Dim Rcrds As String = ""
        If Table<>Nothing Then
            ExecuteSql("Select * from " & Table & " where " & RcrdFld & " = '" & RcrdStr & "'")
            While  Not rs.EOF
                Rcrds &= Convert.ToString(rs.Fields(PromptFld).Value) & "; "
                rs.MoveNext()
            End While
            ExecErr = "Error: " & Prompt & vbNewLine & vbNewLine & "Related Records: " & Rcrds
        Else
            ExecErr = Prompt
        End If
    End Function
#End If


End Module