
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility.VB6

Public Class frmOrderReception
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalTax As System.Windows.Forms.TextBox
    Friend WithEvents txtFreightCharge As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesTax As System.Windows.Forms.TextBox
    Friend WithEvents txtEntry As System.Windows.Forms.TextBox
    Friend WithEvents fgProducts As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdAddProducts As System.Windows.Forms.Button
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtProviderName As System.Windows.Forms.TextBox
    Friend WithEvents txtContactLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtContactName As System.Windows.Forms.TextBox
    Friend WithEvents cmdProviders As System.Windows.Forms.Button
    Friend WithEvents lvProviders As System.Windows.Forms.ListView
    Friend WithEvents lvProvidersColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProvidersColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProvidersColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProvidersColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProvidersColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProvidersColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProvidersColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Frame2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtProviderContact As System.Windows.Forms.TextBox
    Friend WithEvents txtProviderCompany As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmOrderReception))
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.txtSubTotal = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtTotalTax = New System.Windows.Forms.TextBox()
        Me.txtFreightCharge = New System.Windows.Forms.TextBox()
        Me.txtSalesTax = New System.Windows.Forms.TextBox()
        Me.txtEntry = New System.Windows.Forms.TextBox()
        Me.fgProducts = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdAddProducts = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtProviderName = New System.Windows.Forms.TextBox()
        Me.txtContactLastName = New System.Windows.Forms.TextBox()
        Me.txtContactName = New System.Windows.Forms.TextBox()
        Me.cmdProviders = New System.Windows.Forms.Button()
        Me.lvProviders = New System.Windows.Forms.ListView()
        Me.lvProvidersColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvProvidersColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvProvidersColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvProvidersColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lvProvidersColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.lvProvidersColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.lvProvidersColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.txtProviderContact = New System.Windows.Forms.TextBox()
        Me.txtProviderCompany = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.fgProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtNotes
        '
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.TabIndex = 4
        Me.txtNotes.Location = New System.Drawing.Point(57, 324)
        Me.txtNotes.Size = New System.Drawing.Size(430, 44)
        Me.txtNotes.Text = ""
        Me.txtNotes.BackColor = System.Drawing.SystemColors.Window
        Me.txtNotes.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNotes.Multiline = True
        '
        'txtSubTotal
        '
        Me.txtSubTotal.Name = "txtSubTotal"
        Me.txtSubTotal.TabStop = False
        Me.txtSubTotal.TabIndex = 30
        Me.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSubTotal.Location = New System.Drawing.Point(356, 607)
        Me.txtSubTotal.Size = New System.Drawing.Size(147, 20)
        Me.txtSubTotal.Text = ""
        Me.txtSubTotal.BackColor = System.Drawing.SystemColors.Menu
        Me.txtSubTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSubTotal.ReadOnly = True
        '
        'txtTotal
        '
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.TabStop = False
        Me.txtTotal.TabIndex = 28
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotal.Location = New System.Drawing.Point(97, 631)
        Me.txtTotal.Size = New System.Drawing.Size(147, 20)
        Me.txtTotal.Text = ""
        Me.txtTotal.BackColor = System.Drawing.SystemColors.Menu
        Me.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotal.ReadOnly = True
        '
        'txtTotalTax
        '
        Me.txtTotalTax.Name = "txtTotalTax"
        Me.txtTotalTax.TabStop = False
        Me.txtTotalTax.TabIndex = 26
        Me.txtTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotalTax.Location = New System.Drawing.Point(356, 582)
        Me.txtTotalTax.Size = New System.Drawing.Size(147, 20)
        Me.txtTotalTax.Text = ""
        Me.txtTotalTax.BackColor = System.Drawing.SystemColors.Menu
        Me.txtTotalTax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotalTax.ReadOnly = True
        '
        'txtFreightCharge
        '
        Me.txtFreightCharge.Name = "txtFreightCharge"
        Me.txtFreightCharge.TabIndex = 7
        Me.txtFreightCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtFreightCharge.Location = New System.Drawing.Point(97, 607)
        Me.txtFreightCharge.Size = New System.Drawing.Size(147, 20)
        Me.txtFreightCharge.Text = ""
        Me.txtFreightCharge.BackColor = System.Drawing.SystemColors.Window
        Me.txtFreightCharge.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtSalesTax
        '
        Me.txtSalesTax.Name = "txtSalesTax"
        Me.txtSalesTax.TabIndex = 6
        Me.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSalesTax.Location = New System.Drawing.Point(97, 582)
        Me.txtSalesTax.Size = New System.Drawing.Size(147, 20)
        Me.txtSalesTax.Text = ""
        Me.txtSalesTax.BackColor = System.Drawing.SystemColors.Window
        Me.txtSalesTax.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtEntry
        '
        Me.txtEntry.Name = "txtEntry"
        Me.txtEntry.Visible = False
        Me.txtEntry.TabIndex = 23
        Me.txtEntry.Location = New System.Drawing.Point(97, 558)
        Me.txtEntry.Size = New System.Drawing.Size(147, 19)
        Me.txtEntry.Text = ""
        Me.txtEntry.BackColor = System.Drawing.SystemColors.Window
        Me.txtEntry.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'fgProducts
        '
        Me.fgProducts.Name = "fgProducts"
        Me.fgProducts.TabIndex = 5
        Me.fgProducts.Location = New System.Drawing.Point(8, 380)
        Me.fgProducts.Size = New System.Drawing.Size(511, 171)
        Me.fgProducts.OcxState = CType(resources.GetObject("fgProducts.OcxState"), System.Windows.Forms.AxHost.State)
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 22
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 686)
        Me.sbStatusBar.Size = New System.Drawing.Size(527, 25)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 525
        '
        'cmdSave
        '
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 8
        Me.cmdSave.Location = New System.Drawing.Point(324, 655)
        Me.cmdSave.Size = New System.Drawing.Size(90, 25)
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 9
        Me.cmdClose.Location = New System.Drawing.Point(429, 655)
        Me.cmdClose.Size = New System.Drawing.Size(90, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdAddProducts
        '
        Me.cmdAddProducts.Name = "cmdAddProducts"
        Me.cmdAddProducts.TabStop = False
        Me.cmdAddProducts.TabIndex = 20
        Me.cmdAddProducts.Location = New System.Drawing.Point(493, 348)
        Me.cmdAddProducts.Size = New System.Drawing.Size(25, 23)
        Me.cmdAddProducts.Text = "..."
        Me.cmdAddProducts.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddProducts.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtProviderName, Me.txtContactLastName, Me.txtContactName, Me.cmdProviders, Me.lvProviders, Me.Label3, Me.Label4, Me.Label2})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 11
        Me.Frame1.Location = New System.Drawing.Point(8, 8)
        Me.Frame1.Size = New System.Drawing.Size(511, 252)
        Me.Frame1.Text = "Search supplier"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtProviderName
        '
        Me.txtProviderName.Name = "txtProviderName"
        Me.txtProviderName.TabIndex = 0
        Me.txtProviderName.Location = New System.Drawing.Point(89, 16)
        Me.txtProviderName.Size = New System.Drawing.Size(147, 20)
        Me.txtProviderName.Text = ""
        Me.txtProviderName.BackColor = System.Drawing.SystemColors.Window
        Me.txtProviderName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtContactLastName
        '
        Me.txtContactLastName.Name = "txtContactLastName"
        Me.txtContactLastName.TabIndex = 2
        Me.txtContactLastName.Location = New System.Drawing.Point(340, 49)
        Me.txtContactLastName.Size = New System.Drawing.Size(147, 20)
        Me.txtContactLastName.Text = ""
        Me.txtContactLastName.BackColor = System.Drawing.SystemColors.Window
        Me.txtContactLastName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtContactName
        '
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.TabIndex = 1
        Me.txtContactName.Location = New System.Drawing.Point(89, 49)
        Me.txtContactName.Size = New System.Drawing.Size(147, 20)
        Me.txtContactName.Text = ""
        Me.txtContactName.BackColor = System.Drawing.SystemColors.Window
        Me.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmdProviders
        '
        Me.cmdProviders.Name = "cmdProviders"
        Me.cmdProviders.TabStop = False
        Me.cmdProviders.TabIndex = 12
        Me.cmdProviders.Location = New System.Drawing.Point(461, 16)
        Me.cmdProviders.Size = New System.Drawing.Size(25, 23)
        Me.cmdProviders.Text = "..."
        Me.cmdProviders.BackColor = System.Drawing.SystemColors.Control
        Me.cmdProviders.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lvProviders
        '
        Me.lvProviders.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvProvidersColumnHeader0, Me.lvProvidersColumnHeader1, Me.lvProvidersColumnHeader2, Me.lvProvidersColumnHeader3, Me.lvProvidersColumnHeader4, Me.lvProvidersColumnHeader5, Me.lvProvidersColumnHeader6})
        Me.lvProviders.Name = "lvProviders"
        Me.lvProviders.TabIndex = 3
        Me.lvProviders.Location = New System.Drawing.Point(8, 81)
        Me.lvProviders.Size = New System.Drawing.Size(494, 163)
        Me.lvProviders.BackColor = System.Drawing.SystemColors.Window
        Me.lvProviders.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvProviders.View = System.Windows.Forms.View.Details
        Me.lvProviders.MultiSelect = False
        Me.lvProviders.GridLines = True
        Me.lvProviders.FullRowSelect = True
        Me.lvProviders.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvProviders.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvProvidersColumnHeader0.Text = "Supplier ID"
        Me.lvProvidersColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvProvidersColumnHeader1.Text = "Supplier Name"
        Me.lvProvidersColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvProvidersColumnHeader2.Text = "Contact Name"
        Me.lvProvidersColumnHeader2.Width = 98
        '
        'ColumnHeader(4)
        '
        Me.lvProvidersColumnHeader3.Text = "Contact Last Name"
        Me.lvProvidersColumnHeader3.Width = 98
        '
        'ColumnHeader(5)
        '
        Me.lvProvidersColumnHeader4.Text = "City"
        Me.lvProvidersColumnHeader4.Width = 98
        '
        'ColumnHeader(6)
        '
        Me.lvProvidersColumnHeader5.Text = "State"
        Me.lvProvidersColumnHeader5.Width = 98
        '
        'ColumnHeader(7)
        '
        Me.lvProvidersColumnHeader6.Text = "Country"
        Me.lvProvidersColumnHeader6.Width = 98
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 15
        Me.Label3.Location = New System.Drawing.Point(243, 49)
        Me.Label3.Size = New System.Drawing.Size(98, 17)
        Me.Label3.Text = "Contact last name:"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 14
        Me.Label4.Location = New System.Drawing.Point(8, 16)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Supplier Name:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 13
        Me.Label2.Location = New System.Drawing.Point(8, 49)
        Me.Label2.Size = New System.Drawing.Size(90, 17)
        Me.Label2.Text = "Contact name:"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame2
        '
        Me.Frame2.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtProviderContact, Me.txtProviderCompany, Me.Label5, Me.Label1})
        Me.Frame2.Name = "Frame2"
        Me.Frame2.TabIndex = 10
        Me.Frame2.Location = New System.Drawing.Point(8, 267)
        Me.Frame2.Size = New System.Drawing.Size(511, 50)
        Me.Frame2.Text = "Supplier"
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtProviderContact
        '
        Me.txtProviderContact.Name = "txtProviderContact"
        Me.txtProviderContact.TabStop = False
        Me.txtProviderContact.TabIndex = 19
        Me.txtProviderContact.Location = New System.Drawing.Point(291, 16)
        Me.txtProviderContact.Size = New System.Drawing.Size(211, 20)
        Me.txtProviderContact.Text = ""
        Me.txtProviderContact.BackColor = System.Drawing.SystemColors.Menu
        Me.txtProviderContact.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProviderContact.ReadOnly = True
        '
        'txtProviderCompany
        '
        Me.txtProviderCompany.Name = "txtProviderCompany"
        Me.txtProviderCompany.TabStop = False
        Me.txtProviderCompany.TabIndex = 18
        Me.txtProviderCompany.Location = New System.Drawing.Point(73, 16)
        Me.txtProviderCompany.Size = New System.Drawing.Size(147, 20)
        Me.txtProviderCompany.Text = ""
        Me.txtProviderCompany.BackColor = System.Drawing.SystemColors.Menu
        Me.txtProviderCompany.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProviderCompany.ReadOnly = True
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 17
        Me.Label5.Location = New System.Drawing.Point(8, 16)
        Me.Label5.Size = New System.Drawing.Size(58, 17)
        Me.Label5.Text = "Name:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 16
        Me.Label1.Location = New System.Drawing.Point(235, 16)
        Me.Label1.Size = New System.Drawing.Size(58, 17)
        Me.Label1.Text = "Contact:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 32
        Me.Label7.Location = New System.Drawing.Point(8, 558)
        Me.Label7.Size = New System.Drawing.Size(82, 17)
        Me.Label7.Text = "Line quantity:"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label12
        '
        Me.Label12.Name = "Label12"
        Me.Label12.TabIndex = 31
        Me.Label12.Location = New System.Drawing.Point(8, 607)
        Me.Label12.Size = New System.Drawing.Size(90, 17)
        Me.Label12.Text = "Freight Charge:"
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label11
        '
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 29
        Me.Label11.Location = New System.Drawing.Point(8, 631)
        Me.Label11.Size = New System.Drawing.Size(90, 17)
        Me.Label11.Text = "Total:"
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label10
        '
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 27
        Me.Label10.Location = New System.Drawing.Point(275, 582)
        Me.Label10.Size = New System.Drawing.Size(90, 17)
        Me.Label10.Text = "Total Tax:"
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label9
        '
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 25
        Me.Label9.Location = New System.Drawing.Point(275, 607)
        Me.Label9.Size = New System.Drawing.Size(90, 17)
        Me.Label9.Text = "Sub Total:"
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 24
        Me.Label8.Location = New System.Drawing.Point(8, 582)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Sales Tax:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 21
        Me.Label6.Location = New System.Drawing.Point(8, 332)
        Me.Label6.Size = New System.Drawing.Size(33, 17)
        Me.Label6.Text = "Notes:"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmOrderReception
        '
        Me.ClientSize = New System.Drawing.Size(527, 711)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtNotes, Me.txtSubTotal, Me.txtTotal, Me.txtTotalTax, Me.txtFreightCharge, Me.txtSalesTax, Me.txtEntry, Me.fgProducts, Me.sbStatusBar, Me.cmdSave, Me.cmdClose, Me.cmdAddProducts, Me.Frame1, Me.Frame2, Me.Label7, Me.Label12, Me.Label11, Me.Label10, Me.Label9, Me.Label8, Me.Label6})
        Me.Name = "frmOrderReception"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Add Stock Order"
        CType(Me.fgProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.Frame2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Private currentProviderName As String
    ' VBto upgrade warning: currentIdProvider As Short	OnWrite(String)
    Private currentIdProvider As Short
    Private currentContactName As String
    Private editingData As Boolean

    Private currentSubTotal As Double
    Private currentTotal As Double
    Private currentTax As Double
    Private currentFreightCharge As Double
    Private currentTotalTax As Double

    Private Sub cmdAddProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddProducts.Click
        frmAddProductTo.Id = currentIdProvider
        frmAddProductTo.ObjectReferred = "Provider " & txtProviderCompany.Text & "|" & txtProviderContact.Text
        frmAddProductTo.Table = "ProductsByProvider"
        frmAddProductTo.ColumnName = "ProviderId"
        frmAddProductTo.LoadData()
        frmAddProductTo.ShowDialog()
        If frmAddProductTo.SavedChanges Then
            LoadProductsById()
        End If
    End Sub

'#Const defUse_txtName_Change = True
#If defUse_txtName_Change Then
    Private Sub txtName_Change()
        DoSearchProvider()
    End Sub
#End If

    Private Sub DoSearchProvider(Optional ByVal Id As Short = 0)
        Dim filter As String
        filter = ""
        If  Not IsEmpty(Id) Then
            filter = "ProviderID = " & Id
        End If
        If txtProviderName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter = "ProviderName LIKE '%" & txtProviderName.Text & "%'"
        End If
        If txtContactName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ContactFirstName LIKE '%" & txtContactName.Text & "%'"
        End If
        If txtContactLastName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ContactLastName LIKE '%" & txtContactLastName.Text & "%'"
        End If

        If filter<>Nothing Then
            filter = "Where " & filter
        End If
        ExecuteSql("Select ProviderID, ProviderName, ContactFirstName, ContactLastName, City, StateOrProvince, 'Country/Region' From Providers " & filter)
        lvProviders.Items.Clear()
        If rs.RecordCount=0 Then
            LogStatus("There are no records with the selected criteria", Me)
        Else
            Dim x As ListViewItem
            While  Not rs.EOF
                x = lvProviders.Items.Add(Convert.ToString(rs.Fields(0).Value))
                For i = 1 To (rs.ColumnCount-1)
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                    End If
                Next i
                rs.MoveNext()
            End While
            If lvProviders.Items.Count=1 Then
                lvProviders.FocusedItem = lvProviders.Items(1 - 1) : lvProviders.FocusedItem.Selected = True
            End If
        End If
    End Sub

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdProviders_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProviders.Click
        frmProviders.ShowDialog()
        txtProviderName.Text = ""
        txtContactLastName.Text = ""
        txtContactName.Text = ""
        DoSearchProvider(frmProviders.CurrentProviderID)
    End Sub

    Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        cmdSave_Click()
    End Sub
    Public Sub cmdSave_Click()
        ' VBto upgrade warning: newOrderId As Short	OnWrite(Object)
        Dim newOrderId As Short

        Try ' On Error GoTo HandleError
            ExecuteSql("Select * from OrderReceptions")
            rs.AddNew()
            rs.Fields("ProviderId").Value = currentIdProvider
            rs.Fields("ReceivedBy").Value = UserId
            rs.Fields("OrderDate").Value = CStr(Today)
            rs.Fields("Notes").Value = txtNotes.Text
            rs.Fields("FreightCharge").Value = currentFreightCharge
            rs.Fields("SalesTaxRate").Value = currentTax*0.01
            rs.Fields("Status").Value = "RECEIVED"
            rs.Update()
            newOrderId = rs.Fields("OrderID").Value


            For i = 1 To fgProducts.Rows-1
                If fgProducts.get_TextMatrix(i, 0)<>"0" Then
                    ExecuteSql("Insert into OrderReceptionDetails (OrderID, ProductID, DateSold, Quantity, UnitPrice, SalePrice, SalesTax, LineTotal) Values (" & newOrderId & ", '" & fgProducts.get_TextMatrix(i, 1) & "', '" & vbFormat(Today, "mm/dd/yyyy") & "'," & fgProducts.get_TextMatrix(i, 0) & "," & fgProducts.get_TextMatrix(i, 3) & "," & fgProducts.get_TextMatrix(i, 4) & "," & currentTax*0.01 & "," & fgProducts.get_TextMatrix(i, 4) & ")")

                    'UnitsInTransit
                    'ExecuteSql "Update Products Set UnitsOnOrder = UnitsOnOrder + " & fgProducts.TextMatrix(i, 0) &
                    '        '" Where ProductId = '" & fgProducts.TextMatrix(i, 1) & "'"

                End If
            Next i



            editingData = False
            If MsgBox("Order reception added successfully" & vbCrLf & "Would you like to add a new order reception?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "New data")=DialogResult.Yes Then
                ClearFields()
            Else
                Close()
            End If
            Exit Sub
        Catch	' HandleError:
            ' ...
        End Try
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")
    End Sub

    Private Sub MakeTextBoxVisible(ByVal txtBox As TextBox, ByVal grid As AxMSFlexGridLib.AxMSFlexGrid)
        With grid
            txtBox.Text = .get_TextMatrix(.Row, .Col)
            'txtBox.Move .CellLeft + .Left, .CellTop + .Top, .CellWidth, .CellHeight
            txtBox.Visible = True
            txtBox.Enabled = True
            'DoEvents
            txtBox.Focus()
            SelectAll(txtBox)
        End With
    End Sub

    Private Sub fgProducts_ClickEvent(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgProducts.ClickEvent
        If fgProducts.Col<>0 Then Exit Sub
        MakeTextBoxVisible(txtEntry, fgProducts)
    End Sub

    Private Sub fgProducts_EnterCell(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgProducts.EnterCell
        SaveEdits()
    End Sub

    Private Sub fgProducts_KeyPressEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_KeyPressEvent) Handles fgProducts.KeyPressEvent
        If fgProducts.Col<>0 Then Exit Sub
        Select Case e.keyAscii
            Case 46, 48 To 57:
                'Case 45, 46, 47, 48 To 59, 65 To 90, 97 To 122
                MakeTextBoxVisible(txtEntry, fgProducts)
                txtEntry.Text = Convert.ToString(Chr(e.keyAscii))
                txtEntry.SelectionStart = 1
        End Select
    End Sub

    Private Sub txtEntry_KeyDown(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles txtEntry.KeyDown
        Dim KeyCode As Keys = e.KeyCode
        Dim Shift As ShiftConstants = e.KeyData \ &H10000

        EditKeyCode(fgProducts, txtEntry, KeyCode, Shift)
    End Sub

    ' VBto upgrade warning: txtBox As TextBox	OnWrite(VB.TextBox, String)
    ' VBto upgrade warning: KeyCode As Short --> As Keys
    ' VBto upgrade warning: Shift As Short --> As ShiftConstants
    Private Sub EditKeyCode(ByVal grid As AxMSFlexGridLib.AxMSFlexGrid, ByRef txtBox As TextBox, ByVal KeyCode As Keys, ByVal Shift As ShiftConstants)
        Select Case KeyCode
            Case Keys.Escape:
                'ESC
                txtBox.Text = ""
                txtBox.Visible = False
                grid.Focus()
            Case Keys.Return:
                'Return
                grid.Focus()
            Case Keys.Left:
                'Left Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Col>grid.FixedCols Then
                    grid.Col -= 1
                End If
            Case Keys.Up:
                'Up Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Row>grid.FixedRows Then
                    grid.Row -= 1
                End If
            Case Keys.Right:
                'Right Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Col<grid.Cols-1 Then
                    grid.Col += 1
                End If
            Case Keys.Down:
                'Down Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Row<grid.Rows-1 Then
                    grid.Row += 1
                End If
        End Select
    End Sub

    Private Sub txtEntry_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEntry.Leave
        SaveEdits()
    End Sub


    Private Sub fgProducts_LeaveCell(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgProducts.LeaveCell
        SaveEdits()
    End Sub

    Private Sub txtEntry_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtEntry.KeyPress
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        Select Case KeyAscii
                'dot and Numbers
            Case Keys.Delete, Keys.D0 To Keys.D0:
                'Alphanumeric
                'Case 45, 46, 47, 48 To 59, 65 To 90, 97 To 122

            Case Else
                KeyAscii = 0
        End Select

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub

    Private Sub SaveEdits()
        Dim lineQuantity As Double, lineUnitPrice As Double, linePrice As Double
        Dim previousLinePrice As Double
        If  Not txtEntry.Visible Or  Not ValidateTextBoxDouble(txtEntry, Me) Or  Not ValidateTextDouble(fgProducts.get_TextMatrix(fgProducts.Row, 3), Me) Or  Not ValidateTextDouble(fgProducts.get_TextMatrix(fgProducts.Row, 4), Me) Then Exit Sub
        previousLinePrice = DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4))
        fgProducts.set_TextMatrix(fgProducts.Row, fgProducts.Col, txtEntry.Text)
        lineQuantity = DoubleValue(txtEntry.Text)
        lineUnitPrice = DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 3))
        previousLinePrice = DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4))
        linePrice = CDbl(lineQuantity*lineUnitPrice)
        fgProducts.set_TextMatrix(fgProducts.Row, 4, linePrice)
        ReCalculateTotals(previousLinePrice, linePrice)
        txtEntry.Visible = False
        editingData = True
    End Sub

    Private Sub ReCalculateTotals(ByVal previous As Double, ByVal current As Double)
        currentSubTotal += -previous+current
        currentTotalTax = currentSubTotal*currentTax*0.01
        currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax
        txtSubTotal.Text = vbFormat(currentSubTotal, "#,##0.00")
        txtTotalTax.Text = vbFormat(currentTotalTax, "#,##0.00")
        txtTotal.Text = vbFormat(currentTotal, "#,##0.00")
    End Sub

    ' VBto upgrade warning: Cancel As Short	OnWrite(Boolean)
    Private Sub Form_QueryUnload(ByRef Cancel As Short, ByVal UnloadMode As Short)
        If editingData Then
            Dim res As DialogResult
            res = MsgBox("Do you want to save the edited data?", MsgBoxStyle.YesNoCancel Or MsgBoxStyle.Question, "Save data")
            If res=DialogResult.Yes Then
                cmdSave_Click()
            ElseIf res<>DialogResult.No Then
                Cancel = True
            End If
        End If
    End Sub

    Private Sub frmOrderReception_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_QueryUnload(Cancel, 0)
        If Cancel <> 0 Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub frmOrderReception_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        editingData = False
        ClearFields()
    End Sub

    Private Sub lvProviders_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvProviders.SelectedIndexChanged
        Dim Item As ListViewItem = CType(sender, ListView).FocusedItem
        If Item Is Nothing Then Exit Sub

        RetrieveDataProvider()
    End Sub

    Private Sub RetrieveDataProvider()
        If editingData Then
            If MsgBox("Do you want to cancel previous edited data?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Data edition")<>DialogResult.Yes Then
                Exit Sub
            End If
        End If

        If lvProviders.FocusedItem.Text<>Nothing Then
            With lvProviders.FocusedItem
                currentIdProvider = lvProviders.FocusedItem.Text
                currentProviderName = .SubItems(1).Text
                currentContactName = .SubItems(2).Text & " " & .SubItems(3).Text
            End With
            txtProviderCompany.Text = currentProviderName
            txtProviderContact.Text = currentContactName
            editingData = False
        End If
        LoadProductsById()
        cmdSave.Enabled = True
        cmdAddProducts.Enabled = True

    End Sub

    Private Sub LoadProductsById()
        Dim Table As String
        Dim ColumnName As String
        Dim Id As Short
        Table = "ProductsByProvider"
        ColumnName = "ProviderId"
        Id = currentIdProvider

        ExecuteSql("Select p.ProductID, p.ProductName, p.UnitPrice, p.UnitsInStock, p.UnitsOnOrder, p.QuantityPerUnit, p.Unit from Products as p, " & Table & " as pb Where pb." & ColumnName & " = " & Id & " And pb.ProductId = p.ProductId")

        'lvProducts.ListItems.Clear
        'If rs.RecordCount > 0 Then
        '    With rs
        '        While Not .EOF
        '            Set x = lvProducts.ListItems.Add(, , 0)
        '            For i = 1 To 5
        '                If Not IsEmpty(.Fields(i - 1)) Then
        '                    x.SubItems(i) = .Fields(i - 1)
        '                End If
        '            Next i
        '            x.SubItems(6) = .Fields(5) & .Fields(6)
        '            .MoveNext
        '        Wend
        '    End With
        'End If

        Dim lng As Integer
        Dim j As Short
        Dim intLoopCount As Short
        Const SCROOL_WIDTH As Short = 320
        With fgProducts
            .Cols = 8
            .FixedCols = 0
            .Rows = 0
            .AddItem("Quantity" & vbTab & "Code" & vbTab & "Product" & vbTab & "UnitPrice" & vbTab & "Price" & vbTab & "Existence" & vbTab & "Ordered" & vbTab & "Quantity per unit")
            .Rows = rs.RecordCount+1
            If .Rows=1 Then .FixedRows = 0 Else .FixedRows = 1
            Dim i As Short
            i = 1
            While  Not rs.EOF
                .set_TextMatrix(i, 0, "0")
                For j = 1 To 6
                    If j=4 Then
                        .set_TextMatrix(i, j, "0")
                    ElseIf j<4 Then
                        .set_TextMatrix(i, j, Convert.ToString(rs.Fields(j-1).Value))
                    Else
                        .set_TextMatrix(i, j, Convert.ToString(rs.Fields(j-2).Value))
                    End If
                Next j
                .set_TextMatrix(i, 7, Convert.ToString(rs.Fields(5).Value) & Convert.ToString(rs.Fields(6).Value))
                rs.MoveNext()
                i += 1
            End While
        End With

    End Sub


'#Const defUse_lvProducts_ItemCheck = True
#If defUse_lvProducts_ItemCheck Then
    Private Sub lvProducts_ItemCheck(ByVal Item As ListViewItem)
        If Item.Checked Then
            Item.Text = "1"
        Else
            Item.Text = "0"
        End If
    End Sub
#End If


    Private Sub txtProviderName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtProviderName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProvider()
    End Sub

    Private Sub txtNotes_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtNotes.TextChanged
        If Not sender.Created() Then Exit Sub
        editingData = True
    End Sub

    Private Sub txtContactName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProvider()
    End Sub

    Private Sub ClearFields()

        fgProducts.Rows = 0
        fgProducts.Cols = 0

        currentSubTotal = 0
        currentTotal = 0
        currentTax = 0
        currentTotalTax = 0
        currentFreightCharge = 0

        txtSubTotal.Text = ""
        txtTotal.Text = ""
        txtTotalTax.Text = ""
        txtSalesTax.Text = ""
        txtFreightCharge.Text = ""

        txtProviderName.Text = ""
        txtContactLastName.Text = ""
        txtContactName.Text = ""
        txtProviderContact.Text = ""
        txtProviderCompany.Text = ""
        cmdSave.Enabled = False
        cmdAddProducts.Enabled = False
        txtNotes.Text = ""
        'txtProviderName.SetFocus
        ReCalculateTotals(0, 0)
        editingData = False
    End Sub

    Private Sub txtFreightCharge_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFreightCharge.TextChanged
        If Not sender.Created() Then Exit Sub
        currentFreightCharge = DoubleValue(txtFreightCharge.Text)
        ReCalculateTotals(0, 0)
        editingData = True
    End Sub

    Private Sub txtFreightCharge_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFreightCharge.KeyPress
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        Select Case KeyAscii
            Case Keys.D0 To Keys.D9:
            Case Keys.Back, Keys.Clear, Keys.Delete:
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Tab:

            Case Else
                KeyAscii = 0
                Beep()
        End Select

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub

    Private Sub txtContactLastName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactLastName.TextChanged
        If Not sender.Created() Then Exit Sub
        editingData = True
    End Sub


    Private Sub txtSalesTax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSalesTax.TextChanged
        If Not sender.Created() Then Exit Sub
        currentTax = DoubleValue(txtSalesTax.Text)
        ReCalculateTotals(0, 0)
        editingData = True
    End Sub

    Private Sub txtSalesTax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSalesTax.KeyPress
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        Select Case KeyAscii
            Case Keys.D0 To Keys.D9:
            Case Keys.Back, Keys.Clear, Keys.Delete:
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Tab:

            Case Else
                KeyAscii = 0
                Beep()
        End Select

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub

End Class