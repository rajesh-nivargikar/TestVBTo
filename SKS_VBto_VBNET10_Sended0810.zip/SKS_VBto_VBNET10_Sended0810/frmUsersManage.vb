
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmUsersManage
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Label1 As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    Friend WithEvents lstAccounts As System.Windows.Forms.ListView
    Friend WithEvents lstAccountsColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lstAccountsColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lstAccountsColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents cmdClear As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents ctrlLiner1 As System.Windows.Forms.PictureBox
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtFullname As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtUsername As System.Windows.Forms.TextBox
    Friend WithEvents cboLevel As System.Windows.Forms.ComboBox
    Friend WithEvents Label1_2 As System.Windows.Forms.Label
    Friend WithEvents Label1_0 As System.Windows.Forms.Label
    Friend WithEvents Label1_1 As System.Windows.Forms.Label
    Friend WithEvents Label1_3 As System.Windows.Forms.Label
    Friend WithEvents lblId As System.Windows.Forms.Label
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdEdit As System.Windows.Forms.Button
    Friend WithEvents cmdDelete As System.Windows.Forms.Button
    Friend WithEvents Label1_4 As System.Windows.Forms.Label
    Friend WithEvents Image1 As System.Windows.Forms.PictureBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmUsersManage))
        Me.components = New System.ComponentModel.Container()
        Me.Label1 = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
        Me.lstAccounts = New System.Windows.Forms.ListView()
        Me.lstAccountsColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lstAccountsColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lstAccountsColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.cmdClear = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.ctrlLiner1 = New System.Windows.Forms.PictureBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtFullname = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtUsername = New System.Windows.Forms.TextBox()
        Me.cboLevel = New System.Windows.Forms.ComboBox()
        Me.Label1_2 = New System.Windows.Forms.Label()
        Me.Label1_0 = New System.Windows.Forms.Label()
        Me.Label1_1 = New System.Windows.Forms.Label()
        Me.Label1_3 = New System.Windows.Forms.Label()
        Me.lblId = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdEdit = New System.Windows.Forms.Button()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.Label1_4 = New System.Windows.Forms.Label()
        Me.Image1 = New System.Windows.Forms.PictureBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'lstAccounts
        '
        Me.lstAccounts.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lstAccountsColumnHeader0, Me.lstAccountsColumnHeader1, Me.lstAccountsColumnHeader2})
        Me.lstAccounts.Name = "lstAccounts"
        Me.lstAccounts.TabIndex = 7
        Me.lstAccounts.Location = New System.Drawing.Point(0, 267)
        Me.lstAccounts.Size = New System.Drawing.Size(341, 114)
        Me.lstAccounts.BackColor = System.Drawing.SystemColors.Window
        Me.lstAccounts.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lstAccounts.LabelEdit = True
        Me.lstAccounts.View = System.Windows.Forms.View.Details
        Me.lstAccounts.MultiSelect = False
        Me.lstAccounts.FullRowSelect = True
        Me.lstAccounts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        '
        'ColumnHeader(1)
        '
        Me.lstAccountsColumnHeader0.Text = "UserId"
        Me.lstAccountsColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lstAccountsColumnHeader1.Text = "Name"
        Me.lstAccountsColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lstAccountsColumnHeader2.Text = "Level"
        Me.lstAccountsColumnHeader2.Width = 98
        '
        'cmdClear
        '
        Me.cmdClear.Name = "cmdClear"
        Me.cmdClear.TabIndex = 5
        Me.cmdClear.Location = New System.Drawing.Point(170, 235)
        Me.cmdClear.Size = New System.Drawing.Size(82, 25)
        Me.cmdClear.Text = "&New"
        Me.cmdClear.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClear.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdSave
        '
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 4
        Me.cmdSave.Location = New System.Drawing.Point(81, 235)
        Me.cmdSave.Size = New System.Drawing.Size(82, 25)
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'ctrlLiner1
        '
        Me.ctrlLiner1.Name = "ctrlLiner1"
        Me.ctrlLiner1.TabIndex = 15
        Me.ctrlLiner1.Location = New System.Drawing.Point(0, 57)
        Me.ctrlLiner1.Size = New System.Drawing.Size(317, 2)
        Me.ctrlLiner1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ctrlLiner1.BackColor = System.Drawing.SystemColors.Control
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtFullname, Me.txtPassword, Me.txtUsername, Me.cboLevel, Me.Label1_2, Me.Label1_0, Me.Label1_1, Me.Label1_3, Me.lblId})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 10
        Me.Frame1.Location = New System.Drawing.Point(8, 65)
        Me.Frame1.Size = New System.Drawing.Size(333, 155)
        Me.Frame1.Text = "User information"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        Me.Frame1.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'txtFullname
        '
        Me.txtFullname.Name = "txtFullname"
        Me.txtFullname.TabIndex = 2
        Me.txtFullname.Location = New System.Drawing.Point(121, 89)
        Me.txtFullname.Size = New System.Drawing.Size(195, 19)
        Me.txtFullname.Text = ""
        Me.txtFullname.BackColor = System.Drawing.SystemColors.Window
        Me.txtFullname.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFullname.MaxLength = 50
        Me.txtFullname.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        '
        'txtPassword
        '
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.TabIndex = 1
        Me.txtPassword.Location = New System.Drawing.Point(121, 57)
        Me.txtPassword.Size = New System.Drawing.Size(195, 19)
        Me.txtPassword.Text = ""
        Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPassword.MaxLength = 50
        Me.txtPassword.Font = New System.Drawing.Font("Wingdings", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        '
        'txtUsername
        '
        Me.txtUsername.Name = "txtUsername"
        Me.txtUsername.TabIndex = 0
        Me.txtUsername.Location = New System.Drawing.Point(121, 24)
        Me.txtUsername.Size = New System.Drawing.Size(195, 19)
        Me.txtUsername.Text = ""
        Me.txtUsername.BackColor = System.Drawing.SystemColors.Window
        Me.txtUsername.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUsername.MaxLength = 50
        Me.txtUsername.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        '
        'cboLevel
        '
        Me.cboLevel.Name = "cboLevel"
        Me.cboLevel.TabIndex = 3
        Me.cboLevel.Location = New System.Drawing.Point(121, 121)
        Me.cboLevel.Size = New System.Drawing.Size(195, 21)
        Me.cboLevel.Text = ""
        Me.cboLevel.BackColor = System.Drawing.SystemColors.Window
        Me.cboLevel.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboLevel.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cboLevel.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(204, Byte))
        '
        'Label1_2
        '
        Me.Label1_2.Name = "Label1_2"
        Me.Label1_2.TabIndex = 16
        Me.Label1_2.AutoSize = True
        Me.Label1_2.Location = New System.Drawing.Point(16, 89)
        Me.Label1_2.Size = New System.Drawing.Size(69, 13)
        Me.Label1_2.Text = "Full name: *"
        Me.Label1_2.BackColor = System.Drawing.SystemColors.Control
        Me.Label1_2.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label1_2.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label1_0
        '
        Me.Label1_0.Name = "Label1_0"
        Me.Label1_0.TabIndex = 14
        Me.Label1_0.AutoSize = True
        Me.Label1_0.Location = New System.Drawing.Point(16, 24)
        Me.Label1_0.Size = New System.Drawing.Size(71, 13)
        Me.Label1_0.Text = "Username: *"
        Me.Label1_0.BackColor = System.Drawing.SystemColors.Control
        Me.Label1_0.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label1_0.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label1_1
        '
        Me.Label1_1.Name = "Label1_1"
        Me.Label1_1.TabIndex = 13
        Me.Label1_1.AutoSize = True
        Me.Label1_1.Location = New System.Drawing.Point(16, 57)
        Me.Label1_1.Size = New System.Drawing.Size(97, 13)
        Me.Label1_1.Text = "New password: *"
        Me.Label1_1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1_1.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label1_1.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label1_3
        '
        Me.Label1_3.Name = "Label1_3"
        Me.Label1_3.TabIndex = 12
        Me.Label1_3.AutoSize = True
        Me.Label1_3.Location = New System.Drawing.Point(16, 121)
        Me.Label1_3.Size = New System.Drawing.Size(72, 13)
        Me.Label1_3.Text = "User level: *"
        Me.Label1_3.BackColor = System.Drawing.SystemColors.Control
        Me.Label1_3.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label1_3.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'lblId
        '
        Me.lblId.Name = "lblId"
        Me.lblId.TabIndex = 11
        Me.lblId.AutoSize = True
        Me.lblId.Location = New System.Drawing.Point(129, 24)
        Me.lblId.Size = New System.Drawing.Size(3, 13)
        Me.lblId.Text = ""
        Me.lblId.BackColor = System.Drawing.SystemColors.Control
        Me.lblId.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.lblId.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 6
        Me.cmdClose.Location = New System.Drawing.Point(259, 235)
        Me.cmdClose.Size = New System.Drawing.Size(82, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdEdit
        '
        Me.cmdEdit.Name = "cmdEdit"
        Me.cmdEdit.TabIndex = 8
        Me.cmdEdit.Location = New System.Drawing.Point(170, 388)
        Me.cmdEdit.Size = New System.Drawing.Size(82, 25)
        Me.cmdEdit.Text = "&Edit"
        Me.cmdEdit.BackColor = System.Drawing.SystemColors.Control
        Me.cmdEdit.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdDelete
        '
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.TabIndex = 9
        Me.cmdDelete.Location = New System.Drawing.Point(259, 388)
        Me.cmdDelete.Size = New System.Drawing.Size(82, 25)
        Me.cmdDelete.Text = "&Delete"
        Me.cmdDelete.BackColor = System.Drawing.SystemColors.Control
        Me.cmdDelete.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1_4
        '
        Me.Label1_4.Name = "Label1_4"
        Me.Label1_4.TabIndex = 19
        Me.Label1_4.AutoSize = True
        Me.Label1_4.Location = New System.Drawing.Point(8, 396)
        Me.Label1_4.Size = New System.Drawing.Size(96, 13)
        Me.Label1_4.Text = "* Required fields"
        Me.Label1_4.BackColor = System.Drawing.SystemColors.Control
        Me.Label1_4.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label1_4.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Image1
        '
        Me.Image1.Name = "Image1"
        Me.ToolTip1.SetToolTip(Me.Image1, "View warnings")
        Me.Image1.Location = New System.Drawing.Point(8, 8)
        Me.Image1.Size = New System.Drawing.Size(32, 32)
        Me.Image1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Image1.BackColor = System.Drawing.SystemColors.Control
        Me.Image1.Image = CType(Resources.GetObject("Image1.Image"), System.Drawing.Bitmap)
        Me.Image1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        '
        'Label19
        '
        Me.Label19.Name = "Label19"
        Me.Label19.TabIndex = 18
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(49, 8)
        Me.Label19.Size = New System.Drawing.Size(34, 16)
        Me.Label19.Text = "User"
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label19.Font = New System.Drawing.Font("MS Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 17
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(49, 32)
        Me.Label4.Size = New System.Drawing.Size(178, 13)
        Me.Label4.Text = "Set user information and access level"
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        '
        'frmUsersManage
        '
        Me.ClientSize = New System.Drawing.Size(349, 419)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.lstAccounts, Me.cmdClear, Me.cmdSave, Me.ctrlLiner1, Me.Frame1, Me.cmdClose, Me.cmdEdit, Me.cmdDelete, Me.Label1_4, Me.Image1, Me.Label19, Me.Label4})
        Me.Name = "frmUsersManage"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = True
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Icon = CType(Resources.GetObject("frmUsersManage.Icon"), System.Drawing.Icon)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Users Management"
        Me.Label1.SetIndex(Label1_2, CType(2, Short))
        Me.Label1.SetIndex(Label1_0, CType(0, Short))
        Me.Label1.SetIndex(Label1_1, CType(1, Short))
        Me.Label1.SetIndex(Label1_3, CType(3, Short))
        Me.Label1.SetIndex(Label1_4, CType(4, Short))
        CType(Me.Label1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.txtPassword.ResumeLayout(False)
        Me.Label1_2.ResumeLayout(False)
        Me.Label1_0.ResumeLayout(False)
        Me.Label1_1.ResumeLayout(False)
        Me.Label1_3.ResumeLayout(False)
        Me.lblId.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Label1_4.ResumeLayout(False)
        Me.Label19.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Dim CurrentEditedUser As String = ""

    Private Sub cmdClear_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClear.Click
        txtUsername.Text = String.Empty
        txtUsername.Focus()
        ClearFields()
    End Sub

    Private Sub cmdDelete_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdDelete.Click
        If NoRecords(lstAccounts, "Please add/select a user") Then Exit Sub
        If MsgBox("Are you sure you want to delete the user '" & lstAccounts.FocusedItem.Text & "'?", MsgBoxStyle.Exclamation Or MsgBoxStyle.YesNo)=DialogResult.Yes Then
            ExecuteSql("Select * from Users")
            If rs.RecordCount=1 Then
                MsgBox("You cannot delete the last user", MsgBoxStyle.Critical, "Delete error")
                Exit Sub
            End If
            ExecuteSql("delete * from Users where Username = '" & lstAccounts.FocusedItem.Text & "'")
            LoadUsers()
        End If
    End Sub

    Private Sub cmdEdit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdEdit.Click
        cmdEdit_Click()
    End Sub
    Public Sub cmdEdit_Click()
        If NoRecords(lstAccounts, "Please add/select a user") Then Exit Sub
        ExecuteSql("Select * from Users where Username = '" & lstAccounts.FocusedItem.Text & "'")
        txtUsername.Text = Convert.ToString(rs.Fields("UserName").Value)
        If rs.EOF Then
            MsgBox("This user does not exist", MsgBoxStyle.Information)
            txtUsername.Focus()
        Else
            txtUsername.Text = Convert.ToString(rs.Fields("UserName").Value)
            CurrentEditedUser = txtUsername.Text
            txtPassword.Text = Convert.ToString(rs.Fields("Password").Value)
            txtFullname.Text = Convert.ToString(rs.Fields("Fullname").Value)
            cboLevel.Text = Convert.ToString(rs.Fields("Level").Value)
            cmdSave.Text = "&Update"
        End If
    End Sub

    Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        Dim SecId As String
        If TextBoxEmpty(txtUsername) Then Exit Sub
        If TextBoxEmpty(txtPassword) Then Exit Sub
        If TextBoxEmpty(txtFullname) Then Exit Sub
        If ComboEmpty(cboLevel) Then Exit Sub

        ExecuteSql("Select * from Users where Username = '" & txtUsername.Text & "'")
        If cmdSave.Text<>"&Update" Then
            If  Not rs.EOF Then
                MsgBox("Add failed: Username already exists", MsgBoxStyle.Critical)
                Exit Sub
            End If

            If cboLevel.Text<>"Administrator" Then
                ExecuteSql2("Select * from Users where level = 'Administrator'")
                If rs2.EOF Then
                    MsgBox("Update failed: No any Administrator found on accounts.  You are not allowed to change the level of this account", MsgBoxStyle.Critical)
                    Exit Sub
                End If
            End If
            If  Not CurrentUserAdmin And cboLevel.Text="Administrator" Then
                MsgBox("You cannot add another level without being 'Administrator'", MsgBoxStyle.Information)
                cboLevel.Focus()
                Exit Sub
            End If
            rs.AddNew()
            msg = "Added new user " & txtUsername.Text
        ElseIf CurrentEditedUser<>txtUsername.Text Then
            ExecuteSql2("Select * from Users where username = '" & txtUsername.Text & "'")
            If  Not rs2.EOF Then
                MsgBox("Username '" & txtUsername.Text & "' already exists.", MsgBoxStyle.Information)
                txtUsername.Focus()
                SelectAll(txtUsername)
                Exit Sub
            End If
            msg = "Record for the user " & txtUsername.Text & " has been successfully updated"
        Else
            msg = "Record for the user " & txtUsername.Text & " has been successfully updated"
        End If
        rs.Fields("UserName").Value = txtUsername.Text
        rs.Fields("Password").Value = txtPassword.Text
        rs.Fields("Level").Value = cboLevel.Text
        rs.Fields("Fullname").Value = txtFullname.Text
        rs.Update()
        LogStatus(msg)
        ClearFields()
        LoadUsers()

        If CurrentUserAdmin Then
            Close()
        End If
    End Sub

    Public Sub LoadUsers()
        ExecuteSql("Select * from Users")
        lstAccounts.Items.Clear()
        Dim x As ListViewItem
        While  Not rs.EOF
            x = lstAccounts.Items.Add(Convert.ToString(rs.Fields("UserName").Value))
            SubItemsSetText(x, 1, Convert.ToString(rs.Fields("Fullname").Value))
            SubItemsSetText(x, 2, Convert.ToString(rs.Fields("Level").Value))
            rs.MoveNext()
        End While
    End Sub

'#Const defUse_LoadUsersAvoidingWith = True
#If defUse_LoadUsersAvoidingWith Then
    Public Sub LoadUsersAvoidingWith()
        ExecuteSql("Select * from Users")
        lstAccounts.Items.Clear()
        Dim x As ListViewItem
        While  Not rs.EOF
            x = lstAccounts.Items.Add(Convert.ToString(rs.Fields("UserName").Value))
            SubItemsSetText(x, 1, Convert.ToString(rs.Fields("Fullname").Value))
            SubItemsSetText(x, 2, Convert.ToString(rs.Fields("Level").Value))
            rs.MoveNext()
        End While
    End Sub
#End If


    Public Sub ClearFields()
        txtUsername.Text = String.Empty
        txtPassword.Text = String.Empty
        txtFullname.Text = String.Empty
        cboLevel.SelectedIndex = -1
        cmdSave.Text = "&Save"
    End Sub

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub frmUsersManage_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        ExecuteSql("Select * from Levels")
        While  Not rs.EOF
            cboLevel.Items.Add(Convert.ToString(rs.Fields("Level").Value))
            rs.MoveNext()
        End While
        If CurrentUserAdmin Then
            cboLevel.Text = "Administrator"
        Else
            cboLevel.SelectedIndex = -1
        End If
        LoadUsers()
    End Sub

    Private Sub Form_Unload(ByRef Cancel As Short)
        If CurrentUserAdmin Then
            ExecuteSql("Select * from Users")
            If rs.EOF Then
                MsgBox("System has failed to initialized. Please contact your administrator" & vbNewLine & vbNewLine & "Status: analysing accounts configuration" & vbNewLine & "Error: No users found", MsgBoxStyle.Critical)
                Application.Exit()
            End If
            'frmxSplash.tmrLoad.Enabled = True
        End If
        LogStatus("")
    End Sub

    Private Sub frmUsersManage_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_Unload(Cancel)
        If Cancel <> 0 Then e.Cancel = True
    End Sub

    Private Sub lstAccounts_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles lstAccounts.DoubleClick
        cmdEdit_Click()
    End Sub

    Private Sub txtFullname_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtFullname.Enter
        SelectAll(txtFullname)
    End Sub

    Private Sub txtPassword_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtPassword.Enter
        SelectAll(txtPassword)
    End Sub

    Private Sub txtUsername_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtUsername.Enter
        SelectAll(txtUsername)
    End Sub

End Class