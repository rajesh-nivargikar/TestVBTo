
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmOrderRequest
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalTax As System.Windows.Forms.TextBox
    Friend WithEvents txtFreightCharge As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesTax As System.Windows.Forms.TextBox
    Friend WithEvents txtEntry As System.Windows.Forms.TextBox
    Friend WithEvents fgProducts As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents dtRequired As System.Windows.Forms.DateTimePicker
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdAddProducts As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtContactLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtContactName As System.Windows.Forms.TextBox
    Friend WithEvents cmdCustomers As System.Windows.Forms.Button
    Friend WithEvents txtCompanyName As System.Windows.Forms.TextBox
    Friend WithEvents lvCustomers As System.Windows.Forms.ListView
    Friend WithEvents lvCustomersColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvCustomersColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvCustomersColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvCustomersColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvCustomersColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvCustomersColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvCustomersColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Frame2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCustomerContact As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomerCompany As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtPromised As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmOrderRequest))
        Me.txtSubTotal = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtTotalTax = New System.Windows.Forms.TextBox()
        Me.txtFreightCharge = New System.Windows.Forms.TextBox()
        Me.txtSalesTax = New System.Windows.Forms.TextBox()
        Me.txtEntry = New System.Windows.Forms.TextBox()
        Me.fgProducts = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.dtRequired = New System.Windows.Forms.DateTimePicker()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdAddProducts = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtContactLastName = New System.Windows.Forms.TextBox()
        Me.txtContactName = New System.Windows.Forms.TextBox()
        Me.cmdCustomers = New System.Windows.Forms.Button()
        Me.txtCompanyName = New System.Windows.Forms.TextBox()
        Me.lvCustomers = New System.Windows.Forms.ListView()
        Me.lvCustomersColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvCustomersColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvCustomersColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvCustomersColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lvCustomersColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.lvCustomersColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.lvCustomersColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.txtCustomerContact = New System.Windows.Forms.TextBox()
        Me.txtCustomerCompany = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.dtPromised = New System.Windows.Forms.DateTimePicker()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.fgProducts, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtSubTotal
        '
        Me.txtSubTotal.Name = "txtSubTotal"
        Me.txtSubTotal.TabStop = False
        Me.txtSubTotal.TabIndex = 31
        Me.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSubTotal.Location = New System.Drawing.Point(356, 623)
        Me.txtSubTotal.Size = New System.Drawing.Size(147, 20)
        Me.txtSubTotal.Text = ""
        Me.txtSubTotal.BackColor = System.Drawing.SystemColors.Menu
        Me.txtSubTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSubTotal.ReadOnly = True
        '
        'txtTotal
        '
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.TabStop = False
        Me.txtTotal.TabIndex = 29
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotal.Location = New System.Drawing.Point(97, 623)
        Me.txtTotal.Size = New System.Drawing.Size(147, 20)
        Me.txtTotal.Text = ""
        Me.txtTotal.BackColor = System.Drawing.SystemColors.Menu
        Me.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotal.ReadOnly = True
        '
        'txtTotalTax
        '
        Me.txtTotalTax.Name = "txtTotalTax"
        Me.txtTotalTax.TabStop = False
        Me.txtTotalTax.TabIndex = 27
        Me.txtTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotalTax.Location = New System.Drawing.Point(356, 599)
        Me.txtTotalTax.Size = New System.Drawing.Size(147, 20)
        Me.txtTotalTax.Text = ""
        Me.txtTotalTax.BackColor = System.Drawing.SystemColors.Menu
        Me.txtTotalTax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotalTax.ReadOnly = True
        '
        'txtFreightCharge
        '
        Me.txtFreightCharge.Name = "txtFreightCharge"
        Me.txtFreightCharge.TabIndex = 8
        Me.txtFreightCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtFreightCharge.Location = New System.Drawing.Point(97, 599)
        Me.txtFreightCharge.Size = New System.Drawing.Size(147, 20)
        Me.txtFreightCharge.Text = ""
        Me.txtFreightCharge.BackColor = System.Drawing.SystemColors.Window
        Me.txtFreightCharge.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtSalesTax
        '
        Me.txtSalesTax.Name = "txtSalesTax"
        Me.txtSalesTax.TabIndex = 7
        Me.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSalesTax.Location = New System.Drawing.Point(97, 574)
        Me.txtSalesTax.Size = New System.Drawing.Size(147, 20)
        Me.txtSalesTax.Text = ""
        Me.txtSalesTax.BackColor = System.Drawing.SystemColors.Window
        Me.txtSalesTax.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtEntry
        '
        Me.txtEntry.Name = "txtEntry"
        Me.txtEntry.Enabled = False
        Me.txtEntry.TabIndex = 24
        Me.txtEntry.Location = New System.Drawing.Point(97, 550)
        Me.txtEntry.Size = New System.Drawing.Size(147, 19)
        Me.txtEntry.Text = ""
        Me.txtEntry.BackColor = System.Drawing.SystemColors.Window
        Me.txtEntry.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'fgProducts
        '
        Me.fgProducts.Name = "fgProducts"
        Me.fgProducts.TabIndex = 6
        Me.fgProducts.Location = New System.Drawing.Point(8, 364)
        Me.fgProducts.Size = New System.Drawing.Size(511, 179)
        Me.fgProducts.OcxState = CType(resources.GetObject("fgProducts.OcxState"), System.Windows.Forms.AxHost.State)
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 23
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 686)
        Me.sbStatusBar.Size = New System.Drawing.Size(529, 25)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 527
        '
        'dtRequired
        '
        Me.dtRequired.Name = "dtRequired"
        Me.dtRequired.TabIndex = 4
        Me.dtRequired.Location = New System.Drawing.Point(121, 324)
        Me.dtRequired.Size = New System.Drawing.Size(98, 20)
        '
        'cmdSave
        '
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 9
        Me.cmdSave.Location = New System.Drawing.Point(324, 655)
        Me.cmdSave.Size = New System.Drawing.Size(90, 25)
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdAddProducts
        '
        Me.cmdAddProducts.Name = "cmdAddProducts"
        Me.cmdAddProducts.TabStop = False
        Me.cmdAddProducts.TabIndex = 21
        Me.cmdAddProducts.Location = New System.Drawing.Point(493, 340)
        Me.cmdAddProducts.Size = New System.Drawing.Size(25, 23)
        Me.cmdAddProducts.Text = "..."
        Me.cmdAddProducts.BackColor = System.Drawing.SystemColors.Control
        Me.cmdAddProducts.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 10
        Me.cmdClose.Location = New System.Drawing.Point(421, 655)
        Me.cmdClose.Size = New System.Drawing.Size(90, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtContactLastName, Me.txtContactName, Me.cmdCustomers, Me.txtCompanyName, Me.lvCustomers, Me.Label3, Me.Label4, Me.Label2})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 12
        Me.Frame1.Location = New System.Drawing.Point(8, 8)
        Me.Frame1.Size = New System.Drawing.Size(511, 252)
        Me.Frame1.Text = "Search customer"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtContactLastName
        '
        Me.txtContactLastName.Name = "txtContactLastName"
        Me.txtContactLastName.TabIndex = 2
        Me.txtContactLastName.Location = New System.Drawing.Point(340, 49)
        Me.txtContactLastName.Size = New System.Drawing.Size(147, 20)
        Me.txtContactLastName.Text = ""
        Me.txtContactLastName.BackColor = System.Drawing.SystemColors.Window
        Me.txtContactLastName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtContactName
        '
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.TabIndex = 1
        Me.txtContactName.Location = New System.Drawing.Point(89, 49)
        Me.txtContactName.Size = New System.Drawing.Size(147, 20)
        Me.txtContactName.Text = ""
        Me.txtContactName.BackColor = System.Drawing.SystemColors.Window
        Me.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmdCustomers
        '
        Me.cmdCustomers.Name = "cmdCustomers"
        Me.cmdCustomers.TabStop = False
        Me.cmdCustomers.TabIndex = 13
        Me.cmdCustomers.Location = New System.Drawing.Point(461, 16)
        Me.cmdCustomers.Size = New System.Drawing.Size(25, 23)
        Me.cmdCustomers.Text = "..."
        Me.cmdCustomers.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCustomers.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtCompanyName
        '
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.TabIndex = 0
        Me.txtCompanyName.Location = New System.Drawing.Point(89, 16)
        Me.txtCompanyName.Size = New System.Drawing.Size(147, 20)
        Me.txtCompanyName.Text = ""
        Me.txtCompanyName.BackColor = System.Drawing.SystemColors.Window
        Me.txtCompanyName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'lvCustomers
        '
        Me.lvCustomers.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvCustomersColumnHeader0, Me.lvCustomersColumnHeader1, Me.lvCustomersColumnHeader2, Me.lvCustomersColumnHeader3, Me.lvCustomersColumnHeader4, Me.lvCustomersColumnHeader5, Me.lvCustomersColumnHeader6})
        Me.lvCustomers.Name = "lvCustomers"
        Me.lvCustomers.TabIndex = 3
        Me.lvCustomers.Location = New System.Drawing.Point(8, 81)
        Me.lvCustomers.Size = New System.Drawing.Size(494, 163)
        Me.lvCustomers.BackColor = System.Drawing.SystemColors.Window
        Me.lvCustomers.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvCustomers.View = System.Windows.Forms.View.Details
        Me.lvCustomers.MultiSelect = False
        Me.lvCustomers.GridLines = True
        Me.lvCustomers.FullRowSelect = True
        Me.lvCustomers.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvCustomers.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvCustomersColumnHeader0.Text = "Customer ID"
        Me.lvCustomersColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvCustomersColumnHeader1.Text = "Company Name"
        Me.lvCustomersColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvCustomersColumnHeader2.Text = "Contact Name"
        Me.lvCustomersColumnHeader2.Width = 98
        '
        'ColumnHeader(4)
        '
        Me.lvCustomersColumnHeader3.Text = "Contact Last Name"
        Me.lvCustomersColumnHeader3.Width = 98
        '
        'ColumnHeader(5)
        '
        Me.lvCustomersColumnHeader4.Text = "City"
        Me.lvCustomersColumnHeader4.Width = 98
        '
        'ColumnHeader(6)
        '
        Me.lvCustomersColumnHeader5.Text = "State"
        Me.lvCustomersColumnHeader5.Width = 98
        '
        'ColumnHeader(7)
        '
        Me.lvCustomersColumnHeader6.Text = "Country"
        Me.lvCustomersColumnHeader6.Width = 98
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 16
        Me.Label3.Location = New System.Drawing.Point(243, 49)
        Me.Label3.Size = New System.Drawing.Size(98, 17)
        Me.Label3.Text = "Contact last name:"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 15
        Me.Label4.Location = New System.Drawing.Point(8, 16)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Company name:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 14
        Me.Label2.Location = New System.Drawing.Point(8, 49)
        Me.Label2.Size = New System.Drawing.Size(90, 17)
        Me.Label2.Text = "Contact name:"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame2
        '
        Me.Frame2.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtCustomerContact, Me.txtCustomerCompany, Me.Label5, Me.Label1})
        Me.Frame2.Name = "Frame2"
        Me.Frame2.TabIndex = 11
        Me.Frame2.Location = New System.Drawing.Point(8, 259)
        Me.Frame2.Size = New System.Drawing.Size(511, 50)
        Me.Frame2.Text = "Customer"
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtCustomerContact
        '
        Me.txtCustomerContact.Name = "txtCustomerContact"
        Me.txtCustomerContact.TabStop = False
        Me.txtCustomerContact.TabIndex = 20
        Me.txtCustomerContact.Location = New System.Drawing.Point(291, 16)
        Me.txtCustomerContact.Size = New System.Drawing.Size(211, 20)
        Me.txtCustomerContact.Text = ""
        Me.txtCustomerContact.BackColor = System.Drawing.SystemColors.Menu
        Me.txtCustomerContact.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustomerContact.ReadOnly = True
        '
        'txtCustomerCompany
        '
        Me.txtCustomerCompany.Name = "txtCustomerCompany"
        Me.txtCustomerCompany.TabStop = False
        Me.txtCustomerCompany.TabIndex = 19
        Me.txtCustomerCompany.Location = New System.Drawing.Point(73, 16)
        Me.txtCustomerCompany.Size = New System.Drawing.Size(147, 20)
        Me.txtCustomerCompany.Text = ""
        Me.txtCustomerCompany.BackColor = System.Drawing.SystemColors.Menu
        Me.txtCustomerCompany.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustomerCompany.ReadOnly = True
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 18
        Me.Label5.Location = New System.Drawing.Point(8, 16)
        Me.Label5.Size = New System.Drawing.Size(58, 17)
        Me.Label5.Text = "Company:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 17
        Me.Label1.Location = New System.Drawing.Point(235, 16)
        Me.Label1.Size = New System.Drawing.Size(58, 17)
        Me.Label1.Text = "Contact:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'dtPromised
        '
        Me.dtPromised.Name = "dtPromised"
        Me.dtPromised.TabIndex = 5
        Me.dtPromised.Location = New System.Drawing.Point(356, 324)
        Me.dtPromised.Size = New System.Drawing.Size(98, 20)
        '
        'Label13
        '
        Me.Label13.Name = "Label13"
        Me.Label13.TabIndex = 33
        Me.Label13.Location = New System.Drawing.Point(8, 550)
        Me.Label13.Size = New System.Drawing.Size(90, 17)
        Me.Label13.Text = "Line quantity:"
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label12
        '
        Me.Label12.Name = "Label12"
        Me.Label12.TabIndex = 32
        Me.Label12.Location = New System.Drawing.Point(8, 599)
        Me.Label12.Size = New System.Drawing.Size(90, 17)
        Me.Label12.Text = "Freight Charge:"
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label11
        '
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 30
        Me.Label11.Location = New System.Drawing.Point(8, 623)
        Me.Label11.Size = New System.Drawing.Size(90, 17)
        Me.Label11.Text = "Total:"
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label10
        '
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 28
        Me.Label10.Location = New System.Drawing.Point(275, 599)
        Me.Label10.Size = New System.Drawing.Size(90, 17)
        Me.Label10.Text = "Total Tax:"
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label9
        '
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 26
        Me.Label9.Location = New System.Drawing.Point(275, 623)
        Me.Label9.Size = New System.Drawing.Size(90, 17)
        Me.Label9.Text = "Sub Total:"
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 25
        Me.Label8.Location = New System.Drawing.Point(8, 574)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Sales Tax:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 22
        Me.Label7.Location = New System.Drawing.Point(259, 324)
        Me.Label7.Size = New System.Drawing.Size(106, 17)
        Me.Label7.Text = "Promised by date:"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 34
        Me.Label6.Location = New System.Drawing.Point(8, 324)
        Me.Label6.Size = New System.Drawing.Size(106, 17)
        Me.Label6.Text = "Required by date:"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmOrderRequest
        '
        Me.ClientSize = New System.Drawing.Size(529, 711)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtSubTotal, Me.txtTotal, Me.txtTotalTax, Me.txtFreightCharge, Me.txtSalesTax, Me.txtEntry, Me.fgProducts, Me.sbStatusBar, Me.dtRequired, Me.cmdSave, Me.cmdAddProducts, Me.cmdClose, Me.Frame1, Me.Frame2, Me.dtPromised, Me.Label13, Me.Label12, Me.Label11, Me.Label10, Me.Label9, Me.Label8, Me.Label7, Me.Label6})
        Me.Name = "frmOrderRequest"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Create Order"
        CType(Me.fgProducts, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.Frame2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Private currentCompanyName As String
    ' VBto upgrade warning: currentIdCustomer As Short	OnWrite(String)
    Private currentIdCustomer As Short
    Private currentContactName As String
    Private editingData As Boolean

    Private currentSubTotal As Double
    Private currentTotal As Double
    Private currentTax As Double
    Private currentFreightCharge As Double
    Private currentTotalTax As Double
    Private editingQuantity As Boolean


    Private Sub cmdAddProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdAddProducts.Click
        frmAddProductTo.Id = currentIdCustomer
        frmAddProductTo.ObjectReferred = "Customer " & txtCustomerCompany.Text & "|" & txtCustomerContact.Text
        frmAddProductTo.Table = "ProductsByCustomer"
        frmAddProductTo.ColumnName = "CustomerId"
        frmAddProductTo.LoadData()
        frmAddProductTo.ShowDialog()
        If frmAddProductTo.SavedChanges Then
            LoadProductsById()
        End If
    End Sub

'#Const defUse_txtName_Change = True
#If defUse_txtName_Change Then
    Private Sub txtName_Change()
        DoSearchCustomer()
    End Sub
#End If

    Private Sub DoSearchCustomer(Optional ByVal Id As String = "")
        Dim filter As String
        filter = ""
        'If Not IsEmpty(Id) Then
        If Id<>"" Then
            filter = "CustomerID = " & Id
        End If
        If txtCompanyName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter = "CompanyName LIKE '%" & txtCompanyName.Text & "%'"
        End If
        If txtContactName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ContactFirstName LIKE '%" & txtContactName.Text & "%'"
        End If
        If txtContactLastName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ContactLastName LIKE '%" & txtContactLastName.Text & "%'"
        End If

        If filter<>Nothing Then
            filter = "Where " & filter
        End If
        ExecuteSql("Select CustomerID, CompanyName, ContactFirstName, ContactLastName, City, StateOrProvince, 'Country/Region' From Customers " & filter)
        lvCustomers.Items.Clear()
        If rs.RecordCount=0 Then
            LogStatus("There are no records with the selected criteria", Me)
        Else
            Dim x As ListViewItem
            While  Not rs.EOF
                x = lvCustomers.Items.Add(Convert.ToString(rs.Fields(0).Value))
                For i = 1 To (rs.ColumnCount-1)
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                    End If
                Next i
                rs.MoveNext()
            End While
            If lvCustomers.Items.Count=1 Then
                lvCustomers.FocusedItem = lvCustomers.Items(1 - 1) : lvCustomers.FocusedItem.Selected = True
            End If
        End If
    End Sub

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdCustomers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCustomers.Click
        'On Error Resume Next
        frmCustomers.ShowDialog()
        txtCompanyName.Text = ""
        txtContactLastName.Text = ""
        txtContactName.Text = ""
        DoSearchCustomer(frmCustomers.CurrentCustomerID)
        frmCustomers.Hide()
    End Sub

    Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        cmdSave_Click()
    End Sub
    Public Sub cmdSave_Click()
        ' VBto upgrade warning: newOrderId As Short	OnWrite(Object)
        Dim newOrderId As Short

        Try ' On Error GoTo HandleError
            ExecuteSql("Select * from OrderRequests")
            rs.AddNew()
            rs.Fields("CustomerId").Value = currentIdCustomer
            rs.Fields("EmployeeId").Value = UserId
            rs.Fields("OrderDate").Value = CStr(Today)
            rs.Fields("RequiredByDate").Value = CStr(dtRequired.value)
            rs.Fields("PromisedByDate").Value = CStr(dtPromised.value)
            rs.Fields("FreightCharge").Value = currentFreightCharge
            rs.Fields("SalesTaxRate").Value = currentTax*0.01
            rs.Fields("Status").Value = "REQUESTED"
            rs.Update()
            newOrderId = rs.Fields("OrderID").Value


            For i = 1 To fgProducts.Rows-1
                If fgProducts.get_TextMatrix(i, 0)<>"0" Then
                    ExecuteSql("Insert into OrderRequestDetails (OrderID, ProductID, DateSold, Quantity, UnitPrice, SalePrice, LineTotal) Values (" & newOrderId & ", '" & fgProducts.get_TextMatrix(i, 1) & "', '" & vbFormat(Today, "mm/dd/yyyy") & "'," & fgProducts.get_TextMatrix(i, 0) & "," & fgProducts.get_TextMatrix(i, 3) & "," & fgProducts.get_TextMatrix(i, 4) & "," & fgProducts.get_TextMatrix(i, 4) & ")")

                    ExecuteSql("Update Products Set UnitsOnOrder = UnitsOnOrder + " & fgProducts.get_TextMatrix(i, 0) & " Where ProductId = '" & fgProducts.get_TextMatrix(i, 1) & "'")

                End If
            Next i

            editingData = False
            If MsgBox("Order added successfully" & vbCrLf & "Would you like to add a new order?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "New data")=DialogResult.Yes Then
                ClearFields()
            Else
                Close()
            End If
            Exit Sub
        Catch	' HandleError:
            ' ...
        End Try
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")
    End Sub

    Private Sub dtPromised_ValueChanged(ByVal sender As object, ByVal e As System.EventArgs) Handles dtPromised.ValueChanged
        editingData = True
    End Sub

    Private Sub dtRequired_ValueChanged(ByVal sender As object, ByVal e As System.EventArgs) Handles dtRequired.ValueChanged
        'If dtPromised.value < dtRequired.value Then
        '    dtPromised.value = dtRequired.value
        'End If
        editingData = True
    End Sub

    Private Sub MakeTextBoxVisible(ByVal txtBox As TextBox, ByVal grid As AxMSFlexGridLib.AxMSFlexGrid)
        With grid
            If .Row<0 Or .Col<0 Then Exit Sub
            txtBox.Text = .get_TextMatrix(.Row, .Col)
            txtBox.Enabled = True

            txtBox.Focus()
            Application.DoEvents()
            editingQuantity = True
        End With
    End Sub

    Private Sub fgProducts_ClickEvent(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgProducts.ClickEvent
        If fgProducts.Col<>0 Then Exit Sub
        MakeTextBoxVisible(txtEntry, fgProducts)
        SelectAll(txtEntry)
    End Sub

    Private Sub fgProducts_EnterCell(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgProducts.EnterCell
        SaveEdits()
    End Sub

    Private Sub fgProducts_KeyPressEvent(ByVal sender As Object, ByVal e As AxMSFlexGridLib.DMSFlexGridEvents_KeyPressEvent) Handles fgProducts.KeyPressEvent
        If fgProducts.Col<>0 Then Exit Sub
        Select Case e.keyAscii
            Case 46, 48 To 57:
                'Case 45, 46, 47, 48 To 59, 65 To 90, 97 To 122
                MakeTextBoxVisible(txtEntry, fgProducts)
                txtEntry.Text = Convert.ToString(Chr(e.keyAscii))
                txtEntry.SelectionStart = 1
        End Select
    End Sub

'#Const defUse_EditKeyCode = True
#If defUse_EditKeyCode Then
    ' VBto upgrade warning: txtBox As TextBox	OnWrite(String)
    Private Sub EditKeyCode(ByVal grid As AxMSFlexGridLib.AxMSFlexGrid, ByRef txtBox As TextBox, ByVal KeyCode As Short, ByVal Shift As Short)
        Select Case KeyCode
            Case 27:
                'ESC
                txtBox.Text = ""
                txtBox.Visible = False
                grid.Focus()
            Case 13:
                'Return
                grid.Focus()
            Case 37:
                'Left Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Col>grid.FixedCols Then
                    grid.Col -= 1
                End If
            Case 38:
                'Up Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Row>grid.FixedRows Then
                    grid.Row -= 1
                End If
            Case 39:
                'Right Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Col<grid.Cols-1 Then
                    grid.Col += 1
                End If
            Case 40:
                'Down Arrow
                grid.Focus()
                Application.DoEvents()
                If grid.Row<grid.Rows-1 Then
                    grid.Row += 1
                End If
        End Select
    End Sub
#End If

    Private Sub txtEntry_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtEntry.Leave
        SaveEdits()
    End Sub


    Private Sub fgProducts_LeaveCell(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgProducts.LeaveCell
        If (editingQuantity) Then
            SaveEdits()
        End If
    End Sub

    Private Sub SaveEdits()
        Dim lineQuantity As Double, lineUnitPrice As Double, linePrice As Double
        Dim previousLinePrice As Double
        If  Not editingQuantity Or  Not ValidateTextBoxDouble(txtEntry, Me) Or  Not ValidateTextDouble(fgProducts.get_TextMatrix(fgProducts.Row, 4), Me) Then
            Exit Sub
        End If
        previousLinePrice = DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4))
        fgProducts.set_TextMatrix(fgProducts.Row, fgProducts.Col, txtEntry.Text)
        lineQuantity = DoubleValue(txtEntry.Text)
        lineUnitPrice = DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 3))
        previousLinePrice = DoubleValue(fgProducts.get_TextMatrix(fgProducts.Row, 4))
        linePrice = CDbl(lineQuantity*lineUnitPrice)
        fgProducts.set_TextMatrix(fgProducts.Row, 4, linePrice)
        ReCalculateTotals(previousLinePrice, linePrice)
        editingQuantity = False
        txtEntry.Enabled = False
        txtEntry.Text = ""

        editingData = True
    End Sub

    Private Sub ReCalculateTotals(ByVal previous As Double, ByVal current As Double)
        currentSubTotal += -previous+current
        currentTotalTax = currentSubTotal*currentTax*0.01
        currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax
        txtSubTotal.Text = vbFormat(currentSubTotal, "#,##0.00")
        txtTotalTax.Text = vbFormat(currentTotalTax, "#,##0.00")
        txtTotal.Text = vbFormat(currentTotal, "#,##0.00")
    End Sub

    ' VBto upgrade warning: Cancel As Short	OnWrite(Boolean)
    Private Sub Form_QueryUnload(ByRef Cancel As Short, ByVal UnloadMode As Short)
        If editingData Then
            Dim res As DialogResult
            res = MsgBox("Do you want to save the edited data?", MsgBoxStyle.YesNoCancel Or MsgBoxStyle.Question, "Save data")
            If res=DialogResult.Yes Then
                cmdSave_Click()
            ElseIf res<>DialogResult.No Then
                Cancel = True
            End If
        End If
    End Sub

    Private Sub frmOrderRequest_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_QueryUnload(Cancel, 0)
        If Cancel <> 0 Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub frmOrderRequest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        editingData = False
        ClearFields()
    End Sub

    Private Sub lvCustomers_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvCustomers.SelectedIndexChanged
        Dim Item As ListViewItem = CType(sender, ListView).FocusedItem
        If Item Is Nothing Then Exit Sub

        RetrieveDataCustomer()
    End Sub

    Private Sub RetrieveDataCustomer()
        If editingData Then
            If MsgBox("Do you want to cancel previous edited data?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Data edition")<>DialogResult.Yes Then
                Exit Sub
            End If
        End If

        If lvCustomers.FocusedItem.Text<>Nothing Then
            With lvCustomers.FocusedItem
                currentIdCustomer = lvCustomers.FocusedItem.Text
                currentCompanyName = .SubItems(1).Text
                currentContactName = .SubItems(2).Text & " " & .SubItems(3).Text
            End With
            txtCustomerCompany.Text = currentCompanyName
            txtCustomerContact.Text = currentContactName
            editingData = False
        End If
        LoadProductsById()
        cmdSave.Enabled = True
        cmdAddProducts.Enabled = True
        dtRequired.Enabled = True
        dtPromised.Enabled = True

    End Sub

    Private Sub LoadProductsById()
        Dim Table As String
        Dim ColumnName As String
        Dim Id As Short
        Table = "ProductsByCustomer"
        ColumnName = "CustomerId"
        Id = currentIdCustomer

        ExecuteSql("Select p.ProductID, p.ProductName, p.UnitPrice, p.UnitsInStock, p.UnitsOnOrder, p.QuantityPerUnit, p.Unit from Products as p, " & Table & " as pb Where pb." & ColumnName & " = " & Id & " And pb.ProductId = p.ProductId")

        'lvProducts.ListItems.Clear
        'If rs.RecordCount > 0 Then
        '    With rs
        '        While Not .EOF
        '            Set x = lvProducts.ListItems.Add(, , 0)
        '            For i = 1 To 5
        '                If Not IsEmpty(.Fields(i - 1)) Then
        '                    x.SubItems(i) = .Fields(i - 1)
        '                End If
        '            Next i
        '            x.SubItems(6) = .Fields(5) & .Fields(6)
        '            .MoveNext
        '        Wend
        '    End With
        'End If

        Dim lng As Integer
        Dim intLoopCount As Short
        Const SCROOL_WIDTH As Short = 320
        With fgProducts
            .Cols = 8
            .FixedCols = 0
            .Rows = 0
            .AddItem("Quantity" & vbTab & "Code" & vbTab & "Product" & vbTab & "UnitPrice" & vbTab & "Price" & vbTab & "Existence" & vbTab & "Ordered" & vbTab & "Quantity per unit")
            .Rows = rs.RecordCount+1
            If .Rows=1 Then .FixedRows = 0 Else .FixedRows = 1
            Dim i As Short
            Dim j As Short
            i = 1
            While  Not rs.EOF
                .set_TextMatrix(i, 0, "0")
                For j = 1 To 6
                    If j=4 Then
                        .set_TextMatrix(i, j, "0")
                    ElseIf j<4 Then
                        .set_TextMatrix(i, j, Convert.ToString(rs.Fields(j-1).Value))
                    Else
                        .set_TextMatrix(i, j, Convert.ToString(rs.Fields(j-2).Value))
                    End If
                Next j
                .set_TextMatrix(i, 7, Convert.ToString(rs.Fields(5).Value) & Convert.ToString(rs.Fields(6).Value))
                rs.MoveNext()
                i += 1
            End While
        End With
    End Sub

'#Const defUse_lvProducts_ItemCheck = True
#If defUse_lvProducts_ItemCheck Then
    Private Sub lvProducts_ItemCheck(ByVal Item As ListViewItem)
        If Item.Checked Then
            Item.Text = "1"
        Else
            Item.Text = "0"
        End If
    End Sub
#End If

    Private Sub txtCompanyName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCompanyName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchCustomer()
    End Sub

    Private Sub txtContactLastName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactLastName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchCustomer()
    End Sub

    Private Sub txtContactName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchCustomer()
    End Sub

    Private Sub ClearFields()

        fgProducts.Rows = 0
        fgProducts.Cols = 0

        currentSubTotal = 0
        currentTotal = 0
        currentTax = 0
        currentTotalTax = 0
        currentFreightCharge = 0

        txtSubTotal.Text = ""
        txtTotal.Text = ""
        txtTotalTax.Text = ""
        txtSalesTax.Text = ""
        txtFreightCharge.Text = ""

        txtCompanyName.Text = ""
        txtContactLastName.Text = ""
        txtContactName.Text = ""
        txtCustomerContact.Text = ""
        txtCustomerCompany.Text = ""
        cmdSave.Enabled = False
        cmdAddProducts.Enabled = False
        dtRequired.Enabled = False
        dtPromised.Enabled = False
        'txtCompanyName.SetFocus
        'txtCompanyName.SetFocus
        ReCalculateTotals(0, 0)
        editingData = False
    End Sub

    Private Sub txtFreightCharge_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtFreightCharge.TextChanged
        If Not sender.Created() Then Exit Sub
        currentFreightCharge = DoubleValue(txtFreightCharge.Text)
        ReCalculateTotals(0, 0)
        editingData = True
    End Sub

    Private Sub txtFreightCharge_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtFreightCharge.KeyPress
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        Select Case KeyAscii
            Case Keys.D0 To Keys.D9:
            Case Keys.Back, Keys.Clear, Keys.Delete:
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Tab:

            Case Else
                KeyAscii = 0
                Beep()
        End Select

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub

    Private Sub txtSalesTax_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtSalesTax.TextChanged
        If Not sender.Created() Then Exit Sub
        currentTax = DoubleValue(txtSalesTax.Text)
        ReCalculateTotals(0, 0)
        editingData = True
    End Sub

    Private Sub txtSalesTax_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtSalesTax.KeyPress
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        Select Case KeyAscii
            Case Keys.D0 To Keys.D9:
            Case Keys.Back, Keys.Clear, Keys.Delete:
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Tab:

            Case Else
                KeyAscii = 0
                Beep()
        End Select

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub

End Class