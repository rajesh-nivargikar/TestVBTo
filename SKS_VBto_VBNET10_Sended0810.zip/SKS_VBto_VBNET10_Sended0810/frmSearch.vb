
Imports System
Imports Microsoft.VisualBasic

Public Class frmSearch
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdSearch As System.Windows.Forms.Button
    Friend WithEvents ctrlLiner1 As System.Windows.Forms.PictureBox
    Friend WithEvents cboSrchBy As System.Windows.Forms.ComboBox
    Friend WithEvents txtSrchStr As System.Windows.Forms.TextBox
    Friend WithEvents Image3 As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents lblSrchBy As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmSearch))
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdSearch = New System.Windows.Forms.Button()
        Me.ctrlLiner1 = New System.Windows.Forms.PictureBox()
        Me.cboSrchBy = New System.Windows.Forms.ComboBox()
        Me.txtSrchStr = New System.Windows.Forms.TextBox()
        Me.Image3 = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.lblSrchBy = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 8
        Me.cmdClose.Location = New System.Drawing.Point(275, 105)
        Me.cmdClose.Size = New System.Drawing.Size(82, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdSearch
        '
        Me.cmdSearch.Name = "cmdSearch"
        Me.cmdSearch.TabIndex = 7
        Me.cmdSearch.Location = New System.Drawing.Point(186, 105)
        Me.cmdSearch.Size = New System.Drawing.Size(82, 25)
        Me.cmdSearch.Text = "&Search"
        Me.cmdSearch.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSearch.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'ctrlLiner1
        '
        Me.ctrlLiner1.Name = "ctrlLiner1"
        Me.ctrlLiner1.TabIndex = 6
        Me.ctrlLiner1.Location = New System.Drawing.Point(0, 57)
        Me.ctrlLiner1.Size = New System.Drawing.Size(389, 2)
        Me.ctrlLiner1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.ctrlLiner1.BackColor = System.Drawing.SystemColors.Control
        '
        'cboSrchBy
        '
        Me.cboSrchBy.Name = "cboSrchBy"
        Me.cboSrchBy.TabIndex = 3
        Me.cboSrchBy.Location = New System.Drawing.Point(210, 146)
        Me.cboSrchBy.Size = New System.Drawing.Size(147, 21)
        Me.cboSrchBy.Text = ""
        Me.cboSrchBy.BackColor = System.Drawing.SystemColors.Window
        Me.cboSrchBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cboSrchBy.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        '
        'txtSrchStr
        '
        Me.txtSrchStr.Name = "txtSrchStr"
        Me.txtSrchStr.TabIndex = 0
        Me.txtSrchStr.Location = New System.Drawing.Point(138, 73)
        Me.txtSrchStr.Size = New System.Drawing.Size(219, 19)
        Me.txtSrchStr.Text = ""
        Me.txtSrchStr.BackColor = System.Drawing.SystemColors.Window
        Me.txtSrchStr.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'Image3
        '
        Me.Image3.Name = "Image3"
        Me.Image3.Location = New System.Drawing.Point(8, 8)
        Me.Image3.Size = New System.Drawing.Size(16, 16)
        Me.Image3.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Image3.BackColor = System.Drawing.SystemColors.Control
        Me.Image3.Image = CType(Resources.GetObject("Image3.Image"), System.Drawing.Bitmap)
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 2
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(126, 146)
        Me.Label1.Size = New System.Drawing.Size(63, 13)
        Me.Label1.Text = "Search by:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label1.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'lblSrchBy
        '
        Me.lblSrchBy.Name = "lblSrchBy"
        Me.lblSrchBy.TabIndex = 1
        Me.lblSrchBy.AutoSize = True
        Me.lblSrchBy.Location = New System.Drawing.Point(7, 73)
        Me.lblSrchBy.Size = New System.Drawing.Size(117, 13)
        Me.lblSrchBy.Text = "Field"
        Me.lblSrchBy.BackColor = System.Drawing.SystemColors.Control
        Me.lblSrchBy.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.lblSrchBy.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.lblSrchBy.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Label20
        '
        Me.Label20.Name = "Label20"
        Me.Label20.TabIndex = 5
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(50, 32)
        Me.Label20.Size = New System.Drawing.Size(120, 13)
        Me.Label20.Text = "Search for a specific item"
        Me.Label20.BackColor = System.Drawing.Color.Transparent
        Me.Label20.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        '
        'Label19
        '
        Me.Label19.Name = "Label19"
        Me.Label19.TabIndex = 4
        Me.Label19.AutoSize = True
        Me.Label19.Location = New System.Drawing.Point(50, 8)
        Me.Label19.Size = New System.Drawing.Size(51, 16)
        Me.Label19.Text = "Search"
        Me.Label19.BackColor = System.Drawing.Color.Transparent
        Me.Label19.ForeColor = System.Drawing.Color.FromArgb(CType(64, Byte), CType(64, Byte), CType(64, Byte))
        Me.Label19.TextAlign = System.Drawing.ContentAlignment.TopRight
        Me.Label19.Font = New System.Drawing.Font("MS Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'frmSearch
        '
        Me.ClientSize = New System.Drawing.Size(382, 175)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdClose, Me.cmdSearch, Me.ctrlLiner1, Me.cboSrchBy, Me.txtSrchStr, Me.Image3, Me.Label1, Me.lblSrchBy, Me.Label20, Me.Label19})
        Me.Name = "frmSearch"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ShowInTaskbar = False
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Icon = CType(Resources.GetObject("frmSearch.Icon"), System.Drawing.Icon)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Search"
        Me.Label1.ResumeLayout(False)
        Me.lblSrchBy.ResumeLayout(False)
        Me.Label19.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Dim SearchTable As String = ""
    Private Sub cboSrchBy_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cboSrchBy.SelectedIndexChanged
        lblSrchBy.Text = cboSrchBy.Text
    End Sub

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub


    Public Sub Search(ByVal Table As String, ByVal fieldToSearch As String, ByVal itemToSearch As String)
        If itemToSearch<>Nothing Then
            Label20.Text = "Search for a " & itemToSearch
        End If
        SearchTable = Table
        ExecuteSql("Select Top 1 * from " & Table)
        For i = 0 To (rs.ColumnCount-1)
            cboSrchBy.Items.Add(rs.Fields(i).Name)
        Next i
        cboSrchBy.Text = fieldToSearch
    End Sub

    Private Sub cmdSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSearch.Click
        If Strings.Right(txtSrchStr.Text, 1)="'" Then
            txtSrchStr.Text = String.Empty
        End If
        Dim txtToSearch As String

        If Trim(txtSrchStr.Text)<>Nothing Then
            txtToSearch = txtSrchStr.Text
        Else
            txtToSearch = "%"
        End If
        If SearchTable="Customers" Then
            SearchCriteriaCustomers(lblSrchBy.Text, txtToSearch)
        ElseIf SearchTable="Products" Then
            SearchCriteriaProducts(lblSrchBy.Text, txtToSearch)
        ElseIf SearchTable="Providers" Then
            SearchCriteriaProviders(lblSrchBy.Text, txtToSearch)
        End If
    End Sub

    ' ''
    Public Sub SearchCriteriaCustomers(ByVal field As String, ByVal value As String)
        ExecuteSql("Select * from Customers where " & field & " LIKE '" & value & "%'")
        If rs.RecordCount=0 Then
            MsgBox("There are no records with the selected criteria", MsgBoxStyle.Information, "Search")
        Else
            LogStatus("There are " & rs.RecordCount & " that meet with the selected criteria")
            frmCustomers.dcCustomers.Recordset = rs
        End If
    End Sub

    Public Sub SearchCriteriaProducts(ByVal field As String, ByVal value As String)
        ExecuteSql("Select * from Products where " & field & " LIKE '" & value & "%'")
        If rs.RecordCount=0 Then
            MsgBox("There are no records with the selected criteria", MsgBoxStyle.Information, "Search")
        Else
            frmProducts.dcProducts.Recordset = rs
        End If
    End Sub

    Public Sub SearchCriteriaProviders(ByVal field As String, ByVal value As String)
        ExecuteSql("Select * from Providers where " & field & " LIKE '" & value & "%'")
        If rs.RecordCount=0 Then
            MsgBox("There are no records with the selected criteria", MsgBoxStyle.Information, "Search")
        Else
            LogStatus("There are " & rs.RecordCount & " that meet with the selected criteria")
            frmProviders.dcProviders.Recordset = rs
        End If
    End Sub

End Class