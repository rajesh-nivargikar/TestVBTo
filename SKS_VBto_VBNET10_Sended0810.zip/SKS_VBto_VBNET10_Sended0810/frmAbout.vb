Public Class frmAbout
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents Line1 As VBtoFigures.LineArray
    Friend WithEvents picIcon As System.Windows.Forms.PictureBox
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents Line1_1 As VBtoFigures.Line
    Friend WithEvents lblDescription As System.Windows.Forms.Label
    Friend WithEvents lblTitle As System.Windows.Forms.Label
    Friend WithEvents Line1_0 As VBtoFigures.Line
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents lblDisclaimer As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAbout))
        Me.components = New System.ComponentModel.Container()
        Me.Line1 = New VBtoFigures.LineArray(components)
        Me.picIcon = New System.Windows.Forms.PictureBox()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.Line1_1 = New VBtoFigures.Line()
        Me.lblDescription = New System.Windows.Forms.Label()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.Line1_0 = New VBtoFigures.Line()
        Me.lblVersion = New System.Windows.Forms.Label()
        Me.lblDisclaimer = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        CType(Me.Line1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'picIcon
        '
        Me.picIcon.Name = "picIcon"
        Me.picIcon.TabIndex = 1
        Me.picIcon.Location = New System.Drawing.Point(16, 16)
        Me.picIcon.Size = New System.Drawing.Size(133, 133)
        Me.picIcon.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.picIcon.BackColor = System.Drawing.SystemColors.Control
        Me.picIcon.Image = CType(Resources.GetObject("picIcon.Image"), System.Drawing.Bitmap)
        Me.picIcon.SizeMode = System.Windows.Forms.PictureBoxSizeMode.AutoSize
        '
        'cmdOK
        '
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.TabIndex = 0
        Me.cmdOK.Location = New System.Drawing.Point(275, 210)
        Me.cmdOK.Size = New System.Drawing.Size(109, 23)
        Me.cmdOK.Text = "OK"
        Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Line1_1
        '
        Me.Line1_1.Name = "Line1_1"
        Me.Line1_1.LineColor = System.Drawing.Color.FromArgb(CType(128, Byte), CType(128, Byte), CType(128, Byte))
        Me.Line1_1.X1 = 6
        Me.Line1_1.Y1 = 165
        Me.Line1_1.X2 = 380
        Me.Line1_1.Y2 = 165
        Me.Line1_1.Location = New System.Drawing.Point(6, 165)
        Me.Line1_1.Size = New System.Drawing.Size(374, 1)
        '
        'lblDescription
        '
        Me.lblDescription.Name = "lblDescription"
        Me.lblDescription.TabIndex = 2
        Me.lblDescription.AutoSize = True
        Me.lblDescription.Location = New System.Drawing.Point(165, 81)
        Me.lblDescription.Size = New System.Drawing.Size(201, 13)
        Me.lblDescription.Text = "Order Processing Software by Mobilize.net"
        Me.lblDescription.BackColor = System.Drawing.SystemColors.Control
        Me.lblDescription.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(0, Byte))
        '
        'lblTitle
        '
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Location = New System.Drawing.Point(165, 24)
        Me.lblTitle.Size = New System.Drawing.Size(123, 13)
        Me.lblTitle.Text = "Salmon King Seafood"
        Me.lblTitle.BackColor = System.Drawing.SystemColors.Control
        Me.lblTitle.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(0, Byte))
        Me.lblTitle.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Line1_0
        '
        Me.Line1_0.Name = "Line1_0"
        Me.Line1_0.LineColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(255, Byte))
        Me.Line1_0.LineWidth = 2
        Me.Line1_0.X1 = 7
        Me.Line1_0.Y1 = 166
        Me.Line1_0.X2 = 380
        Me.Line1_0.Y2 = 166
        Me.Line1_0.Location = New System.Drawing.Point(7, 166)
        Me.Line1_0.Size = New System.Drawing.Size(373, 2)
        '
        'lblVersion
        '
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.TabIndex = 5
        Me.lblVersion.AutoSize = True
        Me.lblVersion.Location = New System.Drawing.Point(165, 57)
        Me.lblVersion.Size = New System.Drawing.Size(139, 13)
        Me.lblVersion.Text = "Version: Mobilize - WebMAP "
        Me.lblVersion.BackColor = System.Drawing.SystemColors.Control
        Me.lblVersion.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblDisclaimer
        '
        Me.lblDisclaimer.Name = "lblDisclaimer"
        Me.lblDisclaimer.TabIndex = 3
        Me.lblDisclaimer.AutoSize = True
        Me.lblDisclaimer.Location = New System.Drawing.Point(17, 177)
        Me.lblDisclaimer.Size = New System.Drawing.Size(277, 13)
        Me.lblDisclaimer.Text = "Warning: This product is protected by copyright laws 2016"
        Me.lblDisclaimer.BackColor = System.Drawing.SystemColors.Control
        Me.lblDisclaimer.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(0, Byte))
        '
        'frmAbout
        '
        Me.ClientSize = New System.Drawing.Size(398, 240)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.picIcon, Me.cmdOK, Me.Line1_1, Me.lblDescription, Me.lblTitle, Me.Line1_0, Me.lblVersion, Me.lblDisclaimer})
        Me.Name = "frmAbout"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ShowInTaskbar = False
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "About SKS Sales agent"
        Me.AcceptButton = cmdOK
        Me.Line1.SetIndex(Line1_1, CType(1, Short))
        Me.Line1.SetIndex(Line1_0, CType(0, Short))
        CType(Me.Line1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.lblTitle.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    ' Reg Key Security Options...
    Const READ_CONTROL As Integer = &H20000
    Const KEY_QUERY_VALUE As Short = &H1
    Const KEY_SET_VALUE As Short = &H2
    Const KEY_CREATE_SUB_KEY As Short = &H4
    Const KEY_ENUMERATE_SUB_KEYS As Short = &H8
    Const KEY_NOTIFY As Short = &H10
    Const KEY_CREATE_LINK As Short = &H20
    Const KEY_ALL_ACCESS As Integer = KEY_QUERY_VALUE+KEY_SET_VALUE+KEY_CREATE_SUB_KEY+KEY_ENUMERATE_SUB_KEYS+KEY_NOTIFY+KEY_CREATE_LINK+READ_CONTROL

    ' Reg Key ROOT Types...
    Const HKEY_LOCAL_MACHINE As Integer = &H80000002
    Const ERROR_SUCCESS As Short = 0
    Const REG_SZ As Short = 1 ' Unicode nul terminated string
    Const REG_DWORD As Short = 4 ' 32-bit number


    Private Sub cmdOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        Close()
    End Sub

    Private Sub frmAbout_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Me.Text = "About " & My.Application.Info.AssemblyName
        'lblVersion.Caption = "Version " & App.Major & "." & App.Minor & "." & App.Revision
        lblTitle.Text = My.Application.Info.AssemblyName
    End Sub


End Class