'Option Strict Off
'Option Explicit On

Imports System
Imports System.Windows.Forms

Public Module modMain


	'=========================================================

    Public CurrentUserAdmin As Boolean
    ' VBto upgrade warning: UserFullname As String	OnWrite(Object, String)
    Public UserFullname As String
    ' VBto upgrade warning: UserLevel As String	OnWrite(Object, String)
    Public UserLevel As String
    Public UserId As String = ""

    Public ConnectionString As String = ""

    Public DetectionType As Short
    Public n As Double, i As Integer, s As String, d As Date
    Public msg As String
    Public ImgName As String, ImgSrc As String





    Public Sub Main()
        ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Orders.mdb;Persist Security Info=False"

        OpenConnection()
        CurrentUserAdmin = True
        UserFullname = "Allan Cantillo"
        UserLevel = "Administrator"
        UserId = "acantillo"
        frmMain.Show()
    End Sub

    ' VBto upgrade warning: frm As Form	OnWrite(Form, frmAdjustStockManual, frmOrderRequest, frmAddStockManual, frmOrderReception, frmAddProductTo, frmReceptionApproval, frmActionOrderReception, frmActionOrderRequest, frmRequestApproval)
    Public Sub LogStatus(ByVal message As String, Optional ByVal frm As Form = Nothing)
        Dim sb As StatusBar
        sb = Nothing
        frmMain.sbStatusBar.Panels(1 - 1).Text = message
        If  Not (frm Is Nothing) Then
            If frm Is frmAdjustStockManual Then
                sb = frmAdjustStockManual.sbStatusBar
            ElseIf frm Is frmActionOrderReception Then
                sb = frmActionOrderReception.sbStatusBar
            ElseIf frm Is frmActionOrderRequest Then
                sb = frmActionOrderRequest.sbStatusBar
            ElseIf frm Is frmAddStockManual Then
                sb = frmAddStockManual.sbStatusBar
            ElseIf frm Is frmReceptionApproval Then
                sb = frmReceptionApproval.sbStatusBar
            ElseIf frm Is frmOrderReception Then
                sb = frmOrderReception.sbStatusBar
            ElseIf frm Is frmOrderRequest Then
                sb = frmOrderRequest.sbStatusBar
            ElseIf frm Is frmRequestApproval Then
                sb = frmRequestApproval.sbStatusBar
            End If
            If  Not (sb Is Nothing) Then
                If  Not (sb.Panels(1 - 1) Is Nothing) Then
                    sb.Panels(1 - 1).Text = message
                End If
            End If
        End If
    End Sub

    ' VBto upgrade warning: frm As Form	OnWrite(frmAdjustStockManual, frmAddStockManual)
    Public Sub ClearLogStatus(Optional ByVal frm As Form = Nothing)
        LogStatus("", frm)
    End Sub




End Module