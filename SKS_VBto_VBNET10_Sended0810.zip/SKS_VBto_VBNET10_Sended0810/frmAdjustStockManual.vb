
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmAdjustStockManual
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtValues As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents txtStockID As System.Windows.Forms.TextBox
    Friend WithEvents txtOriginalPrice As System.Windows.Forms.TextBox
    Friend WithEvents txtValues_0 As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantityPerUnit As System.Windows.Forms.TextBox
    Friend WithEvents txtProductName As System.Windows.Forms.TextBox
    Friend WithEvents txtUnit As System.Windows.Forms.TextBox
    Friend WithEvents txtValues_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtOriginalQuantity As System.Windows.Forms.TextBox
    Friend WithEvents Frame3 As System.Windows.Forms.GroupBox
    Friend WithEvents lvStocks As System.Windows.Forms.ListView
    Friend WithEvents lvStocksColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvStocksColumnHeader7 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents cmdProducts As System.Windows.Forms.Button
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents lvProducts As System.Windows.Forms.ListView
    Friend WithEvents lvProductsColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents lblNewQuantity As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents lblCurrentQuantity As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAdjustStockManual))
        Me.components = New System.ComponentModel.Container()
        Me.txtValues = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.txtStockID = New System.Windows.Forms.TextBox()
        Me.txtOriginalPrice = New System.Windows.Forms.TextBox()
        Me.txtValues_0 = New System.Windows.Forms.TextBox()
        Me.txtQuantityPerUnit = New System.Windows.Forms.TextBox()
        Me.txtProductName = New System.Windows.Forms.TextBox()
        Me.txtUnit = New System.Windows.Forms.TextBox()
        Me.txtValues_1 = New System.Windows.Forms.TextBox()
        Me.txtOriginalQuantity = New System.Windows.Forms.TextBox()
        Me.Frame3 = New System.Windows.Forms.GroupBox()
        Me.lvStocks = New System.Windows.Forms.ListView()
        Me.lvStocksColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.lvStocksColumnHeader7 = New System.Windows.Forms.ColumnHeader()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.cmdProducts = New System.Windows.Forms.Button()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.lvProducts = New System.Windows.Forms.ListView()
        Me.lvProductsColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.lblNewQuantity = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.lblCurrentQuantity = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        CType(Me.txtValues, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 28
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 544)
        Me.sbStatusBar.Size = New System.Drawing.Size(431, 25)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 429
        '
        'txtStockID
        '
        Me.txtStockID.Name = "txtStockID"
        Me.txtStockID.TabStop = False
        Me.txtStockID.TabIndex = 26
        Me.txtStockID.Location = New System.Drawing.Point(97, 378)
        Me.txtStockID.Size = New System.Drawing.Size(82, 20)
        Me.txtStockID.Text = ""
        Me.txtStockID.BackColor = System.Drawing.SystemColors.Menu
        Me.txtStockID.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtOriginalPrice
        '
        Me.txtOriginalPrice.Name = "txtOriginalPrice"
        Me.txtOriginalPrice.TabStop = False
        Me.txtOriginalPrice.TabIndex = 25
        Me.txtOriginalPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtOriginalPrice.Location = New System.Drawing.Point(97, 407)
        Me.txtOriginalPrice.Size = New System.Drawing.Size(82, 20)
        Me.txtOriginalPrice.Text = ""
        Me.txtOriginalPrice.BackColor = System.Drawing.SystemColors.Menu
        Me.txtOriginalPrice.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOriginalPrice.ReadOnly = True
        '
        'txtValues_0
        '
        Me.txtValues_0.Name = "txtValues_0"
        Me.txtValues_0.TabIndex = 4
        Me.txtValues_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtValues_0.Location = New System.Drawing.Point(332, 407)
        Me.txtValues_0.Size = New System.Drawing.Size(82, 20)
        Me.txtValues_0.Text = ""
        Me.txtValues_0.BackColor = System.Drawing.SystemColors.Window
        Me.txtValues_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValues_0.ReadOnly = True
        '
        'txtQuantityPerUnit
        '
        Me.txtQuantityPerUnit.Name = "txtQuantityPerUnit"
        Me.txtQuantityPerUnit.TabStop = False
        Me.txtQuantityPerUnit.TabIndex = 21
        Me.txtQuantityPerUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtQuantityPerUnit.Location = New System.Drawing.Point(332, 378)
        Me.txtQuantityPerUnit.Size = New System.Drawing.Size(82, 20)
        Me.txtQuantityPerUnit.Text = ""
        Me.txtQuantityPerUnit.BackColor = System.Drawing.SystemColors.Menu
        Me.txtQuantityPerUnit.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantityPerUnit.ReadOnly = True
        '
        'txtProductName
        '
        Me.txtProductName.Name = "txtProductName"
        Me.txtProductName.TabStop = False
        Me.txtProductName.TabIndex = 20
        Me.txtProductName.Location = New System.Drawing.Point(97, 348)
        Me.txtProductName.Size = New System.Drawing.Size(147, 20)
        Me.txtProductName.Text = ""
        Me.txtProductName.BackColor = System.Drawing.SystemColors.Menu
        Me.txtProductName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProductName.ReadOnly = True
        '
        'txtUnit
        '
        Me.txtUnit.Name = "txtUnit"
        Me.txtUnit.TabStop = False
        Me.txtUnit.TabIndex = 19
        Me.txtUnit.Location = New System.Drawing.Point(332, 348)
        Me.txtUnit.Size = New System.Drawing.Size(82, 20)
        Me.txtUnit.Text = ""
        Me.txtUnit.BackColor = System.Drawing.SystemColors.Menu
        Me.txtUnit.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUnit.ReadOnly = True
        '
        'txtValues_1
        '
        Me.txtValues_1.Name = "txtValues_1"
        Me.txtValues_1.TabIndex = 5
        Me.txtValues_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtValues_1.Location = New System.Drawing.Point(332, 437)
        Me.txtValues_1.Size = New System.Drawing.Size(82, 20)
        Me.txtValues_1.Text = ""
        Me.txtValues_1.BackColor = System.Drawing.SystemColors.Window
        Me.txtValues_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValues_1.ReadOnly = True
        '
        'txtOriginalQuantity
        '
        Me.txtOriginalQuantity.Name = "txtOriginalQuantity"
        Me.txtOriginalQuantity.TabStop = False
        Me.txtOriginalQuantity.TabIndex = 14
        Me.txtOriginalQuantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtOriginalQuantity.Location = New System.Drawing.Point(97, 437)
        Me.txtOriginalQuantity.Size = New System.Drawing.Size(82, 20)
        Me.txtOriginalQuantity.Text = ""
        Me.txtOriginalQuantity.BackColor = System.Drawing.SystemColors.Menu
        Me.txtOriginalQuantity.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOriginalQuantity.ReadOnly = True
        '
        'Frame3
        '
        Me.Frame3.Controls.AddRange(New System.Windows.Forms.Control() {Me.lvStocks})
        Me.Frame3.Name = "Frame3"
        Me.Frame3.TabIndex = 13
        Me.Frame3.Location = New System.Drawing.Point(8, 202)
        Me.Frame3.Size = New System.Drawing.Size(414, 139)
        Me.Frame3.Text = "Stocks for the product "
        Me.Frame3.BackColor = System.Drawing.SystemColors.Control
        Me.Frame3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lvStocks
        '
        Me.lvStocks.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvStocksColumnHeader0, Me.lvStocksColumnHeader1, Me.lvStocksColumnHeader2, Me.lvStocksColumnHeader3, Me.lvStocksColumnHeader4, Me.lvStocksColumnHeader5, Me.lvStocksColumnHeader6, Me.lvStocksColumnHeader7})
        Me.lvStocks.Name = "lvStocks"
        Me.lvStocks.TabIndex = 3
        Me.lvStocks.Location = New System.Drawing.Point(8, 16)
        Me.lvStocks.Size = New System.Drawing.Size(397, 114)
        Me.lvStocks.BackColor = System.Drawing.SystemColors.Window
        Me.lvStocks.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvStocks.View = System.Windows.Forms.View.Details
        Me.lvStocks.MultiSelect = False
        Me.lvStocks.GridLines = True
        Me.lvStocks.FullRowSelect = True
        Me.lvStocks.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvStocks.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvStocksColumnHeader0.Text = "Stock ID"
        Me.lvStocksColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvStocksColumnHeader1.Text = "Current Stock"
        Me.lvStocksColumnHeader1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvStocksColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvStocksColumnHeader2.Text = "Initial Stock"
        Me.lvStocksColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvStocksColumnHeader2.Width = 98
        '
        'ColumnHeader(4)
        '
        Me.lvStocksColumnHeader3.Text = "Price"
        Me.lvStocksColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvStocksColumnHeader3.Width = 98
        '
        'ColumnHeader(5)
        '
        Me.lvStocksColumnHeader4.Text = "Stock Price"
        Me.lvStocksColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvStocksColumnHeader4.Width = 98
        '
        'ColumnHeader(6)
        '
        Me.lvStocksColumnHeader5.Text = "Created"
        Me.lvStocksColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvStocksColumnHeader5.Width = 98
        '
        'ColumnHeader(7)
        '
        Me.lvStocksColumnHeader6.Text = "Modified"
        Me.lvStocksColumnHeader6.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvStocksColumnHeader6.Width = 98
        '
        'ColumnHeader(8)
        '
        Me.lvStocksColumnHeader7.Text = "User"
        Me.lvStocksColumnHeader7.Width = 98
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtCode, Me.txtName, Me.cmdProducts, Me.Label5, Me.Label4})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 9
        Me.Frame1.Location = New System.Drawing.Point(8, 32)
        Me.Frame1.Size = New System.Drawing.Size(414, 66)
        Me.Frame1.Text = "Search product "
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtCode
        '
        Me.txtCode.Name = "txtCode"
        Me.txtCode.TabIndex = 0
        Me.txtCode.Location = New System.Drawing.Point(113, 16)
        Me.txtCode.Size = New System.Drawing.Size(98, 20)
        Me.txtCode.Text = ""
        Me.txtCode.BackColor = System.Drawing.SystemColors.Window
        Me.txtCode.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtName
        '
        Me.txtName.Name = "txtName"
        Me.txtName.TabIndex = 1
        Me.txtName.Location = New System.Drawing.Point(113, 40)
        Me.txtName.Size = New System.Drawing.Size(147, 20)
        Me.txtName.Text = ""
        Me.txtName.BackColor = System.Drawing.SystemColors.Window
        Me.txtName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmdProducts
        '
        Me.cmdProducts.Name = "cmdProducts"
        Me.cmdProducts.TabStop = False
        Me.cmdProducts.TabIndex = 10
        Me.cmdProducts.Location = New System.Drawing.Point(364, 16)
        Me.cmdProducts.Size = New System.Drawing.Size(25, 23)
        Me.cmdProducts.Text = "..."
        Me.cmdProducts.BackColor = System.Drawing.SystemColors.Control
        Me.cmdProducts.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 12
        Me.Label5.Location = New System.Drawing.Point(16, 16)
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.Text = "Product code:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 11
        Me.Label4.Location = New System.Drawing.Point(16, 40)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Product name:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 7
        Me.cmdClose.Location = New System.Drawing.Point(348, 510)
        Me.cmdClose.Size = New System.Drawing.Size(74, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdSave
        '
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 6
        Me.cmdSave.Location = New System.Drawing.Point(267, 510)
        Me.cmdSave.Size = New System.Drawing.Size(74, 25)
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lvProducts
        '
        Me.lvProducts.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvProductsColumnHeader0, Me.lvProductsColumnHeader1, Me.lvProductsColumnHeader2, Me.lvProductsColumnHeader3, Me.lvProductsColumnHeader4, Me.lvProductsColumnHeader5, Me.lvProductsColumnHeader6})
        Me.lvProducts.Name = "lvProducts"
        Me.lvProducts.TabIndex = 2
        Me.lvProducts.Location = New System.Drawing.Point(8, 105)
        Me.lvProducts.Size = New System.Drawing.Size(414, 98)
        Me.lvProducts.BackColor = System.Drawing.SystemColors.Window
        Me.lvProducts.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvProducts.View = System.Windows.Forms.View.Details
        Me.lvProducts.MultiSelect = False
        Me.lvProducts.GridLines = True
        Me.lvProducts.FullRowSelect = True
        Me.lvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvProducts.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvProductsColumnHeader0.Text = "Code"
        Me.lvProductsColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvProductsColumnHeader1.Text = "Name"
        Me.lvProductsColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvProductsColumnHeader2.Text = "Price"
        Me.lvProductsColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader2.Width = 98
        '
        'ColumnHeader(4)
        '
        Me.lvProductsColumnHeader3.Text = "Existence"
        Me.lvProductsColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader3.Width = 98
        '
        'ColumnHeader(5)
        '
        Me.lvProductsColumnHeader4.Text = "Ordered"
        Me.lvProductsColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader4.Width = 98
        '
        'ColumnHeader(6)
        '
        Me.lvProductsColumnHeader5.Text = "Quantity per Unit"
        Me.lvProductsColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader5.Width = 98
        '
        'ColumnHeader(7)
        '
        Me.lvProductsColumnHeader6.Text = "Unit"
        Me.lvProductsColumnHeader6.Width = 98
        '
        'Label14
        '
        Me.Label14.Name = "Label14"
        Me.Label14.TabIndex = 32
        Me.Label14.Location = New System.Drawing.Point(218, 477)
        Me.Label14.Size = New System.Drawing.Size(90, 17)
        Me.Label14.Text = "Adjusted quantity"
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblNewQuantity
        '
        Me.lblNewQuantity.Name = "lblNewQuantity"
        Me.lblNewQuantity.TabIndex = 31
        Me.lblNewQuantity.Location = New System.Drawing.Point(316, 477)
        Me.lblNewQuantity.Size = New System.Drawing.Size(90, 17)
        Me.lblNewQuantity.Text = ""
        Me.lblNewQuantity.BackColor = System.Drawing.SystemColors.Control
        Me.lblNewQuantity.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label12
        '
        Me.Label12.Name = "Label12"
        Me.Label12.TabIndex = 30
        Me.Label12.Location = New System.Drawing.Point(16, 477)
        Me.Label12.Size = New System.Drawing.Size(90, 17)
        Me.Label12.Text = "Stock quantity"
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblCurrentQuantity
        '
        Me.lblCurrentQuantity.Name = "lblCurrentQuantity"
        Me.lblCurrentQuantity.TabIndex = 29
        Me.lblCurrentQuantity.Location = New System.Drawing.Point(113, 477)
        Me.lblCurrentQuantity.Size = New System.Drawing.Size(90, 17)
        Me.lblCurrentQuantity.Text = ""
        Me.lblCurrentQuantity.BackColor = System.Drawing.SystemColors.Control
        Me.lblCurrentQuantity.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label11
        '
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 27
        Me.Label11.Location = New System.Drawing.Point(16, 380)
        Me.Label11.Size = New System.Drawing.Size(66, 17)
        Me.Label11.Text = "Stock ID:"
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label10
        '
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 24
        Me.Label10.Location = New System.Drawing.Point(235, 380)
        Me.Label10.Size = New System.Drawing.Size(90, 17)
        Me.Label10.Text = "Quantity per Unit"
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 23
        Me.Label8.Location = New System.Drawing.Point(16, 348)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Product name:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label9
        '
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 22
        Me.Label9.Location = New System.Drawing.Point(299, 348)
        Me.Label9.Size = New System.Drawing.Size(25, 17)
        Me.Label9.Text = "Unit"
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 18
        Me.Label7.Location = New System.Drawing.Point(218, 440)
        Me.Label7.Size = New System.Drawing.Size(90, 17)
        Me.Label7.Text = "Adjusted &Quantity"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 17
        Me.Label6.Location = New System.Drawing.Point(218, 410)
        Me.Label6.Size = New System.Drawing.Size(74, 17)
        Me.Label6.Text = "Adjusted &Price"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 16
        Me.Label2.Location = New System.Drawing.Point(16, 440)
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.Text = "Original Quantity"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 15
        Me.Label1.Location = New System.Drawing.Point(16, 410)
        Me.Label1.Size = New System.Drawing.Size(74, 17)
        Me.Label1.Text = "Original Price"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 8
        Me.Label3.Location = New System.Drawing.Point(16, 8)
        Me.Label3.Size = New System.Drawing.Size(122, 17)
        Me.Label3.Text = "Select a product first"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmAdjustStockManual
        '
        Me.ClientSize = New System.Drawing.Size(431, 569)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.sbStatusBar, Me.txtStockID, Me.txtOriginalPrice, Me.txtValues_0, Me.txtQuantityPerUnit, Me.txtProductName, Me.txtUnit, Me.txtValues_1, Me.txtOriginalQuantity, Me.Frame3, Me.Frame1, Me.cmdClose, Me.cmdSave, Me.lvProducts, Me.Label14, Me.lblNewQuantity, Me.Label12, Me.lblCurrentQuantity, Me.Label11, Me.Label10, Me.Label8, Me.Label9, Me.Label7, Me.Label6, Me.Label2, Me.Label1, Me.Label3})
        Me.Name = "frmAdjustStockManual"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Inventory Adjust"
        Me.txtValues.SetIndex(txtValues_0, CType(0, Short))
        Me.txtValues.SetIndex(txtValues_1, CType(1, Short))
        CType(Me.txtValues, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame3.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    Private editingData As Boolean
    Private currentIdProduct As String = ""
    ' VBto upgrade warning: currentIdStock As Short	OnWrite(String)
    Private currentIdStock As Short
    Private currentQuantityPerUnit As String = ""
    Private currentUnit As String = ""
    Private currentProductName As String
    ' VBto upgrade warning: currentStockPrice As Double	OnWrite(String)
    Private currentStockPrice As Double
    ' VBto upgrade warning: currentStock As Double	OnWrite(String)
    Private currentStock As Double
    Private changedStockPrice As Double
    Private changedStock As Double
    Private codeGeneratedChange As Boolean
    Private quantity As Double
    Private stockPrice As Double, unitPrice As Double

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        cmdSave_Click()
    End Sub
    Public Sub cmdSave_Click()
        Dim newStockId As Short
        ' VBto upgrade warning: newManualLogId As Short	OnWrite(Object)
        Dim newManualLogId As Short
        ' VBto upgrade warning: newStockLogId As Short	OnWrite(Object)
        Dim newStockLogId As Short
        editingData = False
        Try ' On Error GoTo HandleError

            Dim deltaStockPrice As Double
            Dim deltaStock As Double
            changedStockPrice = CDbl(txtValues(0).Text)
            changedStock = CDbl(txtValues(1).Text)

            deltaStockPrice = changedStockPrice-currentStockPrice
            deltaStock = changedStock-currentStock

            If deltaStockPrice=0 And deltaStock=0 Then
                LogStatus("There is no modification of the Stock, the data won't be saved", Me)
                Exit Sub
            End If
            ' UPDATE
            ExecuteSql("Update Stocks Set StockPrice = " & changedStockPrice & ", Stock = " & changedStock & " Where StockId = " & currentIdStock)

            ' NEW
            ExecuteSql("Select * from ManualStocks")
            rs.AddNew()
            rs.Fields("StockID").Value = currentIdStock
            rs.Fields("Quantity").Value = deltaStock
            rs.Fields("Price").Value = deltaStockPrice
            rs.Fields("User").Value = UserId
            rs.Fields("Date").Value = CStr(Today)
            rs.Fields("Action").Value = "MOD"
            rs.Update()
            newManualLogId = rs.Fields("ManualID").Value

            'NEW
            ExecuteSql("Select * from StockLog")
            rs.AddNew()
            rs.Fields("User").Value = UserId
            rs.Fields("Date").Value = CStr(Today)
            rs.Fields("Quantity").Value = deltaStock
            rs.Fields("StockPrice").Value = deltaStockPrice
            rs.Fields("ProductID").Value = currentIdProduct
            rs.Fields("StockID").Value = currentIdStock
            rs.Fields("DocType").Value = "MANUAL"
            rs.Fields("DocID").Value = newManualLogId
            rs.Update()
            newStockLogId = rs.Fields("ID").Value

            ExecuteSql("Update Products Set UnitsInStock = UnitsInStock + " & deltaStock & " Where ProductId = '& currentIdProduct &'")

            If MsgBox("Data modified successfully" & vbCrLf & "Would you like to modify another stock manually?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Modify data")=DialogResult.Yes Then
                ClearFields()
            Else
                Close()
            End If

            Exit Sub
        Catch	' HandleError:
            ' ...
        End Try
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")
    End Sub

    ' VBto upgrade warning: Cancel As Short	OnWrite(Boolean)
    Private Sub Form_QueryUnload(ByRef Cancel As Short, ByVal UnloadMode As Short)
        If editingData Then
            Dim res As DialogResult
            res = MsgBox("Do you want to save the edited data?", MsgBoxStyle.YesNoCancel Or MsgBoxStyle.Question, "Save data")
            If res=DialogResult.Yes Then
                cmdSave_Click()
            ElseIf res<>DialogResult.No Then
                Cancel = True
            End If
        End If
    End Sub

    Private Sub frmAdjustStockManual_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_QueryUnload(Cancel, 0)
        If Cancel <> 0 Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub cmdProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProducts.Click
        frmProducts.ShowDialog()
        txtCode.Text = frmProducts.CurrentProductID
        txtName.Text = ""
        DoSearchProduct()
    End Sub

    Private Sub lvProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvProducts.SelectedIndexChanged
        Dim Item As ListViewItem = CType(sender, ListView).FocusedItem
        If Item Is Nothing Then Exit Sub

        DoSearchStocks()
    End Sub

    Private Sub lvStocks_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvStocks.SelectedIndexChanged
        Dim Item As ListViewItem = CType(sender, ListView).FocusedItem
        If Item Is Nothing Then Exit Sub

        RetrieveDataProduct()
    End Sub

    Private Sub txtCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCode.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProduct()
    End Sub

    'Private Sub txtCode_KeyPress(KeyAscii As Integer)
    'KeyAscii = UpCase(KeyAscii)
    'End Sub

    Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProduct()
    End Sub

    Private Sub DoSearchProduct()
        Dim filter As String
        filter = ""
        If txtCode.Text<>Nothing Then
            filter = "ProductId LIKE '%" & txtCode.Text & "%'"
        End If
        If txtName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ProductName LIKE '%" & txtName.Text & "%'"
        End If
        If filter<>Nothing Then
            filter = "Where " & filter
        End If
        ExecuteSql("Select ProductID, ProductName, UnitPrice, UnitsInStock, UnitsOnOrder, QuantityPerUnit, Unit from Products " & filter)
        lvProducts.Items.Clear()
        If rs.RecordCount=0 Then
            LogStatus("There are no records with the selected criteria")
        Else
            Dim x As ListViewItem
            While  Not rs.EOF
                x = lvProducts.Items.Add(Convert.ToString(rs.Fields(0).Value))
                For i = 1 To (rs.ColumnCount-1)
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                    End If
                Next i
                rs.MoveNext()
            End While
            If lvProducts.Items.Count=1 Then
                lvProducts.FocusedItem = lvProducts.Items(1 - 1) : lvProducts.FocusedItem.Selected = True
            End If
        End If
    End Sub


    Private Sub DoSearchStocks()
        If lvProducts.FocusedItem Is Nothing Then
            Exit Sub
        End If
        If editingData Then
            If MsgBox("Do you want to cancel previous edited data?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Data edition")<>DialogResult.Yes Then
                Exit Sub
            End If
        End If
        Dim productId As String
        Dim productName As String
        productId = lvProducts.FocusedItem.Text
        productName = lvProducts.FocusedItem.SubItems(1).Text
        currentIdProduct = lvProducts.FocusedItem.Text
        With lvProducts.FocusedItem
            If  Not IsEmpty(.SubItems(5).Text) Then currentQuantityPerUnit = .SubItems(5).Text
            If  Not IsEmpty(.SubItems(6).Text) Then currentUnit = .SubItems(6).Text
            currentProductName = .SubItems(1).Text
        End With
        txtProductName.Text = productName
        txtUnit.Text = currentUnit
        txtQuantityPerUnit.Text = currentQuantityPerUnit

        ExecuteSql("Select StockID, Stock, InitialStock, UnitPrice, " & "StockPrice, DateStarted, DateModified, User From Stocks " & " Where ProductId = '" & productId & "'")
        lvStocks.Items.Clear()
        If rs.RecordCount=0 Then
            LogStatus("There are no stock records of the product " & productName)
            RetrieveDataProduct()
        Else
            Dim x As ListViewItem
            While  Not rs.EOF
                x = lvStocks.Items.Add(Convert.ToString(rs.Fields(0).Value))
                For i = 1 To (rs.ColumnCount-1)
                    SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                Next i
                rs.MoveNext()
            End While
            If lvStocks.Items.Count=1 Then
                lvStocks.FocusedItem = lvStocks.Items(1 - 1) : lvStocks.FocusedItem.Selected = True
            End If
        End If
    End Sub

    Private Sub RetrieveDataProduct()
        If editingData Then
            If MsgBox("Do you want to cancel previous edited data?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Data edition")<>DialogResult.Yes Then
                Exit Sub
            End If
        End If

        Dim setEmpty As Boolean
        setEmpty = True
        If  Not (lvStocks.FocusedItem Is Nothing) Then
            If lvStocks.FocusedItem.Text<>Nothing Then
                currentIdStock = lvStocks.FocusedItem.Text
                With lvStocks.FocusedItem
                    currentStock = .SubItems(1).Text
                    currentStockPrice = .SubItems(4).Text
                End With
                codeGeneratedChange = True
                txtOriginalQuantity.Text = currentStock
                txtOriginalPrice.Text = currentStockPrice
                txtStockID.Text = currentIdStock
                txtValues(0).Text = currentStockPrice
                txtValues(1).Text = currentStock
                lblNewQuantity.Text = vbFormat(CDbl(currentStock*currentQuantityPerUnit), "##,###.00") & currentUnit
                lblCurrentQuantity.Text = vbFormat(CDbl(currentStock*currentQuantityPerUnit), "##,###.00") & currentUnit
                codeGeneratedChange = False
                setEmpty = False
                txtValues(0).ReadOnly = False
                txtValues(1).ReadOnly = False
                txtValues(0).Focus()
            End If
        End If
        If setEmpty Then
            codeGeneratedChange = True
            txtOriginalQuantity.Text = ""
            txtOriginalPrice.Text = ""
            txtStockID.Text = ""
            txtValues(0).Text = ""
            txtValues(1).Text = ""
            lblNewQuantity.Text = ""
            lblCurrentQuantity.Text = ""
            codeGeneratedChange = False
        End If
        editingData = False

    End Sub

    Private Sub txtValues_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtValues.Enter
        Dim Index As Short = txtValues.GetIndex(sender)
        SelectAll(txtValues(Index))
    End Sub

    Private Sub txtValues_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtValues.KeyPress
        Dim Index As Short = txtValues.GetIndex(sender)
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        txtValues_KeyPress(Index, KeyAscii)

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub
    Public Sub txtValues_KeyPress(ByVal Index As Integer, ByRef KeyAscii As Keys)
        Select Case KeyAscii
            Case Keys.D0 To Keys.D9:
            Case Keys.Back, Keys.Clear, Keys.Delete:
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Tab:

            Case Else
                KeyAscii = 0
                Beep()
        End Select
    End Sub

    Private Sub txtValues_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtValues.TextChanged
        Dim Index As Short = txtValues.GetIndex(sender)
        If Not sender.Created() Then Exit Sub
        If  Not codeGeneratedChange Then
            editingData = True
            codeGeneratedChange = True
            If txtValues(0).Text<>Nothing Then changedStockPrice = CDbl(txtValues(0).Text)
            If txtValues(1).Text<>Nothing Then changedStock = CDbl(txtValues(1).Text)
            Select Case Index
                Case 1:
                    If changedStock>currentStock Then
                        changedStock = currentStock
                        LogStatus("Cannot pass the original stock, to add more, add a new stock manually", Me)
                        txtValues(1).Text = changedStock
                    End If
            End Select
            lblNewQuantity.Text = vbFormat(CDbl(changedStock*currentQuantityPerUnit), "##,###.00") & currentUnit
            lblCurrentQuantity.Text = vbFormat(CDbl(currentStock*currentQuantityPerUnit), "##,###.00") & currentUnit
            codeGeneratedChange = False
        End If
    End Sub

    Private Sub ClearFields()
        codeGeneratedChange = True
        txtValues(0).Text = ""
        txtValues(1).Text = ""
        txtValues(0).ReadOnly = True
        txtValues(1).ReadOnly = True
        txtCode.Text = ""
        txtName.Text = ""
        txtUnit.Text = ""
        txtStockID.Text = ""
        txtOriginalPrice.Text = ""
        txtOriginalQuantity.Text = ""
        txtProductName.Text = ""
        txtQuantityPerUnit.Text = ""
        lvProducts.Items.Clear()
        lvStocks.Items.Clear()
        lblCurrentQuantity.Text = ""
        lblNewQuantity.Text = ""
        txtCode.Focus()
        editingData = False
        codeGeneratedChange = False
        ClearLogStatus(Me)
    End Sub

End Class