Public Class frmMain
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbStatusBar_Panel2 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents sbStatusBar_Panel3 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents MainMenu1 As System.Windows.Forms.MainMenu
    Friend WithEvents mnuFile As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCustomer As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProviders As System.Windows.Forms.MenuItem
    Friend WithEvents mnuExit As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOrders As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCreateOrderRequest As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOrderRequestsApproval As System.Windows.Forms.MenuItem
    Friend WithEvents lExit2 As System.Windows.Forms.MenuItem
    Friend WithEvents mnuCreateOrderReception As System.Windows.Forms.MenuItem
    Friend WithEvents mnuOrderReceptionsApproval As System.Windows.Forms.MenuItem
    Friend WithEvents mnuMainInventory As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAddStockManually As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAdjustStockManually As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAccounts As System.Windows.Forms.MenuItem
    Friend WithEvents mnuProducts As System.Windows.Forms.MenuItem
    Friend WithEvents mnuSecurity As System.Windows.Forms.MenuItem
    Friend WithEvents mnuHelp As System.Windows.Forms.MenuItem
    Friend WithEvents mnuAbout As System.Windows.Forms.MenuItem
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmMain))
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.sbStatusBar_Panel2 = New System.Windows.Forms.StatusBarPanel()
        Me.sbStatusBar_Panel3 = New System.Windows.Forms.StatusBarPanel()
        Me.MainMenu1 = New System.Windows.Forms.MainMenu()
        Me.mnuFile = New System.Windows.Forms.MenuItem()
        Me.mnuCustomer = New System.Windows.Forms.MenuItem()
        Me.mnuProviders = New System.Windows.Forms.MenuItem()
        Me.mnuExit = New System.Windows.Forms.MenuItem()
        Me.mnuOrders = New System.Windows.Forms.MenuItem()
        Me.mnuCreateOrderRequest = New System.Windows.Forms.MenuItem()
        Me.mnuOrderRequestsApproval = New System.Windows.Forms.MenuItem()
        Me.lExit2 = New System.Windows.Forms.MenuItem()
        Me.mnuCreateOrderReception = New System.Windows.Forms.MenuItem()
        Me.mnuOrderReceptionsApproval = New System.Windows.Forms.MenuItem()
        Me.mnuMainInventory = New System.Windows.Forms.MenuItem()
        Me.mnuAddStockManually = New System.Windows.Forms.MenuItem()
        Me.mnuAdjustStockManually = New System.Windows.Forms.MenuItem()
        Me.mnuAccounts = New System.Windows.Forms.MenuItem()
        Me.mnuProducts = New System.Windows.Forms.MenuItem()
        Me.mnuSecurity = New System.Windows.Forms.MenuItem()
        Me.mnuHelp = New System.Windows.Forms.MenuItem()
        Me.mnuAbout = New System.Windows.Forms.MenuItem()
        Me.SuspendLayout()
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1, Me.sbStatusBar_Panel2, Me.sbStatusBar_Panel3})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 0
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 666)
        Me.sbStatusBar.Size = New System.Drawing.Size(1126, 25)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 909
        Me.sbStatusBar_Panel1.MinWidth = 67
        '
        'Panel2
        '
        Me.sbStatusBar_Panel2.Text = ""
        '
        'Panel3
        '
        Me.sbStatusBar_Panel3.Text = ""
        '
        'mnuFile
        '
        Me.mnuFile.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuCustomer, Me.mnuProviders, Me.mnuExit})
        Me.mnuFile.Name = "mnuFile"
        Me.mnuFile.Text = "&File"
        '
        'mnuCustomer
        '
        Me.mnuCustomer.Name = "mnuCustomer"
        Me.mnuCustomer.Text = "&Manage Customers"
        '
        'mnuProviders
        '
        Me.mnuProviders.Name = "mnuProviders"
        Me.mnuProviders.Text = "Manage Su&ppliers "
        '
        'mnuExit
        '
        Me.mnuExit.Name = "mnuExit"
        Me.mnuExit.Text = "&Exit"
        '
        'mnuOrders
        '
        Me.mnuOrders.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuCreateOrderRequest, Me.mnuOrderRequestsApproval, Me.lExit2, Me.mnuCreateOrderReception, Me.mnuOrderReceptionsApproval})
        Me.mnuOrders.Name = "mnuOrders"
        Me.mnuOrders.Text = "&Orders"
        '
        'mnuCreateOrderRequest
        '
        Me.mnuCreateOrderRequest.Name = "mnuCreateOrderRequest"
        Me.mnuCreateOrderRequest.Text = "Create Order"
        '
        'mnuOrderRequestsApproval
        '
        Me.mnuOrderRequestsApproval.Name = "mnuOrderRequestsApproval"
        Me.mnuOrderRequestsApproval.Text = "Create Invoice"
        '
        'lExit2
        '
        Me.lExit2.Name = "lExit2"
        Me.lExit2.Text = "-"
        '
        'mnuCreateOrderReception
        '
        Me.mnuCreateOrderReception.Name = "mnuCreateOrderReception"
        Me.mnuCreateOrderReception.Text = "Add Stock Order"
        '
        'mnuOrderReceptionsApproval
        '
        Me.mnuOrderReceptionsApproval.Name = "mnuOrderReceptionsApproval"
        Me.mnuOrderReceptionsApproval.Text = "Add Stock to Inventory"
        '
        'mnuMainInventory
        '
        Me.mnuMainInventory.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAddStockManually, Me.mnuAdjustStockManually})
        Me.mnuMainInventory.Name = "mnuMainInventory"
        Me.mnuMainInventory.Text = "&Inventory"
        '
        'mnuAddStockManually
        '
        Me.mnuAddStockManually.Name = "mnuAddStockManually"
        Me.mnuAddStockManually.Text = "Inventory Update"
        '
        'mnuAdjustStockManually
        '
        Me.mnuAdjustStockManually.Name = "mnuAdjustStockManually"
        Me.mnuAdjustStockManually.Text = "Inventory Adjust"
        '
        'mnuAccounts
        '
        Me.mnuAccounts.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuProducts, Me.mnuSecurity})
        Me.mnuAccounts.Name = "mnuAccounts"
        Me.mnuAccounts.Text = "&Maintenance"
        '
        'mnuProducts
        '
        Me.mnuProducts.Name = "mnuProducts"
        Me.mnuProducts.Text = "Manage Products"
        '
        'mnuSecurity
        '
        Me.mnuSecurity.Name = "mnuSecurity"
        Me.mnuSecurity.Text = "Manage Users"
        '
        'mnuHelp
        '
        Me.mnuHelp.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuAbout})
        Me.mnuHelp.Name = "mnuHelp"
        Me.mnuHelp.Text = "&Help"
        '
        'mnuAbout
        '
        Me.mnuAbout.Name = "mnuAbout"
        Me.mnuAbout.Text = "&About"
        '
        'MainMenu1
        '
        Me.MainMenu1.MenuItems.AddRange(New System.Windows.Forms.MenuItem() {Me.mnuFile, Me.mnuOrders, Me.mnuMainInventory, Me.mnuAccounts, Me.mnuHelp})
        '
        'frmMain
        '
        Me.ClientSize = New System.Drawing.Size(1126, 692)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.sbStatusBar})
        Me.Menu = Me.MainMenu1
        Me.IsMdiContainer = True
        Me.Name = "frmMain"
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = True
        Me.MaximizeBox = True
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Icon = CType(Resources.GetObject("frmMain.Icon"), System.Drawing.Icon)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.Text = "Sales Agent"
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    Private Sub frmMain_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        frmSplash.ShowDialog()
        ShowAsMdiChild(frmOrderRequest, Me)


    End Sub

    Private Sub mnuAbout_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuAbout.Click
        frmAbout.ShowDialog()
    End Sub

    Private Sub mnuAddStockManually_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuAddStockManually.Click
        ShowAsMdiChild(frmAddStockManual, Me)
    End Sub

    Private Sub mnuAdjustStockManually_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuAdjustStockManually.Click
        ShowAsMdiChild(frmAdjustStockManual, Me)
    End Sub

    Private Sub mnuCreateOrderReception_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuCreateOrderReception.Click
        ShowAsMdiChild(frmOrderReception, Me)
    End Sub

    Private Sub mnuCreateOrderRequest_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuCreateOrderRequest.Click
        ShowAsMdiChild(frmOrderRequest, Me)
    End Sub

    Private Sub mnuCustomer_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuCustomer.Click
        frmCustomers.ShowDialog()
        frmCustomers.InitForm()
    End Sub

    Private Sub mnuExit_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuExit.Click
        Close()
    End Sub

    Private Sub mnuOrderReceptionsApproval_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuOrderReceptionsApproval.Click
        ShowAsMdiChild(frmReceptionApproval, Me)
    End Sub

    Private Sub mnuOrderRequestsApproval_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuOrderRequestsApproval.Click
        ShowAsMdiChild(frmRequestApproval, Me)
    End Sub

    Private Sub mnuProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuProducts.Click
        frmProducts.ShowDialog()
    End Sub

    Private Sub mnuProviders_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuProviders.Click
        frmProviders.ShowDialog()
    End Sub

    Private Sub mnuSecurity_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles mnuSecurity.Click
        ShowAsMdiChild(frmUsersManage, Me)
    End Sub



End Class