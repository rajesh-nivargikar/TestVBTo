
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmAddStockManual
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtValues As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents txtUnit As System.Windows.Forms.TextBox
    Friend WithEvents txtProductName As System.Windows.Forms.TextBox
    Friend WithEvents txtQuantityPerUnit As System.Windows.Forms.TextBox
    Friend WithEvents txtValues_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtValues_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtValues_0 As System.Windows.Forms.TextBox
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdProducts As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lvProducts As System.Windows.Forms.ListView
    Friend WithEvents lvProductsColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblNewQuantity As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAddStockManual))
        Me.components = New System.ComponentModel.Container()
        Me.txtValues = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.txtUnit = New System.Windows.Forms.TextBox()
        Me.txtProductName = New System.Windows.Forms.TextBox()
        Me.txtQuantityPerUnit = New System.Windows.Forms.TextBox()
        Me.txtValues_2 = New System.Windows.Forms.TextBox()
        Me.txtValues_1 = New System.Windows.Forms.TextBox()
        Me.txtValues_0 = New System.Windows.Forms.TextBox()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdProducts = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lvProducts = New System.Windows.Forms.ListView()
        Me.lvProductsColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.lblNewQuantity = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        CType(Me.txtValues, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'cmdSave
        '
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 24
        Me.cmdSave.Location = New System.Drawing.Point(227, 380)
        Me.cmdSave.Size = New System.Drawing.Size(90, 25)
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 23
        Me.cmdClose.Location = New System.Drawing.Point(332, 380)
        Me.cmdClose.Size = New System.Drawing.Size(90, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 20
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 421)
        Me.sbStatusBar.Size = New System.Drawing.Size(429, 23)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 408
        '
        'txtUnit
        '
        Me.txtUnit.Name = "txtUnit"
        Me.txtUnit.TabStop = False
        Me.txtUnit.TabIndex = 18
        Me.txtUnit.Location = New System.Drawing.Point(324, 267)
        Me.txtUnit.Size = New System.Drawing.Size(82, 20)
        Me.txtUnit.Text = ""
        Me.txtUnit.BackColor = System.Drawing.SystemColors.Menu
        Me.txtUnit.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtUnit.ReadOnly = True
        '
        'txtProductName
        '
        Me.txtProductName.Name = "txtProductName"
        Me.txtProductName.TabStop = False
        Me.txtProductName.TabIndex = 16
        Me.txtProductName.Location = New System.Drawing.Point(97, 267)
        Me.txtProductName.Size = New System.Drawing.Size(147, 20)
        Me.txtProductName.Text = ""
        Me.txtProductName.BackColor = System.Drawing.SystemColors.Menu
        Me.txtProductName.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtProductName.ReadOnly = True
        '
        'txtQuantityPerUnit
        '
        Me.txtQuantityPerUnit.Name = "txtQuantityPerUnit"
        Me.txtQuantityPerUnit.TabStop = False
        Me.txtQuantityPerUnit.TabIndex = 15
        Me.txtQuantityPerUnit.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtQuantityPerUnit.Location = New System.Drawing.Point(324, 299)
        Me.txtQuantityPerUnit.Size = New System.Drawing.Size(82, 20)
        Me.txtQuantityPerUnit.Text = ""
        Me.txtQuantityPerUnit.BackColor = System.Drawing.SystemColors.Menu
        Me.txtQuantityPerUnit.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtQuantityPerUnit.ReadOnly = True
        '
        'txtValues_2
        '
        Me.txtValues_2.Name = "txtValues_2"
        Me.txtValues_2.TabIndex = 5
        Me.txtValues_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtValues_2.Location = New System.Drawing.Point(324, 332)
        Me.txtValues_2.Size = New System.Drawing.Size(82, 20)
        Me.txtValues_2.Text = ""
        Me.txtValues_2.BackColor = System.Drawing.SystemColors.Window
        Me.txtValues_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValues_2.ReadOnly = True
        '
        'txtValues_1
        '
        Me.txtValues_1.Name = "txtValues_1"
        Me.txtValues_1.TabIndex = 4
        Me.txtValues_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtValues_1.Location = New System.Drawing.Point(97, 332)
        Me.txtValues_1.Size = New System.Drawing.Size(82, 20)
        Me.txtValues_1.Text = ""
        Me.txtValues_1.BackColor = System.Drawing.SystemColors.Window
        Me.txtValues_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValues_1.ReadOnly = True
        '
        'txtValues_0
        '
        Me.txtValues_0.Name = "txtValues_0"
        Me.txtValues_0.TabIndex = 3
        Me.txtValues_0.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtValues_0.Location = New System.Drawing.Point(97, 299)
        Me.txtValues_0.Size = New System.Drawing.Size(82, 20)
        Me.txtValues_0.Text = ""
        Me.txtValues_0.BackColor = System.Drawing.SystemColors.Window
        Me.txtValues_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtValues_0.ReadOnly = True
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdProducts, Me.txtName, Me.txtCode, Me.Label4, Me.Label5})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 6
        Me.Frame1.Location = New System.Drawing.Point(8, 32)
        Me.Frame1.Size = New System.Drawing.Size(414, 66)
        Me.Frame1.Text = "Search product "
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdProducts
        '
        Me.cmdProducts.Name = "cmdProducts"
        Me.cmdProducts.TabStop = False
        Me.cmdProducts.TabIndex = 7
        Me.cmdProducts.Location = New System.Drawing.Point(364, 16)
        Me.cmdProducts.Size = New System.Drawing.Size(25, 23)
        Me.cmdProducts.Text = "..."
        Me.cmdProducts.BackColor = System.Drawing.SystemColors.Control
        Me.cmdProducts.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtName
        '
        Me.txtName.Name = "txtName"
        Me.txtName.TabIndex = 1
        Me.txtName.Location = New System.Drawing.Point(113, 40)
        Me.txtName.Size = New System.Drawing.Size(147, 20)
        Me.txtName.Text = ""
        Me.txtName.BackColor = System.Drawing.SystemColors.Window
        Me.txtName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtCode
        '
        Me.txtCode.Name = "txtCode"
        Me.txtCode.TabIndex = 0
        Me.txtCode.Location = New System.Drawing.Point(113, 16)
        Me.txtCode.Size = New System.Drawing.Size(98, 20)
        Me.txtCode.Text = ""
        Me.txtCode.BackColor = System.Drawing.SystemColors.Window
        Me.txtCode.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 9
        Me.Label4.Location = New System.Drawing.Point(16, 40)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Product name:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 8
        Me.Label5.Location = New System.Drawing.Point(16, 16)
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.Text = "Product code:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lvProducts
        '
        Me.lvProducts.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvProductsColumnHeader0, Me.lvProductsColumnHeader1, Me.lvProductsColumnHeader2, Me.lvProductsColumnHeader3, Me.lvProductsColumnHeader4, Me.lvProductsColumnHeader5, Me.lvProductsColumnHeader6})
        Me.lvProducts.Name = "lvProducts"
        Me.lvProducts.TabIndex = 2
        Me.lvProducts.Location = New System.Drawing.Point(8, 105)
        Me.lvProducts.Size = New System.Drawing.Size(414, 155)
        Me.lvProducts.BackColor = System.Drawing.SystemColors.Window
        Me.lvProducts.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvProducts.View = System.Windows.Forms.View.Details
        Me.lvProducts.MultiSelect = False
        Me.lvProducts.GridLines = True
        Me.lvProducts.FullRowSelect = True
        Me.lvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvProducts.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvProductsColumnHeader0.Text = "Code"
        Me.lvProductsColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvProductsColumnHeader1.Text = "Name"
        Me.lvProductsColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvProductsColumnHeader2.Text = "Price"
        Me.lvProductsColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader2.Width = 98
        '
        'ColumnHeader(4)
        '
        Me.lvProductsColumnHeader3.Text = "Existence"
        Me.lvProductsColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader3.Width = 98
        '
        'ColumnHeader(5)
        '
        Me.lvProductsColumnHeader4.Text = "Ordered"
        Me.lvProductsColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader4.Width = 98
        '
        'ColumnHeader(6)
        '
        Me.lvProductsColumnHeader5.Text = "Quantity per Unit"
        Me.lvProductsColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader5.Width = 98
        '
        'ColumnHeader(7)
        '
        Me.lvProductsColumnHeader6.Text = "Unit"
        Me.lvProductsColumnHeader6.Width = 98
        '
        'lblNewQuantity
        '
        Me.lblNewQuantity.Name = "lblNewQuantity"
        Me.lblNewQuantity.TabIndex = 22
        Me.lblNewQuantity.Location = New System.Drawing.Point(105, 367)
        Me.lblNewQuantity.Size = New System.Drawing.Size(90, 17)
        Me.lblNewQuantity.Text = ""
        Me.lblNewQuantity.BackColor = System.Drawing.SystemColors.Control
        Me.lblNewQuantity.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label10
        '
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 21
        Me.Label10.Location = New System.Drawing.Point(8, 367)
        Me.Label10.Size = New System.Drawing.Size(90, 17)
        Me.Label10.Text = "Stock quantity"
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label9
        '
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 19
        Me.Label9.Location = New System.Drawing.Point(291, 267)
        Me.Label9.Size = New System.Drawing.Size(25, 17)
        Me.Label9.Text = "Unit"
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 17
        Me.Label8.Location = New System.Drawing.Point(8, 267)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Product name:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 14
        Me.Label7.Location = New System.Drawing.Point(227, 299)
        Me.Label7.Size = New System.Drawing.Size(90, 17)
        Me.Label7.Text = "Quantity per Unit"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 13
        Me.Label6.Location = New System.Drawing.Point(227, 335)
        Me.Label6.Size = New System.Drawing.Size(74, 17)
        Me.Label6.Text = "Unit Price"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 12
        Me.Label1.Location = New System.Drawing.Point(8, 335)
        Me.Label1.Size = New System.Drawing.Size(74, 17)
        Me.Label1.Text = "Stock Price"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 11
        Me.Label2.Location = New System.Drawing.Point(8, 302)
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.Text = "Quantity"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 10
        Me.Label3.Location = New System.Drawing.Point(16, 8)
        Me.Label3.Size = New System.Drawing.Size(122, 17)
        Me.Label3.Text = "Select a product first"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmAddStockManual
        '
        Me.ClientSize = New System.Drawing.Size(429, 444)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdSave, Me.cmdClose, Me.sbStatusBar, Me.txtUnit, Me.txtProductName, Me.txtQuantityPerUnit, Me.txtValues_2, Me.txtValues_1, Me.txtValues_0, Me.Frame1, Me.lvProducts, Me.lblNewQuantity, Me.Label10, Me.Label9, Me.Label8, Me.Label7, Me.Label6, Me.Label1, Me.Label2, Me.Label3})
        Me.Name = "frmAddStockManual"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Inventory Update"
        Me.txtValues.SetIndex(txtValues_2, CType(2, Short))
        Me.txtValues.SetIndex(txtValues_1, CType(1, Short))
        Me.txtValues.SetIndex(txtValues_0, CType(0, Short))
        CType(Me.txtValues, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    Private editingData As Boolean
    Private currentIdProduct As String = ""
    Private currentQuantityPerUnit As String = ""
    Private currentUnit As String = ""
    Private currentProductName As String
    ' VBto upgrade warning: currentPriceReference As Double	OnWrite(String)
    Private currentPriceReference As Double
    Private codeGeneratedChange As Boolean
    Private quantity As Double
    Private stockPrice As Double, unitPrice As Double

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProducts.Click
        frmProducts.ShowDialog()
        txtCode.Text = frmProducts.CurrentProductID
        txtName.Text = ""
        DoSearchProduct()
    End Sub

    Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        cmdSave_Click()
    End Sub
    Public Sub cmdSave_Click()
        ' VBto upgrade warning: newStockId As Short	OnWrite(Object)
        Dim newStockId As Short
        ' VBto upgrade warning: newManualLogId As Short	OnWrite(Object)
        Dim newManualLogId As Short
        ' VBto upgrade warning: newStockLogId As Short	OnWrite(Object)
        Dim newStockLogId As Short
        editingData = False
        Try ' On Error GoTo HandleError
            ExecuteSql("Select * from Stocks")
            rs.AddNew()
            rs.Fields("ProductID").Value = currentIdProduct
            rs.Fields("Stock").Value = txtValues(0).Text
            rs.Fields("InitialStock").Value = txtValues(0).Text
            rs.Fields("DateStarted").Value = CStr(Today)
            rs.Fields("DateModified").Value = CStr(Today)
            rs.Fields("User").Value = UserId
            rs.Fields("UnitPrice").Value = txtValues(2).Text
            rs.Fields("StockPrice").Value = txtValues(1).Text
            rs.Update()
            newStockId = rs.Fields("StockID").Value

            ExecuteSql("Select * from ManualStocks")
            rs.AddNew()
            rs.Fields("StockID").Value = newStockId
            rs.Fields("Quantity").Value = txtValues(0).Text
            rs.Fields("Price").Value = txtValues(1).Text
            rs.Fields("User").Value = UserId
            rs.Fields("Date").Value = CStr(Today)
            rs.Fields("Action").Value = "ADD"
            rs.Update()
            newManualLogId = rs.Fields("ManualID").Value

            ExecuteSql("Select * from StockLog")
            rs.AddNew()
            rs.Fields("User").Value = UserId
            rs.Fields("Date").Value = CStr(Today)
            rs.Fields("Quantity").Value = txtValues(0).Text
            rs.Fields("StockPrice").Value = txtValues(1).Text
            rs.Fields("ProductID").Value = currentIdProduct
            rs.Fields("StockID").Value = newStockId
            rs.Fields("DocType").Value = "MANUAL"
            rs.Fields("DocID").Value = newManualLogId
            rs.Update()
            newStockLogId = rs.Fields("ID").Value

            ExecuteSql("Update Products Set UnitsInStock = UnitsInStock + " & txtValues(0).Text & " Where ProductId = '& currentIdProduct &'")

            If MsgBox("Data added successfully" & vbCrLf & "Would you like to add a new stock manually?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "New data")=DialogResult.Yes Then
                ClearFields()
            Else
                Close()
            End If

            Exit Sub
        Catch	' HandleError:
            ' ...
        End Try
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")
    End Sub

    Private Sub frmAddStockManual_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        editingData = False
        codeGeneratedChange = False
    End Sub

    ' VBto upgrade warning: Cancel As Short	OnWrite(Boolean)
    Private Sub Form_QueryUnload(ByRef Cancel As Short, ByVal UnloadMode As Short)
        If editingData Then
            Dim res As DialogResult
            res = MsgBox("Do you want to save the edited data?", MsgBoxStyle.YesNoCancel Or MsgBoxStyle.Question, "Save data")
            If res=DialogResult.Yes Then
                cmdSave_Click()
            ElseIf res<>DialogResult.No Then
                Cancel = True
            End If
        End If
    End Sub

    Private Sub frmAddStockManual_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_QueryUnload(Cancel, 0)
        If Cancel <> 0 Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub lvProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles lvProducts.Click
        RetrieveDataProduct()
    End Sub

    Private Sub lvProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvProducts.SelectedIndexChanged
        Dim Item As ListViewItem = CType(sender, ListView).FocusedItem
        If Item Is Nothing Then Exit Sub

        RetrieveDataProduct()
    End Sub

    Private Sub txtCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCode.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProduct()
    End Sub

    'Private Sub txtCode_KeyPress(KeyAscii As Integer)
    'KeyAscii = UpCase(KeyAscii)
    'End Sub

    Private Sub txtCode_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCode.Leave
        If lvProducts.Items.Count=1 Then
            RetrieveDataProduct()
        End If
    End Sub

    Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProduct()
    End Sub


    Private Sub DoSearchProduct()
        Dim filter As String
        filter = ""
        If txtCode.Text<>Nothing Then
            filter = "ProductId LIKE '%" & txtCode.Text & "%'"
        End If
        If txtName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ProductName LIKE '%" & txtName.Text & "%'"
        End If
        If filter<>Nothing Then
            filter = "Where " & filter
        End If
        ExecuteSql("Select ProductID, ProductName, UnitPrice, UnitsInStock, UnitsOnOrder, QuantityPerUnit, Unit from Products " & filter)
        lvProducts.Items.Clear()
        If rs.RecordCount=0 Then
            LogStatus("There are no records with the selected criteria", Me)
        Else
            Dim x As ListViewItem
            While  Not rs.EOF
                x = lvProducts.Items.Add(Convert.ToString(rs.Fields(0).Value))
                For i = 1 To (rs.ColumnCount-1)
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                    End If
                Next i
                rs.MoveNext()
            End While
            If lvProducts.Items.Count=1 Then
                lvProducts.FocusedItem = lvProducts.Items(1 - 1) : lvProducts.FocusedItem.Selected = True
                'RetrieveDataProduct
            End If
        End If
    End Sub

    Private Sub RetrieveDataProduct()
        If editingData Then
            If MsgBox("Do you want to cancel previous edited data?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Data edition")<>DialogResult.Yes Then
                Exit Sub
            End If
        End If

        If lvProducts.FocusedItem.Text<>Nothing Then
            With lvProducts.FocusedItem
                currentIdProduct = lvProducts.FocusedItem.Text
                If .SubItems(5).Text<>Nothing Then currentQuantityPerUnit = .SubItems(5).Text
                If .SubItems(6).Text<>Nothing Then currentUnit = .SubItems(6).Text
                currentProductName = .SubItems(1).Text
                currentPriceReference = .SubItems(2).Text
            End With
            txtProductName.Text = currentProductName
            txtQuantityPerUnit.Text = currentQuantityPerUnit
            txtUnit.Text = currentUnit
            txtValues(0).ReadOnly = False
            txtValues(1).ReadOnly = False
            txtValues(2).ReadOnly = False
            txtValues(0).Text = 1
            txtValues(1).Text = currentPriceReference
            txtValues(2).Text = currentPriceReference
            txtValues(0).Focus()
            SelectAll(txtValues(0))
            editingData = False
        End If
    End Sub


    Private Sub txtName_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtName.Leave
        If lvProducts.Items.Count=1 Then
            RetrieveDataProduct()
        End If
    End Sub

    Private Sub txtValues_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtValues.TextChanged
        Dim Index As Short = txtValues.GetIndex(sender)
        If Not sender.Created() Then Exit Sub
        If  Not codeGeneratedChange Then
            editingData = True
            codeGeneratedChange = True
            If txtValues(0).Text<>Nothing Then quantity = CDbl(txtValues(0).Text)
            If txtValues(1).Text<>Nothing Then stockPrice = CDbl(txtValues(1).Text)
            If txtValues(2).Text<>Nothing Then unitPrice = CDbl(txtValues(2).Text)
            Select Case Index
                Case 0:
                    txtValues(1).Text = unitPrice*quantity
                Case 1:
                    txtValues(2).Text = stockPrice/quantity
                Case 2:
                    txtValues(1).Text = unitPrice*quantity
            End Select
            lblNewQuantity.Text = vbFormat(CDbl(quantity*currentQuantityPerUnit), "##,###.00") & currentUnit
            codeGeneratedChange = False
        End If
    End Sub

    Private Sub txtValues_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtValues.Enter
        Dim Index As Short = txtValues.GetIndex(sender)
        SelectAll(txtValues(Index))
    End Sub

    Private Sub txtValues_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtValues.KeyPress
        Dim Index As Short = txtValues.GetIndex(sender)
        Dim KeyAscii As Keys = Asc(e.KeyChar)

        txtValues_KeyPress(Index, KeyAscii)

        e.KeyChar = Chr(KeyAscii) : If KeyAscii = 0 Then e.Handled = True
    End Sub
    Public Sub txtValues_KeyPress(ByVal Index As Integer, ByRef KeyAscii As Keys)
        Select Case KeyAscii
            Case Keys.D0 To Keys.D9:
            Case Keys.Back, Keys.Clear, Keys.Delete:
            Case Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Tab:

            Case Else
                KeyAscii = 0
                Beep()
        End Select
    End Sub

    Private Sub ClearFields()
        codeGeneratedChange = True
        txtValues(0).ReadOnly = True
        txtValues(1).ReadOnly = True
        txtValues(2).ReadOnly = True
        txtValues(0).Text = ""
        txtValues(1).Text = ""
        txtValues(2).Text = ""
        txtCode.Text = ""
        txtName.Text = ""
        txtUnit.Text = ""
        txtProductName.Text = ""
        txtQuantityPerUnit.Text = ""
        lvProducts.Items.Clear()
        txtCode.Focus()
        editingData = False
        codeGeneratedChange = False
        lblNewQuantity.Text = ""
        ClearLogStatus(Me)
    End Sub

End Class