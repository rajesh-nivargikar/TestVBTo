
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmLogin
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lblLabels As Microsoft.VisualBasic.Compatibility.VB6.LabelArray
    Friend WithEvents txtUserName As System.Windows.Forms.TextBox
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents cmdOK As System.Windows.Forms.Button
    Friend WithEvents lblLabels_0 As System.Windows.Forms.Label
    Friend WithEvents lblLabels_1 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmLogin))
        Me.components = New System.ComponentModel.Container()
        Me.lblLabels = New Microsoft.VisualBasic.Compatibility.VB6.LabelArray(components)
        Me.txtUserName = New System.Windows.Forms.TextBox()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.cmdOK = New System.Windows.Forms.Button()
        Me.lblLabels_0 = New System.Windows.Forms.Label()
        Me.lblLabels_1 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        CType(Me.lblLabels, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'txtUserName
        '
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.TabIndex = 1
        Me.txtUserName.Location = New System.Drawing.Point(119, 25)
        Me.txtUserName.Size = New System.Drawing.Size(157, 23)
        Me.txtUserName.Text = ""
        Me.txtUserName.BackColor = System.Drawing.SystemColors.Window
        Me.txtUserName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmdCancel
        '
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.TabIndex = 5
        Me.cmdCancel.Location = New System.Drawing.Point(198, 101)
        Me.cmdCancel.Size = New System.Drawing.Size(77, 26)
        Me.cmdCancel.Text = "Cancel"
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtPassword
        '
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.TabIndex = 3
        Me.txtPassword.Location = New System.Drawing.Point(119, 52)
        Me.txtPassword.Size = New System.Drawing.Size(157, 23)
        Me.txtPassword.Text = ""
        Me.txtPassword.BackColor = System.Drawing.SystemColors.Window
        Me.txtPassword.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmdOK
        '
        Me.cmdOK.Name = "cmdOK"
        Me.cmdOK.TabIndex = 4
        Me.cmdOK.Location = New System.Drawing.Point(90, 101)
        Me.cmdOK.Size = New System.Drawing.Size(77, 26)
        Me.cmdOK.Text = "OK"
        Me.cmdOK.BackColor = System.Drawing.SystemColors.Control
        Me.cmdOK.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblLabels_0
        '
        Me.lblLabels_0.Name = "lblLabels_0"
        Me.lblLabels_0.TabIndex = 0
        Me.lblLabels_0.Location = New System.Drawing.Point(39, 26)
        Me.lblLabels_0.Size = New System.Drawing.Size(73, 18)
        Me.lblLabels_0.Text = "&User Name:"
        Me.lblLabels_0.BackColor = System.Drawing.SystemColors.Control
        Me.lblLabels_0.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblLabels_1
        '
        Me.lblLabels_1.Name = "lblLabels_1"
        Me.lblLabels_1.TabIndex = 2
        Me.lblLabels_1.Location = New System.Drawing.Point(39, 53)
        Me.lblLabels_1.Size = New System.Drawing.Size(73, 18)
        Me.lblLabels_1.Text = "&Password:"
        Me.lblLabels_1.BackColor = System.Drawing.SystemColors.Control
        Me.lblLabels_1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmLogin
        '
        Me.ClientSize = New System.Drawing.Size(292, 139)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtUserName, Me.cmdCancel, Me.txtPassword, Me.cmdOK, Me.lblLabels_0, Me.lblLabels_1})
        Me.Name = "frmLogin"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ShowInTaskbar = False
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.Icon = CType(Resources.GetObject("frmLogin.Icon"), System.Drawing.Icon)
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Login"
        Me.CancelButton = cmdCancel
        Me.AcceptButton = cmdOK
        Me.lblLabels.SetIndex(lblLabels_0, CType(0, Short))
        Me.lblLabels.SetIndex(lblLabels_1, CType(1, Short))
        CType(Me.lblLabels, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    Public LoginSucceeded As Boolean

    Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        LoginSucceeded = False
        Close()
    End Sub

    Private Sub cmdOK_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdOK.Click
        ExecuteSql("SELECT * FROM Users WHERE username = '" & txtUserName.Text & "' and password = '" & txtPassword.Text & "'")
        If rs.EOF Then
            MsgBox("Invalid 'Username' or 'Password', please try again!", MsgBoxStyle.Exclamation)
            txtUserName.Focus()
            SelectAll(txtUserName)
            Exit Sub
        End If
        UserFullname = Convert.ToString(rs.Fields("Fullname").Value)
        UserLevel = Convert.ToString(rs.Fields("Level").Value)
        CurrentUserAdmin = (UserLevel="Administrator")
        Me.Cursor = Cursors.Default
        LoginSucceeded = True
        LogStatus("User : " & UserFullname & " logged at " & Now.Date & "," & TimeValue(Convert.ToString(Now)))
        Close()
    End Sub

End Class