
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility.VB6
Imports ADODB

Public Class frmProducts
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtField As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtField_6 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_0 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_5 As System.Windows.Forms.TextBox
    Friend WithEvents txtCategory As System.Windows.Forms.TextBox
    Friend WithEvents cmbCategory As System.Windows.Forms.ComboBox
    Friend WithEvents txtField_4 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_3 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_1 As System.Windows.Forms.TextBox
    Friend WithEvents Check1 As System.Windows.Forms.CheckBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents dcProducts As Microsoft.VisualBasic.Compatibility.VB6.ADODC
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Toolbar1 As System.Windows.Forms.ToolBar
    Friend WithEvents Button1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmProducts))
        Me.components = New System.ComponentModel.Container()
        Me.txtField = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtField_6 = New System.Windows.Forms.TextBox()
        Me.txtField_0 = New System.Windows.Forms.TextBox()
        Me.txtField_5 = New System.Windows.Forms.TextBox()
        Me.txtCategory = New System.Windows.Forms.TextBox()
        Me.cmbCategory = New System.Windows.Forms.ComboBox()
        Me.txtField_4 = New System.Windows.Forms.TextBox()
        Me.txtField_3 = New System.Windows.Forms.TextBox()
        Me.txtField_2 = New System.Windows.Forms.TextBox()
        Me.txtField_1 = New System.Windows.Forms.TextBox()
        Me.Check1 = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.dcProducts = New Microsoft.VisualBasic.Compatibility.VB6.ADODC()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Toolbar1 = New System.Windows.Forms.ToolBar()
        Me.Button1 = New System.Windows.Forms.ToolBarButton()
        Me.Button2 = New System.Windows.Forms.ToolBarButton()
        Me.Button3 = New System.Windows.Forms.ToolBarButton()
        Me.Button4 = New System.Windows.Forms.ToolBarButton()
        Me.Button5 = New System.Windows.Forms.ToolBarButton()
        Me.Button6 = New System.Windows.Forms.ToolBarButton()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        CType(Me.txtField, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtField_6, Me.txtField_0, Me.txtField_5, Me.txtCategory, Me.cmbCategory, Me.txtField_4, Me.txtField_3, Me.txtField_2, Me.txtField_1, Me.Check1, Me.Label7, Me.Label3, Me.Label2, Me.Label1, Me.Label4, Me.Label5, Me.Label6, Me.Label11, Me.Label15})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 9
        Me.Frame1.Location = New System.Drawing.Point(8, 49)
        Me.Frame1.Size = New System.Drawing.Size(438, 284)
        Me.Frame1.Text = "Product information"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtField_6
        '
        Me.txtField_6.Name = "txtField_6"
        Me.txtField_6.TabIndex = 20
        Me.txtField_6.Location = New System.Drawing.Point(259, 243)
        Me.txtField_6.Size = New System.Drawing.Size(106, 20)
        Me.txtField_6.Text = ""
        Me.txtField_6.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_6.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_0
        '
        Me.txtField_0.Name = "txtField_0"
        Me.txtField_0.TabIndex = 0
        Me.txtField_0.Location = New System.Drawing.Point(105, 24)
        Me.txtField_0.Size = New System.Drawing.Size(114, 20)
        Me.txtField_0.Text = ""
        Me.txtField_0.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_0.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtField_0.MaxLength = 20
        '
        'txtField_5
        '
        Me.txtField_5.Name = "txtField_5"
        Me.txtField_5.TabIndex = 7
        Me.txtField_5.Location = New System.Drawing.Point(105, 243)
        Me.txtField_5.Size = New System.Drawing.Size(106, 20)
        Me.txtField_5.Text = ""
        Me.txtField_5.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_5.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtCategory
        '
        Me.txtCategory.Name = "txtCategory"
        Me.txtCategory.TabStop = False
        Me.txtCategory.TabIndex = 16
        Me.txtCategory.Location = New System.Drawing.Point(267, 121)
        Me.txtCategory.Size = New System.Drawing.Size(114, 19)
        Me.txtCategory.Text = ""
        Me.txtCategory.BackColor = System.Drawing.SystemColors.Window
        Me.txtCategory.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmbCategory
        '
        Me.cmbCategory.Name = "cmbCategory"
        Me.cmbCategory.TabIndex = 3
        Me.cmbCategory.Location = New System.Drawing.Point(105, 118)
        Me.cmbCategory.Size = New System.Drawing.Size(122, 21)
        Me.cmbCategory.Text = ""
        Me.cmbCategory.BackColor = System.Drawing.SystemColors.Window
        Me.cmbCategory.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbCategory.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        '
        'txtField_4
        '
        Me.txtField_4.Name = "txtField_4"
        Me.txtField_4.TabIndex = 6
        Me.txtField_4.Location = New System.Drawing.Point(105, 212)
        Me.txtField_4.Size = New System.Drawing.Size(106, 20)
        Me.txtField_4.Text = ""
        Me.txtField_4.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_4.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_3
        '
        Me.txtField_3.Name = "txtField_3"
        Me.txtField_3.TabIndex = 4
        Me.txtField_3.Location = New System.Drawing.Point(105, 150)
        Me.txtField_3.Size = New System.Drawing.Size(122, 20)
        Me.txtField_3.Text = ""
        Me.txtField_3.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_3.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_2
        '
        Me.txtField_2.Name = "txtField_2"
        Me.txtField_2.TabIndex = 2
        Me.txtField_2.Location = New System.Drawing.Point(105, 89)
        Me.txtField_2.Size = New System.Drawing.Size(308, 20)
        Me.txtField_2.Text = ""
        Me.txtField_2.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtField_2.MaxLength = 255
        '
        'txtField_1
        '
        Me.txtField_1.Name = "txtField_1"
        Me.txtField_1.TabIndex = 1
        Me.txtField_1.Location = New System.Drawing.Point(105, 57)
        Me.txtField_1.Size = New System.Drawing.Size(195, 20)
        Me.txtField_1.Text = ""
        Me.txtField_1.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtField_1.MaxLength = 50
        '
        'Check1
        '
        Me.Check1.Name = "Check1"
        Me.Check1.TabIndex = 5
        Me.Check1.Location = New System.Drawing.Point(105, 183)
        Me.Check1.Size = New System.Drawing.Size(25, 17)
        Me.Check1.Text = ""
        Me.Check1.BackColor = System.Drawing.SystemColors.Control
        Me.Check1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 19
        Me.Label7.Location = New System.Drawing.Point(218, 243)
        Me.Label7.Size = New System.Drawing.Size(58, 17)
        Me.Label7.Text = "Unit:"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 18
        Me.Label3.Location = New System.Drawing.Point(16, 24)
        Me.Label3.Size = New System.Drawing.Size(90, 17)
        Me.Label3.Text = "Product Code:"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 17
        Me.Label2.Location = New System.Drawing.Point(16, 243)
        Me.Label2.Size = New System.Drawing.Size(82, 17)
        Me.Label2.Text = "Quantity per unit:"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 15
        Me.Label1.Location = New System.Drawing.Point(16, 57)
        Me.Label1.Size = New System.Drawing.Size(90, 17)
        Me.Label1.Text = "Product Name:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 14
        Me.Label4.Location = New System.Drawing.Point(16, 88)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Description:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 13
        Me.Label5.Location = New System.Drawing.Point(16, 150)
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.Text = "Serial number:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 12
        Me.Label6.Location = New System.Drawing.Point(16, 212)
        Me.Label6.Size = New System.Drawing.Size(82, 17)
        Me.Label6.Text = "Unit price:"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label11
        '
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 11
        Me.Label11.Location = New System.Drawing.Point(16, 119)
        Me.Label11.Size = New System.Drawing.Size(90, 17)
        Me.Label11.Text = "Category:"
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label15
        '
        Me.Label15.Name = "Label15"
        Me.Label15.TabIndex = 10
        Me.Label15.Location = New System.Drawing.Point(16, 181)
        Me.Label15.Size = New System.Drawing.Size(90, 17)
        Me.Label15.Text = "Discontinued:"
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'dcProducts
        '
        Me.dcProducts.Name = "dcProducts"
        Me.dcProducts.Enabled = True
        Me.dcProducts.Location = New System.Drawing.Point(8, 340)
        Me.dcProducts.Size = New System.Drawing.Size(179, 22)
        Me.dcProducts.Text = "Products"
        Me.dcProducts.BackColor = System.Drawing.SystemColors.Window
        Me.dcProducts.ForeColor = System.Drawing.SystemColors.WindowText
        Me.dcProducts.Orientation = ADODC.OrientationEnum.adHorizontal
        Me.dcProducts.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        Me.dcProducts.ConnectionTimeout = 15
        Me.dcProducts.CommandTimeout = 30
        Me.dcProducts.CursorType = ADODB.CursorTypeEnum.adOpenDynamic
        Me.dcProducts.LockType = ADODB.LockTypeEnum.adLockPessimistic
        Me.dcProducts.CommandType = ADODB.CommandTypeEnum.adCmdTable
        Me.dcProducts.CacheSize = 50
        Me.dcProducts.MaxRecords = 0
        Me.dcProducts.BOFAction = ADODC.BOFActionEnum.adDoMoveFirst
        Me.dcProducts.EOFAction = ADODC.EOFActionEnum.adDoMoveLast
        Me.dcProducts.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Orders.mdb;Persist Security Info=False"
        Me.dcProducts.UserName = ""
        Me.dcProducts.RecordSource = "Products"
        Me.dcProducts.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'ImageList1
        '
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.TransparentColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(255, Byte))
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        '
        'Toolbar1
        '
        Me.Toolbar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Button1, Me.Button2, Me.Button3, Me.Button4, Me.Button5, Me.Button6})
        Me.Toolbar1.Name = "Toolbar1"
        Me.Toolbar1.TabIndex = 8
        Me.Toolbar1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Toolbar1.ButtonSize = New System.Drawing.Size(16, 16)
        Me.Toolbar1.ImageList = Me.ImageList1
        '
        'Button1
        '
        Me.Button1.Name = "Button1"
        Me.Button1.ImageIndex = 0
        Me.Button1.Text = "Add"
        Me.Button1.ToolTipText = "Create a new record"
        Me.Button1.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button2
        '
        Me.Button2.Name = "Button2"
        Me.Button2.ImageIndex = 1
        Me.Button2.Text = "Edit"
        Me.Button2.ToolTipText = "Edit this record"
        Me.Button2.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button3
        '
        Me.Button3.Name = "Button3"
        Me.Button3.ImageIndex = 2
        Me.Button3.Text = "Save"
        Me.Button3.ToolTipText = "Save the current changes"
        Me.Button3.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button4
        '
        Me.Button4.Name = "Button4"
        Me.Button4.ImageIndex = 3
        Me.Button4.Text = "Delete"
        Me.Button4.ToolTipText = "Delete the current record"
        Me.Button4.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button5
        '
        Me.Button5.Name = "Button5"
        Me.Button5.ImageIndex = 4
        Me.Button5.Text = "Search"
        Me.Button5.ToolTipText = "Search for a record"
        Me.Button5.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button6
        '
        Me.Button6.Name = "Button6"
        Me.Button6.Text = "Cancel"
        Me.Button6.ToolTipText = "Cancel edited changes"
        Me.Button6.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'frmProducts
        '
        Me.ClientSize = New System.Drawing.Size(453, 383)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.Frame1, Me.dcProducts, Me.Toolbar1})
        Me.Name = "frmProducts"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.ShowInTaskbar = False
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Products"
        Me.txtField.SetIndex(txtField_6, CType(6, Short))
        Me.txtField.SetIndex(txtField_0, CType(0, Short))
        Me.txtField.SetIndex(txtField_5, CType(5, Short))
        Me.txtField.SetIndex(txtField_4, CType(4, Short))
        Me.txtField.SetIndex(txtField_3, CType(3, Short))
        Me.txtField.SetIndex(txtField_2, CType(2, Short))
        Me.txtField.SetIndex(txtField_1, CType(1, Short))
        CType(Me.txtField, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.Toolbar1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Private NewMode As Boolean
    Private EditMode As Boolean
    Private CancellingMode As Boolean
    ' VBto upgrade warning: CurrentProductID As String	OnWrite(Object)
    Public CurrentProductID As String = ""

    'SKS Demo TODO: Go the the designer and change the data binding of _txtField_4 like this:
    '_txtField_4.DataBindings.Add("Text", dcProducts, "UnitPrice", true, System.Windows.Forms.DataSourceUpdateMode.OnPropertyChanged, null, "C2");


    Private Sub cmbCategory_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory.SelectedIndexChanged
        If cmbCategory.Items.Count=0 Or cmbCategory.SelectedIndex=-1 Then
            Exit Sub
        End If
        txtCategory.Text = VB6.GetItemData(cmbCategory, cmbCategory.SelectedIndex)
    End Sub

    Private Sub Form_Unload(ByRef Cancel As Short)
        CurrentProductID = Convert.ToString(dcProducts.Recordset.Fields("ProductId").Value)
    End Sub

    Private Sub frmProducts_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_Unload(Cancel)
        If Cancel <> 0 Then e.Cancel = True
    End Sub

    Private Sub txtCategory_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCategory.TextChanged
        If Not sender.Created() Then Exit Sub
        If cmbCategory.Items.Count=0 Then
            LoadCombo("Categories", cmbCategory, "CategoryName", "CategoryID")
        End If
        If txtCategory.Text=Nothing Then
            cmbCategory.SelectedIndex = -1
            Exit Sub
        End If
        Dim Index As Integer
        Index = -1
        For i = 0 To cmbCategory.Items.Count
            If VB6.GetItemData(cmbCategory, i)=txtCategory.Text Then
                Index = i
                Exit For
            End If
        Next
        cmbCategory.SelectedIndex = i
    End Sub

    Private Sub frmProducts_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtCategory.Visible = False
        dcProducts.ConnectionString = ConnectionString
        NewMode = False
        EditMode = False
        CancellingMode = False
        If cmbCategory.Items.Count=0 Then
            LoadCombo("Categories", cmbCategory, "CategoryName", "CategoryID")
        End If
    End Sub

    Private Sub Toolbar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles Toolbar1.ButtonClick
        Dim Button As ToolBarButton = e.Button

        Dim x As Object
        'SKS Demo TODO: dcProducts.SetFocus()
        Select Case Button.Text
            Case "Add":
                'Add new record
                NewMode = True
                dcProducts.Recordset.AddNew()
                dcProducts.Recordset("UnitsInStock") = 0
                dcProducts.Recordset("UnitsOnOrder") = 0
            Case "Edit":
                'Edit mode
                EditMode = True
                'dcProducts.Recordset.EditMode =
            Case "Save":
                'Save data
                dcProducts.Recordset.Update()
                EditMode = False
                NewMode = False
            Case "Delete":
                'Delete record
                If MsgBox("Are you sure you want to delete this record?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Delete record")=DialogResult.Yes Then
                    dcProducts.Recordset.Delete()
                    dcProducts.Recordset.Requery()
                End If
            Case "Search":
                'Search for records
                SearchShow("Products", "ProductName", "product")
            Case "Cancel":
                CancellingMode = True
                'Cancel edited changes
                EditMode = False
                NewMode = False
                dcProducts.Recordset.CancelUpdate()
                dcProducts.Recordset.Requery()
                CancellingMode = False
                Close()
        End Select
    End Sub

    'Private Sub txtField_KeyPress(Index As Integer, KeyAscii As Integer)
    'If Index = 0 Then
    '    KeyAscii = Asc(UCase(Chr(KeyAscii)))
    'ElseIf Index = 4 Or Index = 5 Then
    '    Select Case KeyAscii
    '        Case vbKey0 To vbKey9
    '        Case vbKeyBack, vbKeyClear, vbKeyDelete
    '        Case vbKeyLeft, vbKeyRight, vbKeyUp, vbKeyDown, vbKeyTab
    '        Case Else
    '            KeyAscii = 0
    '            Beep
    '    End Select
    'End If
    'End Sub

End Class