
Imports System
Imports System.Windows.Forms

Public Class frmRequestApproval
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents cmdApprove As System.Windows.Forms.Button
    Friend WithEvents cmdInfo As System.Windows.Forms.Button
    Friend WithEvents fgOrders As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbStatus As System.Windows.Forms.ComboBox
    Friend WithEvents chkTo As System.Windows.Forms.CheckBox
    Friend WithEvents chkFrom As System.Windows.Forms.CheckBox
    Friend WithEvents txtProductID As System.Windows.Forms.TextBox
    Friend WithEvents txtOrderID As System.Windows.Forms.TextBox
    Friend WithEvents txtContactLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtContactName As System.Windows.Forms.TextBox
    Friend WithEvents cmdCustomers As System.Windows.Forms.Button
    Friend WithEvents txtCompanyName As System.Windows.Forms.TextBox
    Friend WithEvents dtFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents dtTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmRequestApproval))
        Me.cmdApprove = New System.Windows.Forms.Button()
        Me.cmdInfo = New System.Windows.Forms.Button()
        Me.fgOrders = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmbStatus = New System.Windows.Forms.ComboBox()
        Me.chkTo = New System.Windows.Forms.CheckBox()
        Me.chkFrom = New System.Windows.Forms.CheckBox()
        Me.txtProductID = New System.Windows.Forms.TextBox()
        Me.txtOrderID = New System.Windows.Forms.TextBox()
        Me.txtContactLastName = New System.Windows.Forms.TextBox()
        Me.txtContactName = New System.Windows.Forms.TextBox()
        Me.cmdCustomers = New System.Windows.Forms.Button()
        Me.txtCompanyName = New System.Windows.Forms.TextBox()
        Me.dtFrom = New System.Windows.Forms.DateTimePicker()
        Me.dtTo = New System.Windows.Forms.DateTimePicker()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        CType(Me.fgOrders, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdApprove
        '
        Me.cmdApprove.Name = "cmdApprove"
        Me.cmdApprove.TabIndex = 10
        Me.cmdApprove.Location = New System.Drawing.Point(235, 445)
        Me.cmdApprove.Size = New System.Drawing.Size(90, 25)
        Me.cmdApprove.Text = "&Create Invoice"
        Me.cmdApprove.BackColor = System.Drawing.SystemColors.Control
        Me.cmdApprove.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdInfo
        '
        Me.cmdInfo.Name = "cmdInfo"
        Me.cmdInfo.TabIndex = 9
        Me.cmdInfo.Location = New System.Drawing.Point(138, 445)
        Me.cmdInfo.Size = New System.Drawing.Size(90, 25)
        Me.cmdInfo.Text = "&Information"
        Me.cmdInfo.BackColor = System.Drawing.SystemColors.Control
        Me.cmdInfo.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'fgOrders
        '
        Me.fgOrders.Name = "fgOrders"
        Me.fgOrders.TabIndex = 8
        Me.fgOrders.Location = New System.Drawing.Point(8, 170)
        Me.fgOrders.Size = New System.Drawing.Size(511, 268)
        Me.fgOrders.OcxState = CType(resources.GetObject("fgOrders.OcxState"), System.Windows.Forms.AxHost.State)
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 18
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 476)
        Me.sbStatusBar.Size = New System.Drawing.Size(529, 25)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 527
        '
        'cmdCancel
        '
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.TabIndex = 11
        Me.cmdCancel.Location = New System.Drawing.Point(332, 445)
        Me.cmdCancel.Size = New System.Drawing.Size(90, 25)
        Me.cmdCancel.Text = "&Cancel Order"
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 12
        Me.cmdClose.Location = New System.Drawing.Point(429, 445)
        Me.cmdClose.Size = New System.Drawing.Size(90, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmbStatus, Me.chkTo, Me.chkFrom, Me.txtProductID, Me.txtOrderID, Me.txtContactLastName, Me.txtContactName, Me.cmdCustomers, Me.txtCompanyName, Me.dtFrom, Me.dtTo, Me.Label5, Me.Label8, Me.Label1, Me.Label6, Me.Label3, Me.Label4, Me.Label2})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 13
        Me.Frame1.Location = New System.Drawing.Point(8, 8)
        Me.Frame1.Size = New System.Drawing.Size(511, 155)
        Me.Frame1.Text = "Search customer"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmbStatus
        '
        Me.cmbStatus.Name = "cmbStatus"
        Me.cmbStatus.TabIndex = 1
        Me.cmbStatus.Location = New System.Drawing.Point(340, 16)
        Me.cmbStatus.Size = New System.Drawing.Size(147, 21)
        Me.cmbStatus.Text = ""
        Me.cmbStatus.BackColor = System.Drawing.SystemColors.Window
        Me.cmbStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.cmbStatus.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.cmbStatus.Items.AddRange(New Object() {"All", "Requested", "Cancelled", "Approved"})
        '
        'chkTo
        '
        Me.chkTo.Name = "chkTo"
        Me.chkTo.TabStop = False
        Me.chkTo.TabIndex = 23
        Me.chkTo.Location = New System.Drawing.Point(340, 81)
        Me.chkTo.Size = New System.Drawing.Size(41, 17)
        Me.chkTo.Text = "To:"
        Me.chkTo.BackColor = System.Drawing.SystemColors.Control
        Me.chkTo.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'chkFrom
        '
        Me.chkFrom.Name = "chkFrom"
        Me.chkFrom.TabStop = False
        Me.chkFrom.TabIndex = 22
        Me.chkFrom.Location = New System.Drawing.Point(89, 81)
        Me.chkFrom.Size = New System.Drawing.Size(48, 17)
        Me.chkFrom.Text = "From:"
        Me.chkFrom.BackColor = System.Drawing.SystemColors.Control
        Me.chkFrom.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtProductID
        '
        Me.txtProductID.Name = "txtProductID"
        Me.txtProductID.TabIndex = 7
        Me.txtProductID.Location = New System.Drawing.Point(340, 113)
        Me.txtProductID.Size = New System.Drawing.Size(147, 20)
        Me.txtProductID.Text = ""
        Me.txtProductID.BackColor = System.Drawing.SystemColors.Window
        Me.txtProductID.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtOrderID
        '
        Me.txtOrderID.Name = "txtOrderID"
        Me.txtOrderID.TabIndex = 6
        Me.txtOrderID.Location = New System.Drawing.Point(89, 113)
        Me.txtOrderID.Size = New System.Drawing.Size(147, 20)
        Me.txtOrderID.Text = ""
        Me.txtOrderID.BackColor = System.Drawing.SystemColors.Window
        Me.txtOrderID.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtContactLastName
        '
        Me.txtContactLastName.Name = "txtContactLastName"
        Me.txtContactLastName.TabIndex = 3
        Me.txtContactLastName.Location = New System.Drawing.Point(340, 49)
        Me.txtContactLastName.Size = New System.Drawing.Size(147, 20)
        Me.txtContactLastName.Text = ""
        Me.txtContactLastName.BackColor = System.Drawing.SystemColors.Window
        Me.txtContactLastName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtContactName
        '
        Me.txtContactName.Name = "txtContactName"
        Me.txtContactName.TabIndex = 2
        Me.txtContactName.Location = New System.Drawing.Point(89, 49)
        Me.txtContactName.Size = New System.Drawing.Size(147, 20)
        Me.txtContactName.Text = ""
        Me.txtContactName.BackColor = System.Drawing.SystemColors.Window
        Me.txtContactName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'cmdCustomers
        '
        Me.cmdCustomers.Name = "cmdCustomers"
        Me.cmdCustomers.TabStop = False
        Me.cmdCustomers.TabIndex = 14
        Me.cmdCustomers.Location = New System.Drawing.Point(243, 16)
        Me.cmdCustomers.Size = New System.Drawing.Size(25, 23)
        Me.cmdCustomers.Text = "..."
        Me.cmdCustomers.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCustomers.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtCompanyName
        '
        Me.txtCompanyName.Name = "txtCompanyName"
        Me.txtCompanyName.TabIndex = 0
        Me.txtCompanyName.Location = New System.Drawing.Point(89, 16)
        Me.txtCompanyName.Size = New System.Drawing.Size(147, 20)
        Me.txtCompanyName.Text = ""
        Me.txtCompanyName.BackColor = System.Drawing.SystemColors.Window
        Me.txtCompanyName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'dtFrom
        '
        Me.dtFrom.Name = "dtFrom"
        Me.dtFrom.TabIndex = 4
        Me.dtFrom.Location = New System.Drawing.Point(138, 81)
        Me.dtFrom.Size = New System.Drawing.Size(98, 20)
        '
        'dtTo
        '
        Me.dtTo.Name = "dtTo"
        Me.dtTo.TabIndex = 5
        Me.dtTo.Location = New System.Drawing.Point(388, 81)
        Me.dtTo.Size = New System.Drawing.Size(98, 20)
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 24
        Me.Label5.Location = New System.Drawing.Point(291, 16)
        Me.Label5.Size = New System.Drawing.Size(41, 17)
        Me.Label5.Text = "Status:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 21
        Me.Label8.Location = New System.Drawing.Point(259, 113)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Product code:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 20
        Me.Label1.Location = New System.Drawing.Point(8, 113)
        Me.Label1.Size = New System.Drawing.Size(90, 17)
        Me.Label1.Text = "Order number:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 19
        Me.Label6.Location = New System.Drawing.Point(8, 81)
        Me.Label6.Size = New System.Drawing.Size(66, 17)
        Me.Label6.Text = "Date range:"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 17
        Me.Label3.Location = New System.Drawing.Point(243, 49)
        Me.Label3.Size = New System.Drawing.Size(98, 17)
        Me.Label3.Text = "Contact last name:"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 16
        Me.Label4.Location = New System.Drawing.Point(8, 16)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Company name:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 15
        Me.Label2.Location = New System.Drawing.Point(8, 49)
        Me.Label2.Size = New System.Drawing.Size(90, 17)
        Me.Label2.Text = "Contact name:"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmRequestApproval
        '
        Me.ClientSize = New System.Drawing.Size(529, 502)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdApprove, Me.cmdInfo, Me.fgOrders, Me.sbStatusBar, Me.cmdCancel, Me.cmdClose, Me.Frame1})
        Me.Name = "frmRequestApproval"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Create Invoice"
        CType(Me.fgOrders, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Private Id As String


    Private Sub cmbStatus_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbStatus.SelectedIndexChanged
        DoSearchRequest()
    End Sub

    Private Sub cmdApprove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApprove.Click
        LoadActionOrderRequest(1)
    End Sub

    Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        LoadActionOrderRequest(2)
    End Sub

    Private Sub cmdInfo_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdInfo.Click
        cmdInfo_Click()
    End Sub
    Public Sub cmdInfo_Click()
        LoadActionOrderRequest()
    End Sub

    Private Sub LoadActionOrderRequest(Optional ByVal Action As Short = 0)
        If fgOrders.Row>0 Then
            Dim OrderId As Short
            With frmActionOrderRequest
                OrderId = CInt(fgOrders.get_TextMatrix(fgOrders.Row, 1))
                .OrderId = OrderId
                .Action = Action
                .LoadData()
                ShowAsMdiChild(frmActionOrderRequest) 'vbModal
            End With
        End If
    End Sub

    Private Sub dtFrom_ValueChanged(ByVal sender As object, ByVal e As System.EventArgs) Handles dtFrom.ValueChanged
        chkFrom.CheckState = CheckState.Checked
        DoSearchRequest()
    End Sub

    Private Sub dtTo_ValueChanged(ByVal sender As object, ByVal e As System.EventArgs) Handles dtTo.ValueChanged
        chkTo.CheckState = CheckState.Checked
        DoSearchRequest()
    End Sub


    Private Sub fgOrders_DblClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles fgOrders.DblClick
        cmdInfo_Click()
    End Sub

    Private Sub frmRequestApproval_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InitGrid()
    End Sub

    Private Sub txtOrderID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtOrderID.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchRequest()
    End Sub

    Private Sub txtProductID_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtProductID.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchRequest()
    End Sub

    Private Sub txtCompanyName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCompanyName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchRequest()
    End Sub

    Private Sub txtContactLastName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactLastName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchRequest()
    End Sub

    Private Sub txtContactName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtContactName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchRequest()
    End Sub

'#Const defUse_txtName_Change = True
#If defUse_txtName_Change Then
    Private Sub txtName_Change()
        DoSearchRequest()
    End Sub
#End If

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdCustomers_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCustomers.Click
        frmCustomers.ShowDialog()
        txtCompanyName.Text = ""
        txtContactLastName.Text = ""
        txtContactName.Text = ""
        DoSearchRequest(frmCustomers.CurrentCustomerID)
        frmCustomers.Hide()
    End Sub

    ' VBto upgrade warning: Id As Short	OnWrite(String)
    Private Sub DoSearchRequest(Optional ByVal Id As Short = -1)
        Dim filter As String
        filter = ""
        If Id<>-1 Then
            filter = "o.CustomerID = " & Id
        End If
        If txtCompanyName.Text<>Nothing Then
            AppendAND(filter)
            filter = "c.CompanyName LIKE '%" & txtCompanyName.Text & "%'"
        End If
        If txtContactName.Text<>Nothing Then
            AppendAND(filter)
            filter &= "c.ContactFirstName LIKE '%" & txtContactName.Text & "%'"
        End If
        If txtContactLastName.Text<>Nothing Then
            AppendAND(filter)
            filter &= "c.ContactLastName LIKE '%" & txtContactLastName.Text & "%'"
        End If
        If txtOrderID.Text<>Nothing Then
            AppendAND(filter)
            filter &= "o.OrderID = " & txtOrderID.Text
        End If
        If txtProductID.Text<>Nothing Then
            AppendAND(filter)
            filter &= "d.ProductID LIKE '%" & txtProductID.Text & "%'"
        End If
        If chkFrom.CheckState=CheckState.Checked Then
            AppendAND(filter)
            filter &= "o.OrderDate >= #" & vbFormat(dtFrom.value, "mm/dd/yyyy") & "#"
        End If
        If chkTo.CheckState=CheckState.Checked Then
            AppendAND(filter)
            filter &= "o.OrderDate <= #" & vbFormat(dtTo.value, "mm/dd/yyyy") & "#"
        End If
        If cmbStatus.SelectedIndex<>-1 And cmbStatus.Text<>"All" Then
            AppendAND(filter)
            filter &= "o.Status = '" & cmbStatus.Text & "'"
        End If

        Dim mwhere As String
        mwhere = " Where o.OrderID = d.OrderID And c.CustomerID = o.CustomerID And u.Username = o.EmployeeId "
        If filter<>Nothing Then
            filter = mwhere & " AND " & filter
        Else
            filter = mwhere
        End If

        Dim sql As String

        sql = "Select o.OrderDate, o.OrderID, c.CompanyName, c.ContactFirstName + ' ' + c.ContactLastName as ContactName, u.Fullname as [Received by], Sum(d.LineTotal) as Price, o.Status " & "From OrderRequests as o, OrderRequestDetails as d, Customers as c, Users as u " & filter & " Group by o.orderDate, o.OrderID, c.CompanyName, c.ContactFirstName + ' ' + c.ContactLastName, u.Fullname, o.Status "
        ExecuteSql(sql)
        LogStatus("There are " & rs.RecordCount & " records with the selected criteria", Me)
        With fgOrders
            .Rows = rs.RecordCount+1
            If .Rows=1 Then .FixedRows = 0 Else .FixedRows = 1
            Dim i As Short
            Dim j As Integer
            i = 1
            While  Not rs.EOF
                For j = 0 To rs.ColumnCount-1
                    If  Not (rs.Fields(j) Is Nothing) Then
                        .set_TextMatrix(i, j, Convert.ToString(rs.Fields(j).Value))
                    End If
                Next j
                rs.MoveNext()
                i += 1
            End While
        End With
    End Sub

    Private Sub InitGrid()
        With fgOrders
            .Rows = 0
            .Cols = 7
            .FixedCols = 0
            .AddItem("Date" & vbTab & "Order" & vbTab & "Customer" & vbTab & "Contact" & vbTab & "Received by" & vbTab & "Price" & vbTab & "Status")
            .Rows = 1
            .FixedRows = 0
            .SelectionMode = MSFlexGridLib.SelectionModeSettings.flexSelectionByRow
        End With
    End Sub

    ' '''''''''''''''''''''''''''''
    ' ''UNUSED CODE Start



'#Const defUse_MakeTextBoxVisible = True
#If defUse_MakeTextBoxVisible Then
    Private Sub MakeTextBoxVisible(ByVal txtBox As TextBox, ByVal grid As AxMSFlexGridLib.AxMSFlexGrid)
        With grid
            txtBox.Text = .get_TextMatrix(.Row, .Col)
            txtBox.SetBounds(.CellLeft+.Left, .CellTop+.Top, .CellWidth, .CellHeight, BoundsSpecified.Location Or BoundsSpecified.Size)
            txtBox.Visible = True
            Application.DoEvents()
            txtBox.Focus()
        End With
    End Sub
#End If



End Class