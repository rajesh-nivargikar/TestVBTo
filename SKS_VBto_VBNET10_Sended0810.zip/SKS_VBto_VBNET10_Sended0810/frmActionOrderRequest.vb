
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmActionOrderRequest
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtPromisedBy As System.Windows.Forms.TextBox
    Friend WithEvents txtRequiredBy As System.Windows.Forms.TextBox
    Friend WithEvents txtReceivedBy As System.Windows.Forms.TextBox
    Friend WithEvents cmdApprove As System.Windows.Forms.Button
    Friend WithEvents txtStatus As System.Windows.Forms.TextBox
    Friend WithEvents txtReceived As System.Windows.Forms.TextBox
    Friend WithEvents txtChangedBy As System.Windows.Forms.TextBox
    Friend WithEvents txtChanged As System.Windows.Forms.TextBox
    Friend WithEvents txtOrderID As System.Windows.Forms.TextBox
    Friend WithEvents txtNotes As System.Windows.Forms.TextBox
    Friend WithEvents txtSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalTax As System.Windows.Forms.TextBox
    Friend WithEvents txtFreightCharge As System.Windows.Forms.TextBox
    Friend WithEvents txtSalesTax As System.Windows.Forms.TextBox
    Friend WithEvents txtEntry As System.Windows.Forms.TextBox
    Friend WithEvents fgDetails As AxMSFlexGridLib.AxMSFlexGrid
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents cmdCancel As System.Windows.Forms.Button
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents Frame2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtCustomerContact As System.Windows.Forms.TextBox
    Friend WithEvents txtCustomerCompany As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents lblChangedBy As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents lblChanged As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmActionOrderRequest))
        Me.txtPromisedBy = New System.Windows.Forms.TextBox()
        Me.txtRequiredBy = New System.Windows.Forms.TextBox()
        Me.txtReceivedBy = New System.Windows.Forms.TextBox()
        Me.cmdApprove = New System.Windows.Forms.Button()
        Me.txtStatus = New System.Windows.Forms.TextBox()
        Me.txtReceived = New System.Windows.Forms.TextBox()
        Me.txtChangedBy = New System.Windows.Forms.TextBox()
        Me.txtChanged = New System.Windows.Forms.TextBox()
        Me.txtOrderID = New System.Windows.Forms.TextBox()
        Me.txtNotes = New System.Windows.Forms.TextBox()
        Me.txtSubTotal = New System.Windows.Forms.TextBox()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.txtTotalTax = New System.Windows.Forms.TextBox()
        Me.txtFreightCharge = New System.Windows.Forms.TextBox()
        Me.txtSalesTax = New System.Windows.Forms.TextBox()
        Me.txtEntry = New System.Windows.Forms.TextBox()
        Me.fgDetails = New AxMSFlexGridLib.AxMSFlexGrid()
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.txtCustomerContact = New System.Windows.Forms.TextBox()
        Me.txtCustomerCompany = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.lblChangedBy = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.lblChanged = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        CType(Me.fgDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'txtPromisedBy
        '
        Me.txtPromisedBy.Name = "txtPromisedBy"
        Me.txtPromisedBy.TabStop = False
        Me.txtPromisedBy.TabIndex = 38
        Me.txtPromisedBy.Location = New System.Drawing.Point(372, 202)
        Me.txtPromisedBy.Size = New System.Drawing.Size(106, 20)
        Me.txtPromisedBy.Text = ""
        Me.txtPromisedBy.BackColor = System.Drawing.SystemColors.Menu
        Me.txtPromisedBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtPromisedBy.ReadOnly = True
        '
        'txtRequiredBy
        '
        Me.txtRequiredBy.Name = "txtRequiredBy"
        Me.txtRequiredBy.TabStop = False
        Me.txtRequiredBy.TabIndex = 37
        Me.txtRequiredBy.Location = New System.Drawing.Point(121, 202)
        Me.txtRequiredBy.Size = New System.Drawing.Size(106, 20)
        Me.txtRequiredBy.Text = ""
        Me.txtRequiredBy.BackColor = System.Drawing.SystemColors.Menu
        Me.txtRequiredBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtRequiredBy.ReadOnly = True
        '
        'txtReceivedBy
        '
        Me.txtReceivedBy.Name = "txtReceivedBy"
        Me.txtReceivedBy.TabStop = False
        Me.txtReceivedBy.TabIndex = 33
        Me.txtReceivedBy.Location = New System.Drawing.Point(97, 65)
        Me.txtReceivedBy.Size = New System.Drawing.Size(106, 20)
        Me.txtReceivedBy.Text = ""
        Me.txtReceivedBy.BackColor = System.Drawing.SystemColors.Menu
        Me.txtReceivedBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtReceivedBy.ReadOnly = True
        '
        'cmdApprove
        '
        Me.cmdApprove.Name = "cmdApprove"
        Me.cmdApprove.TabIndex = 0
        Me.cmdApprove.Location = New System.Drawing.Point(235, 485)
        Me.cmdApprove.Size = New System.Drawing.Size(90, 25)
        Me.cmdApprove.Text = "&Create Invoice"
        Me.cmdApprove.BackColor = System.Drawing.SystemColors.Control
        Me.cmdApprove.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtStatus
        '
        Me.txtStatus.Name = "txtStatus"
        Me.txtStatus.TabStop = False
        Me.txtStatus.TabIndex = 31
        Me.txtStatus.Location = New System.Drawing.Point(413, 8)
        Me.txtStatus.Size = New System.Drawing.Size(106, 20)
        Me.txtStatus.Text = ""
        Me.txtStatus.BackColor = System.Drawing.SystemColors.Menu
        Me.txtStatus.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtStatus.ReadOnly = True
        '
        'txtReceived
        '
        Me.txtReceived.Name = "txtReceived"
        Me.txtReceived.TabStop = False
        Me.txtReceived.TabIndex = 29
        Me.txtReceived.Location = New System.Drawing.Point(97, 36)
        Me.txtReceived.Size = New System.Drawing.Size(106, 20)
        Me.txtReceived.Text = ""
        Me.txtReceived.BackColor = System.Drawing.SystemColors.Menu
        Me.txtReceived.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtReceived.ReadOnly = True
        '
        'txtChangedBy
        '
        Me.txtChangedBy.Name = "txtChangedBy"
        Me.txtChangedBy.TabStop = False
        Me.txtChangedBy.TabIndex = 25
        Me.txtChangedBy.Location = New System.Drawing.Point(413, 65)
        Me.txtChangedBy.Size = New System.Drawing.Size(106, 20)
        Me.txtChangedBy.Text = ""
        Me.txtChangedBy.BackColor = System.Drawing.SystemColors.Menu
        Me.txtChangedBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtChangedBy.ReadOnly = True
        '
        'txtChanged
        '
        Me.txtChanged.Name = "txtChanged"
        Me.txtChanged.TabStop = False
        Me.txtChanged.TabIndex = 24
        Me.txtChanged.Location = New System.Drawing.Point(413, 36)
        Me.txtChanged.Size = New System.Drawing.Size(106, 20)
        Me.txtChanged.Text = ""
        Me.txtChanged.BackColor = System.Drawing.SystemColors.Menu
        Me.txtChanged.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtChanged.ReadOnly = True
        '
        'txtOrderID
        '
        Me.txtOrderID.Name = "txtOrderID"
        Me.txtOrderID.TabStop = False
        Me.txtOrderID.TabIndex = 23
        Me.txtOrderID.Location = New System.Drawing.Point(97, 8)
        Me.txtOrderID.Size = New System.Drawing.Size(106, 20)
        Me.txtOrderID.Text = ""
        Me.txtOrderID.BackColor = System.Drawing.SystemColors.Menu
        Me.txtOrderID.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtOrderID.ReadOnly = True
        '
        'txtNotes
        '
        Me.txtNotes.Name = "txtNotes"
        Me.txtNotes.TabStop = False
        Me.txtNotes.TabIndex = 3
        Me.txtNotes.Location = New System.Drawing.Point(57, 154)
        Me.txtNotes.Size = New System.Drawing.Size(462, 44)
        Me.txtNotes.Text = ""
        Me.txtNotes.BackColor = System.Drawing.SystemColors.Menu
        Me.txtNotes.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtNotes.Multiline = True
        Me.txtNotes.ReadOnly = True
        '
        'txtSubTotal
        '
        Me.txtSubTotal.Name = "txtSubTotal"
        Me.txtSubTotal.TabStop = False
        Me.txtSubTotal.TabIndex = 21
        Me.txtSubTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSubTotal.Location = New System.Drawing.Point(372, 437)
        Me.txtSubTotal.Size = New System.Drawing.Size(147, 20)
        Me.txtSubTotal.Text = ""
        Me.txtSubTotal.BackColor = System.Drawing.SystemColors.Menu
        Me.txtSubTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSubTotal.ReadOnly = True
        '
        'txtTotal
        '
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.TabStop = False
        Me.txtTotal.TabIndex = 19
        Me.txtTotal.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotal.Location = New System.Drawing.Point(89, 461)
        Me.txtTotal.Size = New System.Drawing.Size(147, 20)
        Me.txtTotal.Text = ""
        Me.txtTotal.BackColor = System.Drawing.SystemColors.Menu
        Me.txtTotal.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotal.ReadOnly = True
        '
        'txtTotalTax
        '
        Me.txtTotalTax.Name = "txtTotalTax"
        Me.txtTotalTax.TabStop = False
        Me.txtTotalTax.TabIndex = 17
        Me.txtTotalTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtTotalTax.Location = New System.Drawing.Point(372, 413)
        Me.txtTotalTax.Size = New System.Drawing.Size(147, 20)
        Me.txtTotalTax.Text = ""
        Me.txtTotalTax.BackColor = System.Drawing.SystemColors.Menu
        Me.txtTotalTax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtTotalTax.ReadOnly = True
        '
        'txtFreightCharge
        '
        Me.txtFreightCharge.Name = "txtFreightCharge"
        Me.txtFreightCharge.TabStop = False
        Me.txtFreightCharge.TabIndex = 6
        Me.txtFreightCharge.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtFreightCharge.Location = New System.Drawing.Point(89, 437)
        Me.txtFreightCharge.Size = New System.Drawing.Size(147, 20)
        Me.txtFreightCharge.Text = ""
        Me.txtFreightCharge.BackColor = System.Drawing.SystemColors.Menu
        Me.txtFreightCharge.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtFreightCharge.ReadOnly = True
        '
        'txtSalesTax
        '
        Me.txtSalesTax.Name = "txtSalesTax"
        Me.txtSalesTax.TabStop = False
        Me.txtSalesTax.TabIndex = 5
        Me.txtSalesTax.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.txtSalesTax.Location = New System.Drawing.Point(89, 413)
        Me.txtSalesTax.Size = New System.Drawing.Size(147, 20)
        Me.txtSalesTax.Text = ""
        Me.txtSalesTax.BackColor = System.Drawing.SystemColors.Menu
        Me.txtSalesTax.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtSalesTax.ReadOnly = True
        '
        'txtEntry
        '
        Me.txtEntry.Name = "txtEntry"
        Me.txtEntry.Visible = False
        Me.txtEntry.TabIndex = 14
        Me.txtEntry.Location = New System.Drawing.Point(421, 340)
        Me.txtEntry.Size = New System.Drawing.Size(74, 19)
        Me.txtEntry.Text = ""
        Me.txtEntry.BackColor = System.Drawing.SystemColors.Window
        Me.txtEntry.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtEntry.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtEntry.BorderStyle = System.Windows.Forms.BorderStyle.None
        '
        'fgDetails
        '
        Me.fgDetails.Name = "fgDetails"
        Me.fgDetails.TabStop = False
        Me.fgDetails.TabIndex = 4
        Me.fgDetails.Location = New System.Drawing.Point(8, 227)
        Me.fgDetails.Size = New System.Drawing.Size(511, 179)
        Me.fgDetails.OcxState = CType(resources.GetObject("fgDetails.OcxState"), System.Windows.Forms.AxHost.State)
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 13
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 515)
        Me.sbStatusBar.Size = New System.Drawing.Size(529, 25)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 509
        '
        'cmdCancel
        '
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.TabIndex = 1
        Me.cmdCancel.Location = New System.Drawing.Point(332, 485)
        Me.cmdCancel.Size = New System.Drawing.Size(90, 25)
        Me.cmdCancel.Text = "&Cancel Order"
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 2
        Me.cmdClose.Location = New System.Drawing.Point(429, 485)
        Me.cmdClose.Size = New System.Drawing.Size(90, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame2
        '
        Me.Frame2.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtCustomerContact, Me.txtCustomerCompany, Me.Label5, Me.Label1})
        Me.Frame2.Name = "Frame2"
        Me.Frame2.TabIndex = 7
        Me.Frame2.Location = New System.Drawing.Point(8, 97)
        Me.Frame2.Size = New System.Drawing.Size(511, 50)
        Me.Frame2.Text = "Customer"
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtCustomerContact
        '
        Me.txtCustomerContact.Name = "txtCustomerContact"
        Me.txtCustomerContact.TabStop = False
        Me.txtCustomerContact.TabIndex = 11
        Me.txtCustomerContact.Location = New System.Drawing.Point(291, 16)
        Me.txtCustomerContact.Size = New System.Drawing.Size(211, 20)
        Me.txtCustomerContact.Text = ""
        Me.txtCustomerContact.BackColor = System.Drawing.SystemColors.Menu
        Me.txtCustomerContact.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustomerContact.ReadOnly = True
        '
        'txtCustomerCompany
        '
        Me.txtCustomerCompany.Name = "txtCustomerCompany"
        Me.txtCustomerCompany.TabStop = False
        Me.txtCustomerCompany.TabIndex = 10
        Me.txtCustomerCompany.Location = New System.Drawing.Point(73, 16)
        Me.txtCustomerCompany.Size = New System.Drawing.Size(147, 20)
        Me.txtCustomerCompany.Text = ""
        Me.txtCustomerCompany.BackColor = System.Drawing.SystemColors.Menu
        Me.txtCustomerCompany.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtCustomerCompany.ReadOnly = True
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 9
        Me.Label5.Location = New System.Drawing.Point(8, 16)
        Me.Label5.Size = New System.Drawing.Size(58, 17)
        Me.Label5.Text = "Name:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 8
        Me.Label1.Location = New System.Drawing.Point(235, 16)
        Me.Label1.Size = New System.Drawing.Size(58, 17)
        Me.Label1.Text = "Contact:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label13
        '
        Me.Label13.Name = "Label13"
        Me.Label13.TabIndex = 36
        Me.Label13.Location = New System.Drawing.Point(16, 202)
        Me.Label13.Size = New System.Drawing.Size(106, 17)
        Me.Label13.Text = "Required by date:"
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 35
        Me.Label2.Location = New System.Drawing.Point(267, 202)
        Me.Label2.Size = New System.Drawing.Size(106, 17)
        Me.Label2.Text = "Promised by date:"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 34
        Me.Label7.Location = New System.Drawing.Point(8, 65)
        Me.Label7.Size = New System.Drawing.Size(74, 17)
        Me.Label7.Text = "Requested by:"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 32
        Me.Label3.Location = New System.Drawing.Point(324, 8)
        Me.Label3.Size = New System.Drawing.Size(50, 17)
        Me.Label3.Text = "Status:"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label19
        '
        Me.Label19.Name = "Label19"
        Me.Label19.TabIndex = 30
        Me.Label19.Location = New System.Drawing.Point(8, 32)
        Me.Label19.Size = New System.Drawing.Size(58, 17)
        Me.Label19.Text = "Requested:"
        Me.Label19.BackColor = System.Drawing.SystemColors.Control
        Me.Label19.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblChangedBy
        '
        Me.lblChangedBy.Name = "lblChangedBy"
        Me.lblChangedBy.TabIndex = 28
        Me.lblChangedBy.Location = New System.Drawing.Point(324, 65)
        Me.lblChangedBy.Size = New System.Drawing.Size(90, 17)
        Me.lblChangedBy.Text = "Changed by:"
        Me.lblChangedBy.BackColor = System.Drawing.SystemColors.Control
        Me.lblChangedBy.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 27
        Me.Label4.Location = New System.Drawing.Point(12, 8)
        Me.Label4.Size = New System.Drawing.Size(50, 17)
        Me.Label4.Text = "Order Id:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lblChanged
        '
        Me.lblChanged.Name = "lblChanged"
        Me.lblChanged.TabIndex = 26
        Me.lblChanged.Location = New System.Drawing.Point(324, 36)
        Me.lblChanged.Size = New System.Drawing.Size(90, 17)
        Me.lblChanged.Text = "Changed:"
        Me.lblChanged.BackColor = System.Drawing.SystemColors.Control
        Me.lblChanged.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label12
        '
        Me.Label12.Name = "Label12"
        Me.Label12.TabIndex = 22
        Me.Label12.Location = New System.Drawing.Point(8, 437)
        Me.Label12.Size = New System.Drawing.Size(90, 17)
        Me.Label12.Text = "Freight Charge:"
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label11
        '
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 20
        Me.Label11.Location = New System.Drawing.Point(8, 461)
        Me.Label11.Size = New System.Drawing.Size(90, 17)
        Me.Label11.Text = "Total:"
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label10
        '
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 18
        Me.Label10.Location = New System.Drawing.Point(291, 413)
        Me.Label10.Size = New System.Drawing.Size(90, 17)
        Me.Label10.Text = "Total Tax:"
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label9
        '
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 16
        Me.Label9.Location = New System.Drawing.Point(291, 437)
        Me.Label9.Size = New System.Drawing.Size(90, 17)
        Me.Label9.Text = "Sub Total:"
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 15
        Me.Label8.Location = New System.Drawing.Point(8, 413)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Sales Tax:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 12
        Me.Label6.Location = New System.Drawing.Point(8, 162)
        Me.Label6.Size = New System.Drawing.Size(33, 17)
        Me.Label6.Text = "Notes:"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmActionOrderRequest
        '
        Me.ClientSize = New System.Drawing.Size(529, 540)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtPromisedBy, Me.txtRequiredBy, Me.txtReceivedBy, Me.cmdApprove, Me.txtStatus, Me.txtReceived, Me.txtChangedBy, Me.txtChanged, Me.txtOrderID, Me.txtNotes, Me.txtSubTotal, Me.txtTotal, Me.txtTotalTax, Me.txtFreightCharge, Me.txtSalesTax, Me.txtEntry, Me.fgDetails, Me.sbStatusBar, Me.cmdCancel, Me.cmdClose, Me.Frame2, Me.Label13, Me.Label2, Me.Label7, Me.Label3, Me.Label19, Me.lblChangedBy, Me.Label4, Me.lblChanged, Me.Label12, Me.Label11, Me.Label10, Me.Label9, Me.Label8, Me.Label6})
        Me.Name = "frmActionOrderRequest"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.WindowsDefaultLocation
        Me.Text = "Create Invoice"
        CType(Me.fgDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    Private currentSubTotal As Double
    Private currentTotal As Double
    ' VBto upgrade warning: currentTax As Double	OnWrite(Object)
    Private currentTax As Double
    ' VBto upgrade warning: currentFreightCharge As Double	OnWrite(Object)
    Private currentFreightCharge As Double
    Private currentTotalTax As Double

    Public Action As Short

    Public OrderId As Short

    Private Sub cmdApprove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdApprove.Click
        cmdApprove_Click()
    End Sub
    Public Sub cmdApprove_Click()
        Try ' On Error GoTo HandleError
            If UCase(txtStatus.Text)="APPROVED" Then
                LogStatus("Order is already approved, not need to be approved again", Me)
                Exit Sub
            End If

            If UCase(txtStatus.Text)="CANCELLED" Then
                LogStatus("Order was already approved by " & txtChangedBy.Text & " on " & txtChanged.Text & ", it cannot be approved", Me)
                Exit Sub
            End If
            Exit Sub

            Exit Sub
        Catch	' HandleError:
            ' ...
        End Try
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")

    End Sub

    Private Sub cmdCancel_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdCancel.Click
        cmdCancel_Click()
    End Sub
    Public Sub cmdCancel_Click()
        Try ' On Error GoTo HandleError
            If UCase(txtStatus.Text)="CANCELLED" Then
                LogStatus("Order was already cancelled, not need to be cancelled again", Me)
                Exit Sub
            End If
            If UCase(txtStatus.Text)="APPROVED" Then
                LogStatus("Order was already cancelled by " & txtChangedBy.Text & " on " & txtChanged.Text & ", it cannot be canceled", Me)
                Exit Sub
            End If


            If MsgBox("Do you want to cancel the order request?", MsgBoxStyle.YesNo Or MsgBoxStyle.Question, "Confirm cancellation")<>DialogResult.Yes Then
                Exit Sub
            End If

            ' UPDATE
            ExecuteSql("Update OrderRequests Set Status = 'CANCELLED', ChangedBy = '" & UserId & "', ChangedDate = #" & Today & "#" & " Where OrderId = " & OrderId)

            LoadData()
            MsgBox("The order was successfully cancelled")
            Close()

            Exit Sub
        Catch	' HandleError:
            ' ...
        End Try
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")

    End Sub

    Private Sub frmActionOrderRequest_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'LoadData
        If Action<>0 Then

            Select Case (Action)
                Case 1:
                    cmdApprove_Click()
                Case 2:
                    cmdCancel_Click()
            End Select
        End If
    End Sub

    Public Sub LoadData()
        currentSubTotal = 0
        currentTotalTax = 0
        ExecuteSql("Select o.OrderDate, u.Fullname, o.Status, c.CompanyName, c.ContactFirstName + ' ' + c.ContactLastName as Contact, o.ChangedDate, o.ChangedBy, o.FreightCharge, o.SalesTaxRate, o.RequiredByDate, o.PromisedByDate, o.Notes " & "From OrderRequests as o, Users as u, Customers as c " & "Where o.OrderID = " & OrderId & " And u.Username = o.EmployeeId And c.CustomerId = o.CustomerId")
        If rs.EOF Then
            LogStatus("The order with the ID '" & OrderId & "' does not exist", Me)
            Exit Sub
        End If
        txtOrderID.Text = OrderId
        txtReceived.Text = Convert.ToString(rs.Fields("OrderDate").Value)
        txtReceivedBy.Text = Convert.ToString(rs.Fields("Fullname").Value)
        If rs.Fields("Notes").Value<>IntPtr.Zero Then txtNotes.Text = Convert.ToString(rs.Fields("Notes").Value)
        txtFreightCharge.Text = Convert.ToString(rs.Fields("FreightCharge").Value)
        currentFreightCharge = rs.Fields("FreightCharge").Value
        txtSalesTax.Text = Convert.ToString(rs.Fields("SalesTaxRate").Value)
        currentTax = rs.Fields("SalesTaxRate").Value
        txtCustomerCompany.Text = Convert.ToString(rs.Fields("CompanyName").Value)
        txtCustomerContact.Text = Convert.ToString(rs.Fields("Contact").Value)
        txtStatus.Text = Convert.ToString(rs.Fields("Status").Value)
        txtRequiredBy.Text = Convert.ToString(rs.Fields("RequiredByDate").Value)
        txtPromisedBy.Text = Convert.ToString(rs.Fields("PromisedByDate").Value)
        If rs.Fields("ChangedDate").Value<>IntPtr.Zero Then txtChanged.Text = Convert.ToString(rs.Fields("ChangedDate").Value)
        If rs.Fields("ChangedBy").Value<>IntPtr.Zero Then txtChangedBy.Text = Convert.ToString(rs.Fields("ChangedBy").Value)

        Dim isRequested As Boolean
        isRequested = txtStatus.Text="REQUESTED"
        lblChanged.Visible =  Not isRequested
        lblChangedBy.Visible =  Not isRequested
        txtChanged.Visible =  Not isRequested
        txtChangedBy.Visible =  Not isRequested
        cmdApprove.Enabled = True ' Requested
        cmdCancel.Enabled = True ' Requested

        If txtStatus.Text="APPROVED" Then
            lblChanged.Text = "Approved Date:"
            lblChangedBy.Text = "Approved By:"
        Else
            lblChanged.Text = "Cancelled Date:"
            lblChangedBy.Text = "Cancelled By:"
        End If
        LoadDetails()
        DisplayTotals()
    End Sub

    Private Sub DisplayTotals()
        currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax
        txtSubTotal.Text = vbFormat(currentSubTotal, "#,##0.00")
        txtTotalTax.Text = vbFormat(currentTotalTax, "#,##0.00")
        txtTotal.Text = vbFormat(currentTotal, "#,##0.00")
    End Sub


    ' VBto upgrade warning: current As Double	OnWrite(VBtoField)
    Private Sub AddToTotals(ByVal current As Double)
        currentSubTotal += current
        currentTotalTax = currentSubTotal*currentTax
        currentTotal = currentFreightCharge+currentSubTotal+currentTotalTax
        txtSubTotal.Text = vbFormat(currentSubTotal, "#,##0.00")
        txtTotalTax.Text = vbFormat(currentTotalTax, "#,##0.00")
        txtTotal.Text = vbFormat(currentTotal, "#,##0.00")
    End Sub


    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub LoadDetails()

        ExecuteSql("Select d.Quantity, p.ProductID, p.ProductName, d.UnitPrice, d.SalePrice, p.UnitsInStock, p.UnitsOnOrder, Str(p.QuantityPerUnit) + p.Unit, d.LineTotal From Products as p, OrderRequestDetails as d " & "Where d.OrderID = " & OrderId & " And d.ProductId = p.ProductId")

        Dim lng As Integer
        Dim intLoopCount As Short
        With fgDetails
            .Rows = 0
            .Cols = 9
            .FixedCols = 0
            .AddItem("Quantity" & vbTab & "Code" & vbTab & "Product" & vbTab & "UnitPrice" & vbTab & "Price" & vbTab & "Existence" & vbTab & "Ordered" & vbTab & "Quantity per unit" & vbTab & "Line Total")
            .Rows = rs.RecordCount+1
            If .Rows=1 Then .FixedRows = 0 Else .FixedRows = 1
            Dim i As Short
            Dim j As Integer
            i = 1
            While  Not rs.EOF
                For j = 1 To rs.ColumnCount
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        .set_TextMatrix(i, j-1, Convert.ToString(rs.Fields(j-1).Value))
                    End If
                Next j
                AddToTotals(rs.Fields("LineTotal").Value)
                rs.MoveNext()
                i += 1
            End While
        End With

    End Sub


End Class