
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic
Imports Microsoft.VisualBasic.Compatibility.VB6
Imports ADODB

Public Class frmProviders
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents txtField As Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray
    Friend WithEvents dcProviders As Microsoft.VisualBasic.Compatibility.VB6.ADODC
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtField_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_4 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_0 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_6 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_7 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_5 As System.Windows.Forms.TextBox
    Friend WithEvents Frame2 As System.Windows.Forms.GroupBox
    Friend WithEvents txtField_11 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_13 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_12 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents txtField_8 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_10 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_14 As System.Windows.Forms.TextBox
    Friend WithEvents txtField_9 As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ImageList1 As System.Windows.Forms.ImageList
    Friend WithEvents Toolbar1 As System.Windows.Forms.ToolBar
    Friend WithEvents Button1 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button2 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button3 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button4 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button5 As System.Windows.Forms.ToolBarButton
    Friend WithEvents Button6 As System.Windows.Forms.ToolBarButton
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmProviders))
        Me.components = New System.ComponentModel.Container()
        Me.txtField = New Microsoft.VisualBasic.Compatibility.VB6.TextBoxArray(components)
        Me.dcProviders = New Microsoft.VisualBasic.Compatibility.VB6.ADODC()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.txtField_1 = New System.Windows.Forms.TextBox()
        Me.txtField_4 = New System.Windows.Forms.TextBox()
        Me.txtField_0 = New System.Windows.Forms.TextBox()
        Me.txtField_6 = New System.Windows.Forms.TextBox()
        Me.txtField_7 = New System.Windows.Forms.TextBox()
        Me.txtField_2 = New System.Windows.Forms.TextBox()
        Me.txtField_5 = New System.Windows.Forms.TextBox()
        Me.Frame2 = New System.Windows.Forms.GroupBox()
        Me.txtField_11 = New System.Windows.Forms.TextBox()
        Me.txtField_13 = New System.Windows.Forms.TextBox()
        Me.txtField_12 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtField_8 = New System.Windows.Forms.TextBox()
        Me.txtField_10 = New System.Windows.Forms.TextBox()
        Me.txtField_14 = New System.Windows.Forms.TextBox()
        Me.txtField_9 = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.Toolbar1 = New System.Windows.Forms.ToolBar()
        Me.Button1 = New System.Windows.Forms.ToolBarButton()
        Me.Button2 = New System.Windows.Forms.ToolBarButton()
        Me.Button3 = New System.Windows.Forms.ToolBarButton()
        Me.Button4 = New System.Windows.Forms.ToolBarButton()
        Me.Button5 = New System.Windows.Forms.ToolBarButton()
        Me.Button6 = New System.Windows.Forms.ToolBarButton()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.SuspendLayout()
        CType(Me.txtField, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'dcProviders
        '
        Me.dcProviders.Name = "dcProviders"
        Me.dcProviders.Enabled = True
        Me.dcProviders.Location = New System.Drawing.Point(8, 413)
        Me.dcProviders.Size = New System.Drawing.Size(179, 22)
        Me.dcProviders.Text = "Suppliers"
        Me.dcProviders.BackColor = System.Drawing.SystemColors.Window
        Me.dcProviders.ForeColor = System.Drawing.SystemColors.WindowText
        Me.dcProviders.Orientation = ADODC.OrientationEnum.adHorizontal
        Me.dcProviders.CursorLocation = ADODB.CursorLocationEnum.adUseClient
        Me.dcProviders.ConnectionTimeout = 15
        Me.dcProviders.CommandTimeout = 30
        Me.dcProviders.CursorType = ADODB.CursorTypeEnum.adOpenStatic
        Me.dcProviders.LockType = ADODB.LockTypeEnum.adLockOptimistic
        Me.dcProviders.CommandType = ADODB.CommandTypeEnum.adCmdTable
        Me.dcProviders.CacheSize = 50
        Me.dcProviders.MaxRecords = 0
        Me.dcProviders.BOFAction = ADODC.BOFActionEnum.adDoMoveFirst
        Me.dcProviders.EOFAction = ADODC.EOFActionEnum.adDoMoveLast
        Me.dcProviders.ConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=Orders.mdb;Persist Security Info=False"
        Me.dcProviders.UserName = ""
        Me.dcProviders.RecordSource = "Providers"
        Me.dcProviders.Font = New System.Drawing.Font("MS Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtField_1, Me.txtField_4, Me.txtField_0, Me.txtField_6, Me.txtField_7, Me.txtField_2, Me.txtField_5, Me.Frame2, Me.txtField_8, Me.txtField_10, Me.txtField_14, Me.txtField_9, Me.Label4, Me.Label15, Me.Label14, Me.Label13, Me.Label12, Me.Label11, Me.Label10, Me.Label9, Me.Label8, Me.Label6, Me.Label1})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 14
        Me.Frame1.Location = New System.Drawing.Point(8, 49)
        Me.Frame1.Size = New System.Drawing.Size(438, 357)
        Me.Frame1.Text = "Supplier information"
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtField_1
        '
        Me.txtField_1.Name = "txtField_1"
        Me.txtField_1.TabIndex = 29
        Me.txtField_1.Location = New System.Drawing.Point(16, 291)
        Me.txtField_1.Size = New System.Drawing.Size(406, 53)
        Me.txtField_1.Text = ""
        Me.txtField_1.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtField_1.Multiline = True
        '
        'txtField_4
        '
        Me.txtField_4.Name = "txtField_4"
        Me.txtField_4.TabIndex = 5
        Me.txtField_4.Location = New System.Drawing.Point(105, 84)
        Me.txtField_4.Size = New System.Drawing.Size(106, 20)
        Me.txtField_4.Text = ""
        Me.txtField_4.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_4.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_0
        '
        Me.txtField_0.Name = "txtField_0"
        Me.txtField_0.TabIndex = 0
        Me.txtField_0.Location = New System.Drawing.Point(105, 24)
        Me.txtField_0.Size = New System.Drawing.Size(106, 20)
        Me.txtField_0.Text = ""
        Me.txtField_0.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_0.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_6
        '
        Me.txtField_6.Name = "txtField_6"
        Me.txtField_6.TabIndex = 7
        Me.txtField_6.Location = New System.Drawing.Point(105, 147)
        Me.txtField_6.Size = New System.Drawing.Size(106, 20)
        Me.txtField_6.Text = ""
        Me.txtField_6.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_6.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_7
        '
        Me.txtField_7.Name = "txtField_7"
        Me.txtField_7.TabIndex = 8
        Me.txtField_7.Location = New System.Drawing.Point(105, 178)
        Me.txtField_7.Size = New System.Drawing.Size(106, 20)
        Me.txtField_7.Text = ""
        Me.txtField_7.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_7.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_2
        '
        Me.txtField_2.Name = "txtField_2"
        Me.txtField_2.TabIndex = 1
        Me.txtField_2.Location = New System.Drawing.Point(105, 55)
        Me.txtField_2.Size = New System.Drawing.Size(106, 20)
        Me.txtField_2.Text = ""
        Me.txtField_2.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_2.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_5
        '
        Me.txtField_5.Name = "txtField_5"
        Me.txtField_5.TabIndex = 6
        Me.txtField_5.Location = New System.Drawing.Point(105, 115)
        Me.txtField_5.Size = New System.Drawing.Size(106, 20)
        Me.txtField_5.Text = ""
        Me.txtField_5.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_5.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'Frame2
        '
        Me.Frame2.Controls.AddRange(New System.Windows.Forms.Control() {Me.txtField_11, Me.txtField_13, Me.txtField_12, Me.Label7, Me.Label3, Me.Label2})
        Me.Frame2.Name = "Frame2"
        Me.Frame2.TabIndex = 24
        Me.Frame2.Location = New System.Drawing.Point(227, 13)
        Me.Frame2.Size = New System.Drawing.Size(196, 98)
        Me.Frame2.Text = "Contact"
        Me.Frame2.BackColor = System.Drawing.SystemColors.Control
        Me.Frame2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtField_11
        '
        Me.txtField_11.Name = "txtField_11"
        Me.txtField_11.TabIndex = 2
        Me.txtField_11.Location = New System.Drawing.Point(65, 16)
        Me.txtField_11.Size = New System.Drawing.Size(122, 20)
        Me.txtField_11.Text = ""
        Me.txtField_11.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_11.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_13
        '
        Me.txtField_13.Name = "txtField_13"
        Me.txtField_13.TabIndex = 4
        Me.txtField_13.Location = New System.Drawing.Point(65, 65)
        Me.txtField_13.Size = New System.Drawing.Size(122, 20)
        Me.txtField_13.Text = ""
        Me.txtField_13.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_13.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_12
        '
        Me.txtField_12.Name = "txtField_12"
        Me.txtField_12.TabIndex = 3
        Me.txtField_12.Location = New System.Drawing.Point(65, 40)
        Me.txtField_12.Size = New System.Drawing.Size(122, 20)
        Me.txtField_12.Text = ""
        Me.txtField_12.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_12.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'Label7
        '
        Me.Label7.Name = "Label7"
        Me.Label7.TabIndex = 27
        Me.Label7.Location = New System.Drawing.Point(8, 16)
        Me.Label7.Size = New System.Drawing.Size(50, 17)
        Me.Label7.Text = "Title:"
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label3
        '
        Me.Label3.Name = "Label3"
        Me.Label3.TabIndex = 26
        Me.Label3.Location = New System.Drawing.Point(8, 70)
        Me.Label3.Size = New System.Drawing.Size(58, 17)
        Me.Label3.Text = "Last name:"
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label2
        '
        Me.Label2.Name = "Label2"
        Me.Label2.TabIndex = 25
        Me.Label2.Location = New System.Drawing.Point(8, 43)
        Me.Label2.Size = New System.Drawing.Size(58, 17)
        Me.Label2.Text = "First name:"
        Me.Label2.BackColor = System.Drawing.SystemColors.Control
        Me.Label2.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtField_8
        '
        Me.txtField_8.Name = "txtField_8"
        Me.txtField_8.TabIndex = 9
        Me.txtField_8.Location = New System.Drawing.Point(316, 116)
        Me.txtField_8.Size = New System.Drawing.Size(106, 20)
        Me.txtField_8.Text = ""
        Me.txtField_8.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_8.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_10
        '
        Me.txtField_10.Name = "txtField_10"
        Me.txtField_10.TabIndex = 11
        Me.txtField_10.Location = New System.Drawing.Point(316, 178)
        Me.txtField_10.Size = New System.Drawing.Size(106, 20)
        Me.txtField_10.Text = ""
        Me.txtField_10.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_10.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtField_14
        '
        Me.txtField_14.Name = "txtField_14"
        Me.txtField_14.TabIndex = 12
        Me.txtField_14.Location = New System.Drawing.Point(16, 218)
        Me.txtField_14.Size = New System.Drawing.Size(406, 53)
        Me.txtField_14.Text = ""
        Me.txtField_14.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_14.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtField_14.Multiline = True
        '
        'txtField_9
        '
        Me.txtField_9.Name = "txtField_9"
        Me.txtField_9.TabIndex = 10
        Me.txtField_9.Location = New System.Drawing.Point(316, 147)
        Me.txtField_9.Size = New System.Drawing.Size(106, 20)
        Me.txtField_9.Text = ""
        Me.txtField_9.BackColor = System.Drawing.SystemColors.Window
        Me.txtField_9.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 30
        Me.Label4.Location = New System.Drawing.Point(16, 275)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Payment Terms:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label15
        '
        Me.Label15.Name = "Label15"
        Me.Label15.TabIndex = 28
        Me.Label15.Location = New System.Drawing.Point(16, 84)
        Me.Label15.Size = New System.Drawing.Size(90, 17)
        Me.Label15.Text = "Zip code:"
        Me.Label15.BackColor = System.Drawing.SystemColors.Control
        Me.Label15.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label14
        '
        Me.Label14.Name = "Label14"
        Me.Label14.TabIndex = 23
        Me.Label14.Location = New System.Drawing.Point(16, 178)
        Me.Label14.Size = New System.Drawing.Size(90, 17)
        Me.Label14.Text = "Country/Region"
        Me.Label14.BackColor = System.Drawing.SystemColors.Control
        Me.Label14.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label13
        '
        Me.Label13.Name = "Label13"
        Me.Label13.TabIndex = 22
        Me.Label13.Location = New System.Drawing.Point(16, 147)
        Me.Label13.Size = New System.Drawing.Size(90, 17)
        Me.Label13.Text = "State or province:"
        Me.Label13.BackColor = System.Drawing.SystemColors.Control
        Me.Label13.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label12
        '
        Me.Label12.Name = "Label12"
        Me.Label12.TabIndex = 21
        Me.Label12.Location = New System.Drawing.Point(16, 202)
        Me.Label12.Size = New System.Drawing.Size(90, 17)
        Me.Label12.Text = "Notes:"
        Me.Label12.BackColor = System.Drawing.SystemColors.Control
        Me.Label12.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label11
        '
        Me.Label11.Name = "Label11"
        Me.Label11.TabIndex = 20
        Me.Label11.Location = New System.Drawing.Point(16, 55)
        Me.Label11.Size = New System.Drawing.Size(90, 17)
        Me.Label11.Text = "Email:"
        Me.Label11.BackColor = System.Drawing.SystemColors.Control
        Me.Label11.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label10
        '
        Me.Label10.Name = "Label10"
        Me.Label10.TabIndex = 19
        Me.Label10.Location = New System.Drawing.Point(235, 178)
        Me.Label10.Size = New System.Drawing.Size(90, 17)
        Me.Label10.Text = "Fax number:"
        Me.Label10.BackColor = System.Drawing.SystemColors.Control
        Me.Label10.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label9
        '
        Me.Label9.Name = "Label9"
        Me.Label9.TabIndex = 18
        Me.Label9.Location = New System.Drawing.Point(235, 147)
        Me.Label9.Size = New System.Drawing.Size(90, 17)
        Me.Label9.Text = "Extension:"
        Me.Label9.BackColor = System.Drawing.SystemColors.Control
        Me.Label9.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label8
        '
        Me.Label8.Name = "Label8"
        Me.Label8.TabIndex = 17
        Me.Label8.Location = New System.Drawing.Point(235, 116)
        Me.Label8.Size = New System.Drawing.Size(90, 17)
        Me.Label8.Text = "Phone number:"
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label6
        '
        Me.Label6.Name = "Label6"
        Me.Label6.TabIndex = 16
        Me.Label6.Location = New System.Drawing.Point(16, 115)
        Me.Label6.Size = New System.Drawing.Size(90, 17)
        Me.Label6.Text = "City:"
        Me.Label6.BackColor = System.Drawing.SystemColors.Control
        Me.Label6.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label1
        '
        Me.Label1.Name = "Label1"
        Me.Label1.TabIndex = 15
        Me.Label1.Location = New System.Drawing.Point(16, 24)
        Me.Label1.Size = New System.Drawing.Size(90, 17)
        Me.Label1.Text = "Supplier Name:"
        Me.Label1.BackColor = System.Drawing.SystemColors.Control
        Me.Label1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'ImageList1
        '
        Me.ImageList1.ImageSize = New System.Drawing.Size(16, 16)
        Me.ImageList1.ColorDepth = System.Windows.Forms.ColorDepth.Depth8Bit
        Me.ImageList1.TransparentColor = System.Drawing.Color.FromArgb(CType(255, Byte), CType(255, Byte), CType(255, Byte))
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        '
        'Toolbar1
        '
        Me.Toolbar1.Buttons.AddRange(New System.Windows.Forms.ToolBarButton() {Me.Button1, Me.Button2, Me.Button3, Me.Button4, Me.Button5, Me.Button6})
        Me.Toolbar1.Name = "Toolbar1"
        Me.Toolbar1.TabIndex = 13
        Me.Toolbar1.BorderStyle = System.Windows.Forms.BorderStyle.None
        Me.Toolbar1.ButtonSize = New System.Drawing.Size(16, 16)
        Me.Toolbar1.ImageList = Me.ImageList1
        '
        'Button1
        '
        Me.Button1.Name = "Button1"
        Me.Button1.ImageIndex = 0
        Me.Button1.Text = "Add"
        Me.Button1.ToolTipText = "Create a new record"
        Me.Button1.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button2
        '
        Me.Button2.Name = "Button2"
        Me.Button2.ImageIndex = 1
        Me.Button2.Text = "Edit"
        Me.Button2.ToolTipText = "Edit this record"
        Me.Button2.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button3
        '
        Me.Button3.Name = "Button3"
        Me.Button3.ImageIndex = 2
        Me.Button3.Text = "Save"
        Me.Button3.ToolTipText = "Save the current changes"
        Me.Button3.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button4
        '
        Me.Button4.Name = "Button4"
        Me.Button4.ImageIndex = 3
        Me.Button4.Text = "Delete"
        Me.Button4.ToolTipText = "Delete the current record"
        Me.Button4.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button5
        '
        Me.Button5.Name = "Button5"
        Me.Button5.ImageIndex = 4
        Me.Button5.Text = "Search"
        Me.Button5.ToolTipText = "Search for a record"
        Me.Button5.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'Button6
        '
        Me.Button6.Name = "Button6"
        Me.Button6.Text = "Cancel"
        Me.Button6.ToolTipText = "Cancel edited changes"
        Me.Button6.Style = System.Windows.Forms.ToolBarButtonStyle.PushButton
        '
        'frmProviders
        '
        Me.ClientSize = New System.Drawing.Size(459, 452)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.dcProviders, Me.Frame1, Me.Toolbar1})
        Me.Name = "frmProviders"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Suppliers"
        Me.txtField.SetIndex(txtField_1, CType(1, Short))
        Me.txtField.SetIndex(txtField_4, CType(4, Short))
        Me.txtField.SetIndex(txtField_0, CType(0, Short))
        Me.txtField.SetIndex(txtField_6, CType(6, Short))
        Me.txtField.SetIndex(txtField_7, CType(7, Short))
        Me.txtField.SetIndex(txtField_2, CType(2, Short))
        Me.txtField.SetIndex(txtField_5, CType(5, Short))
        Me.txtField.SetIndex(txtField_11, CType(11, Short))
        Me.txtField.SetIndex(txtField_13, CType(13, Short))
        Me.txtField.SetIndex(txtField_12, CType(12, Short))
        Me.txtField.SetIndex(txtField_8, CType(8, Short))
        Me.txtField.SetIndex(txtField_10, CType(10, Short))
        Me.txtField.SetIndex(txtField_14, CType(14, Short))
        Me.txtField.SetIndex(txtField_9, CType(9, Short))
        CType(Me.txtField, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Frame2.ResumeLayout(False)
        Me.Frame1.ResumeLayout(False)
        Me.Toolbar1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================
    Private NewMode As Boolean
    Private EditMode As Boolean
    Private CancellingMode As Boolean
    ' VBto upgrade warning: CurrentProviderID As Short	OnWrite(Object)
    Public CurrentProviderID As Short

    'Private Sub adcProviders_MoveComplete(ByVal adReason As ADODB.EventReasonEnum, ByVal pError As ADODB.Error, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
    'NewMode = False
    'EditMode = False
    'CancellingMode = False
    'End Sub

    'Private Sub dcProviders_WillMove(ByVal adReason As ADODB.EventReasonEnum, adStatus As ADODB.EventStatusEnum, ByVal pRecordset As ADODB.Recordset)
    'CancellingMode = True
    'End Sub


    Private Sub frmProviders_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        dcProviders.ConnectionString = ConnectionString

        NewMode = False
        EditMode = False
        CancellingMode = False
    End Sub

    Private Sub Form_Unload(ByRef Cancel As Short)
        CurrentProviderID = dcProviders.Recordset.Fields("ProviderId").Value
    End Sub

    Private Sub frmProviders_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_Unload(Cancel)
        If Cancel <> 0 Then e.Cancel = True
    End Sub

    Private Sub Toolbar1_ButtonClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolBarButtonClickEventArgs) Handles Toolbar1.ButtonClick
        Dim Button As ToolBarButton = e.Button

        Dim x As Object
        'SKS Demo TODO: dcProviders.SetFocus()
        Select Case Button.Text
            Case "Add":
                'Add new record
                NewMode = True
                dcProviders.Recordset.AddNew()
            Case "Edit":
                'Edit mode
                EditMode = True
            Case "Save":
                Save()
            Case "Delete":
                'Delete record
                If MsgBox("Are you sure you want to delete this record?", MsgBoxStyle.Question Or MsgBoxStyle.YesNo, "Delete record")=DialogResult.Yes Then
                    dcProviders.Recordset.Delete()
                    dcProviders.Recordset.Requery()
                End If
            Case "Search":
                'Search for records
                SearchShow("Providers", "ProviderName", "Provider")
            Case "Cancel":
                CancellingMode = True
                'Cancel edited changes
                EditMode = False
                NewMode = False
                dcProviders.Recordset.CancelUpdate()
                dcProviders.Recordset.Requery()
                CancellingMode = False
                Close()
        End Select
    End Sub


    Private Sub Save()
        'Save data
        If TextBoxEmpty(txtField(0)) Then Exit Sub
        If TextBoxEmpty(txtField(1)) Then Exit Sub
        If TextBoxEmpty(txtField(2)) Then Exit Sub
        If TextBoxEmpty(txtField(4)) Then Exit Sub
        If TextBoxEmpty(txtField(5)) Then Exit Sub
        If TextBoxEmpty(txtField(6)) Then Exit Sub
        If TextBoxEmpty(txtField(7)) Then Exit Sub
        If TextBoxEmpty(txtField(7)) Then Exit Sub
        If TextBoxEmpty(txtField(10)) Then Exit Sub
        If TextBoxEmpty(txtField(11)) Then Exit Sub
        If TextBoxEmpty(txtField(12)) Then Exit Sub
        If TextBoxEmpty(txtField(14)) Then Exit Sub
        dcProviders.Recordset.Update()
        EditMode = False
        NewMode = False
    End Sub

    Private Sub txtField_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtField.TextChanged
        Dim Index As Short = txtField.GetIndex(sender)
        If Not sender.Created() Then Exit Sub
        If  Not CancellingMode Then
            EditMode = True
        End If
    End Sub

    'Used in search form
    'Public Sub SearchCriteria(field As String, value As String)
    'ExecuteSql "Select * from Providers where " & field & " LIKE '" & value & "%'"
    'If rs.RecordCount = 0 Then
    '    MsgBox "There are no records with the selected criteria", vbInformation, "Search"
    'Else
    '    LogStatus "There are " & rs.RecordCount & " that meet with the selected criteria"
    '    Set dcProviders.Recordset = rs
    'End If
    'End Sub

End Class