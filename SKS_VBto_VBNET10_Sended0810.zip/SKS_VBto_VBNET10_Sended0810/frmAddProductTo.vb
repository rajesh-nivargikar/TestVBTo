
Imports System
Imports System.Windows.Forms
Imports Microsoft.VisualBasic

Public Class frmAddProductTo
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents chkAll As System.Windows.Forms.CheckBox
    Friend WithEvents cmdRemove As System.Windows.Forms.Button
    Friend WithEvents sbStatusBar As System.Windows.Forms.StatusBar
    Friend WithEvents sbStatusBar_Panel1 As System.Windows.Forms.StatusBarPanel
    Friend WithEvents cmdClose As System.Windows.Forms.Button
    Friend WithEvents cmdSave As System.Windows.Forms.Button
    Friend WithEvents Frame1 As System.Windows.Forms.GroupBox
    Friend WithEvents cmdProducts As System.Windows.Forms.Button
    Friend WithEvents txtName As System.Windows.Forms.TextBox
    Friend WithEvents txtCode As System.Windows.Forms.TextBox
    Friend WithEvents lvProducts As System.Windows.Forms.ListView
    Friend WithEvents lvProductsColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader4 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader5 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsColumnHeader6 As System.Windows.Forms.ColumnHeader
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lvProductsBy As System.Windows.Forms.ListView
    Friend WithEvents lvProductsByColumnHeader0 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsByColumnHeader1 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsByColumnHeader2 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lvProductsByColumnHeader3 As System.Windows.Forms.ColumnHeader
    Friend WithEvents lblProductsRelated As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(frmAddProductTo))
        Me.chkAll = New System.Windows.Forms.CheckBox()
        Me.cmdRemove = New System.Windows.Forms.Button()
        Me.sbStatusBar = New System.Windows.Forms.StatusBar()
        Me.sbStatusBar_Panel1 = New System.Windows.Forms.StatusBarPanel()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.Frame1 = New System.Windows.Forms.GroupBox()
        Me.cmdProducts = New System.Windows.Forms.Button()
        Me.txtName = New System.Windows.Forms.TextBox()
        Me.txtCode = New System.Windows.Forms.TextBox()
        Me.lvProducts = New System.Windows.Forms.ListView()
        Me.lvProductsColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader4 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader5 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsColumnHeader6 = New System.Windows.Forms.ColumnHeader()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lvProductsBy = New System.Windows.Forms.ListView()
        Me.lvProductsByColumnHeader0 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsByColumnHeader1 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsByColumnHeader2 = New System.Windows.Forms.ColumnHeader()
        Me.lvProductsByColumnHeader3 = New System.Windows.Forms.ColumnHeader()
        Me.lblProductsRelated = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'chkAll
        '
        Me.chkAll.Name = "chkAll"
        Me.chkAll.TabStop = False
        Me.chkAll.TabIndex = 13
        Me.chkAll.Location = New System.Drawing.Point(113, 458)
        Me.chkAll.Size = New System.Drawing.Size(82, 17)
        Me.chkAll.Text = "Check All"
        Me.chkAll.BackColor = System.Drawing.SystemColors.Control
        Me.chkAll.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdRemove
        '
        Me.cmdRemove.Name = "cmdRemove"
        Me.cmdRemove.TabStop = False
        Me.cmdRemove.TabIndex = 12
        Me.cmdRemove.Location = New System.Drawing.Point(8, 453)
        Me.cmdRemove.Size = New System.Drawing.Size(98, 25)
        Me.cmdRemove.Text = "&Remove Checked"
        Me.cmdRemove.BackColor = System.Drawing.SystemColors.Control
        Me.cmdRemove.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'sbStatusBar
        '
        Me.sbStatusBar.Panels.AddRange(New System.Windows.Forms.StatusBarPanel() {Me.sbStatusBar_Panel1})
        Me.sbStatusBar.Name = "sbStatusBar"
        Me.sbStatusBar.TabIndex = 11
        Me.sbStatusBar.Location = New System.Drawing.Point(0, 493)
        Me.sbStatusBar.Size = New System.Drawing.Size(429, 23)
        Me.sbStatusBar.ShowPanels = True
        Me.sbStatusBar.SizingGrip = False
        '
        'Panel1
        '
        Me.sbStatusBar_Panel1.Text = ""
        Me.sbStatusBar_Panel1.AutoSize = System.Windows.Forms.StatusBarPanelAutoSize.Spring
        Me.sbStatusBar_Panel1.Width = 427
        '
        'cmdClose
        '
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.TabIndex = 7
        Me.cmdClose.Location = New System.Drawing.Point(332, 453)
        Me.cmdClose.Size = New System.Drawing.Size(90, 25)
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdSave
        '
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.TabIndex = 6
        Me.cmdSave.Location = New System.Drawing.Point(227, 453)
        Me.cmdSave.Size = New System.Drawing.Size(90, 25)
        Me.cmdSave.Text = "&Save"
        Me.cmdSave.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSave.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Frame1
        '
        Me.Frame1.Controls.AddRange(New System.Windows.Forms.Control() {Me.cmdProducts, Me.txtName, Me.txtCode, Me.lvProducts, Me.Label4, Me.Label5})
        Me.Frame1.Name = "Frame1"
        Me.Frame1.TabIndex = 4
        Me.Frame1.Location = New System.Drawing.Point(8, 8)
        Me.Frame1.Size = New System.Drawing.Size(414, 236)
        Me.Frame1.Text = "Search product "
        Me.Frame1.BackColor = System.Drawing.SystemColors.Control
        Me.Frame1.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'cmdProducts
        '
        Me.cmdProducts.Name = "cmdProducts"
        Me.cmdProducts.TabStop = False
        Me.cmdProducts.TabIndex = 5
        Me.cmdProducts.Location = New System.Drawing.Point(364, 16)
        Me.cmdProducts.Size = New System.Drawing.Size(25, 23)
        Me.cmdProducts.Text = "..."
        Me.cmdProducts.BackColor = System.Drawing.SystemColors.Control
        Me.cmdProducts.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'txtName
        '
        Me.txtName.Name = "txtName"
        Me.txtName.TabIndex = 1
        Me.txtName.Location = New System.Drawing.Point(113, 40)
        Me.txtName.Size = New System.Drawing.Size(147, 20)
        Me.txtName.Text = ""
        Me.txtName.BackColor = System.Drawing.SystemColors.Window
        Me.txtName.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'txtCode
        '
        Me.txtCode.Name = "txtCode"
        Me.txtCode.TabIndex = 0
        Me.txtCode.Location = New System.Drawing.Point(113, 16)
        Me.txtCode.Size = New System.Drawing.Size(98, 20)
        Me.txtCode.Text = ""
        Me.txtCode.BackColor = System.Drawing.SystemColors.Window
        Me.txtCode.ForeColor = System.Drawing.SystemColors.WindowText
        '
        'lvProducts
        '
        Me.lvProducts.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvProductsColumnHeader0, Me.lvProductsColumnHeader1, Me.lvProductsColumnHeader2, Me.lvProductsColumnHeader3, Me.lvProductsColumnHeader4, Me.lvProductsColumnHeader5, Me.lvProductsColumnHeader6})
        Me.lvProducts.Name = "lvProducts"
        Me.lvProducts.TabIndex = 2
        Me.lvProducts.Location = New System.Drawing.Point(8, 65)
        Me.lvProducts.Size = New System.Drawing.Size(397, 163)
        Me.lvProducts.BackColor = System.Drawing.SystemColors.Window
        Me.lvProducts.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvProducts.View = System.Windows.Forms.View.Details
        Me.lvProducts.MultiSelect = False
        Me.lvProducts.GridLines = True
        Me.lvProducts.FullRowSelect = True
        Me.lvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvProducts.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvProductsColumnHeader0.Text = "Code"
        Me.lvProductsColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvProductsColumnHeader1.Text = "Name"
        Me.lvProductsColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvProductsColumnHeader2.Text = "Price"
        Me.lvProductsColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader2.Width = 98
        '
        'ColumnHeader(4)
        '
        Me.lvProductsColumnHeader3.Text = "Existence"
        Me.lvProductsColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader3.Width = 98
        '
        'ColumnHeader(5)
        '
        Me.lvProductsColumnHeader4.Text = "Ordered"
        Me.lvProductsColumnHeader4.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader4.Width = 98
        '
        'ColumnHeader(6)
        '
        Me.lvProductsColumnHeader5.Text = "Quantity per Unit"
        Me.lvProductsColumnHeader5.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsColumnHeader5.Width = 98
        '
        'ColumnHeader(7)
        '
        Me.lvProductsColumnHeader6.Text = "Unit"
        Me.lvProductsColumnHeader6.Width = 98
        '
        'Label4
        '
        Me.Label4.Name = "Label4"
        Me.Label4.TabIndex = 9
        Me.Label4.Location = New System.Drawing.Point(16, 40)
        Me.Label4.Size = New System.Drawing.Size(90, 17)
        Me.Label4.Text = "Product name:"
        Me.Label4.BackColor = System.Drawing.SystemColors.Control
        Me.Label4.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'Label5
        '
        Me.Label5.Name = "Label5"
        Me.Label5.TabIndex = 8
        Me.Label5.Location = New System.Drawing.Point(16, 16)
        Me.Label5.Size = New System.Drawing.Size(90, 17)
        Me.Label5.Text = "Product code:"
        Me.Label5.BackColor = System.Drawing.SystemColors.Control
        Me.Label5.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'lvProductsBy
        '
        Me.lvProductsBy.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.lvProductsByColumnHeader0, Me.lvProductsByColumnHeader1, Me.lvProductsByColumnHeader2, Me.lvProductsByColumnHeader3})
        Me.lvProductsBy.Name = "lvProductsBy"
        Me.lvProductsBy.TabIndex = 3
        Me.lvProductsBy.Location = New System.Drawing.Point(8, 275)
        Me.lvProductsBy.Size = New System.Drawing.Size(414, 171)
        Me.lvProductsBy.BackColor = System.Drawing.SystemColors.Window
        Me.lvProductsBy.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lvProductsBy.View = System.Windows.Forms.View.Details
        Me.lvProductsBy.MultiSelect = False
        Me.lvProductsBy.GridLines = True
        Me.lvProductsBy.FullRowSelect = True
        Me.lvProductsBy.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lvProductsBy.CheckBoxes = True
        Me.lvProductsBy.HideSelection = False
        '
        'ColumnHeader(1)
        '
        Me.lvProductsByColumnHeader0.Text = "Code"
        Me.lvProductsByColumnHeader0.Width = 98
        '
        'ColumnHeader(2)
        '
        Me.lvProductsByColumnHeader1.Text = "Name"
        Me.lvProductsByColumnHeader1.Width = 98
        '
        'ColumnHeader(3)
        '
        Me.lvProductsByColumnHeader2.Text = "Price"
        Me.lvProductsByColumnHeader2.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsByColumnHeader2.Width = 61
        '
        'ColumnHeader(4)
        '
        Me.lvProductsByColumnHeader3.Text = "Quantity per Unit"
        Me.lvProductsByColumnHeader3.TextAlign = System.Windows.Forms.HorizontalAlignment.Right
        Me.lvProductsByColumnHeader3.Width = 95
        '
        'lblProductsRelated
        '
        Me.lblProductsRelated.Name = "lblProductsRelated"
        Me.lblProductsRelated.TabIndex = 10
        Me.lblProductsRelated.Location = New System.Drawing.Point(8, 251)
        Me.lblProductsRelated.Size = New System.Drawing.Size(414, 17)
        Me.lblProductsRelated.Text = "Products"
        Me.lblProductsRelated.BackColor = System.Drawing.SystemColors.Control
        Me.lblProductsRelated.ForeColor = System.Drawing.SystemColors.ControlText
        '
        'frmAddProductTo
        '
        Me.ClientSize = New System.Drawing.Size(429, 517)
        Me.Controls.AddRange(New System.Windows.Forms.Control() {Me.chkAll, Me.cmdRemove, Me.sbStatusBar, Me.cmdClose, Me.cmdSave, Me.Frame1, Me.lvProductsBy, Me.lblProductsRelated})
        Me.Name = "frmAddProductTo"
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ForeColor = System.Drawing.SystemColors.ControlText
        Me.MinimizeBox = False
        Me.MaximizeBox = False
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Create New Product Item"
        Me.Frame1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

	'=========================================================

    Public Id As Short
    Public ObjectReferred As String = ""
    Public Table As String = ""
    Public ColumnName As String = ""

    Public SavedChanges As Boolean
    Private productsStored As Collection
    Private productsToDelete As Collection
    Private productsToAdd As Collection
    Private editingData As Boolean
    Private currentIdProduct As String = ""

    Private codeGeneratedChange As Boolean

    Private Sub chkAll_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles chkAll.Click
        Dim check As Boolean
        check = chkAll.CheckState=CheckState.Checked
        For i = 1 To lvProductsBy.Items.Count
            lvProductsBy.Items(i - 1).Checked = check : lvProductsBy.Items(i - 1).Focused = check
        Next i
    End Sub

    Private Sub cmdClose_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdClose.Click
        Close()
    End Sub

    Private Sub cmdProducts_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdProducts.Click
        frmProducts.ShowDialog()
        txtCode.Text = frmProducts.CurrentProductID
        txtName.Text = ""
        DoSearchProduct()
    End Sub

    Private Sub cmdRemove_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdRemove.Click
        Dim productIdToDelete As String
        For i = lvProductsBy.Items.Count To 1 Step -1
            If lvProductsBy.Items(i - 1).Checked Then
                productIdToDelete = lvProductsBy.Items(i - 1).Text

                If Exists(productsStored, productIdToDelete) Then
                    If Exists(productsToAdd, productIdToDelete) Then
                        productsToDelete.Remove(productIdToDelete)
                    Else
                        AddToCollection(productsToDelete, productIdToDelete)
                    End If
                Else
                    If Exists(productsToAdd, currentIdProduct) Then
                        productsToAdd.Remove(currentIdProduct)
                    End If
                End If

                lvProductsBy.Items.RemoveAt(i-1)
                editingData = True
            End If
        Next i
    End Sub

    Private Sub cmdSave_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmdSave.Click
        cmdSave_Click()
    End Sub
    Public Sub cmdSave_Click()

        If productsToAdd.Count=0 And productsToDelete.Count=0 Then
            editingData = True
            MsgBox("No data to be saved", MsgBoxStyle.OkOnly Or MsgBoxStyle.Information, "No data modified")
            Close()
            Exit Sub
        End If
        SavedChanges = True
        Dim productCode As Object
        For Each productCode In productsToAdd
            ExecuteSql("Insert into " & Table & "(" & ColumnName & ", ProductID) Values (" & Id & ", '" & productCode & "')")
            productCode = Nothing
        Next
        For Each productCode In productsToDelete
            ExecuteSql("Delete from " & Table & " Where " & ColumnName & " = " & Id & " And ProductID = '" & productCode & "'")
            productCode = Nothing
        Next

        editingData = False
        MsgBox("Data was succesfully saved", MsgBoxStyle.OkOnly Or MsgBoxStyle.Information, "New data")
        Close()
        Exit Sub
HandleError:
        MsgBox("An error has occurred adding the data. Error: (" & err.Number & ") " & err.Description, MsgBoxStyle.Critical, "Error")
    End Sub

    Public Sub LoadData()
        editingData = False
        editingData = False
        codeGeneratedChange = False
        Me.Text = "Add product(s) to " & ObjectReferred
        lblProductsRelated.Text = "Products related to " & ObjectReferred
        productsStored = New Collection()
        productsToDelete = New Collection()
        productsToAdd = New Collection()
        LoadProductsById()
    End Sub

    ' VBto upgrade warning: Cancel As Short	OnWrite(Boolean)
    Private Sub Form_QueryUnload(ByRef Cancel As Short, ByVal UnloadMode As Short)
        If editingData Then
            Dim res As DialogResult
            res = MsgBox("Do you want to save the edited data?", MsgBoxStyle.YesNoCancel Or MsgBoxStyle.Question, "Save data")
            If res=DialogResult.Yes Then
                cmdSave_Click()
            ElseIf res<>DialogResult.No Then
                Cancel = True
            End If
        End If
    End Sub

    Private Sub frmAddProductTo_FormClosing(ByVal sender As Object, ByVal e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim Cancel As Short = 0
        Form_QueryUnload(Cancel, 0)
        If Cancel <> 0 Then
            e.Cancel = True
            Exit Sub
        End If
    End Sub

    Private Sub lvProducts_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lvProducts.SelectedIndexChanged
        Dim Item As ListViewItem = CType(sender, ListView).FocusedItem
        If Item Is Nothing Then Exit Sub

        AddProductToSet()
    End Sub

    Private Sub txtCode_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtCode.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProduct()
    End Sub

    'Private Sub txtCode_KeyPress(KeyAscii As Integer)
    'KeyAscii = UpCase(KeyAscii)
    'End Sub

    Private Sub txtCode_Leave(ByVal sender As Object, ByVal e As System.EventArgs) Handles txtCode.Leave
        If lvProducts.Items.Count=1 Then
            AddProductToSet()
        End If
    End Sub

    Private Sub txtName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtName.TextChanged
        If Not sender.Created() Then Exit Sub
        DoSearchProduct()
    End Sub

    Private Sub LoadProductsById()
        Dim productCode As String
        ExecuteSql("Select p.ProductID, p.ProductName, p.UnitPrice, p.QuantityPerUnit, p.Unit from Products as p, " & Table & " as pb Where pb." & ColumnName & " = " & Id & " And pb.ProductId = p.ProductId")

        LogStatus("There are " & rs.RecordCount & " records with the selected criteria", Me)
        If rs.RecordCount>0 Then
            Dim x As ListViewItem
            While  Not rs.EOF
                'productCode = CStr(rs.Fields(0).value)
                productCode = Convert.ToString(rs.Fields(0).Value)
                AddToCollection(productsStored, productCode)
                x = lvProductsBy.Items.Add(productCode)
                For i = 1 To 2
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                    End If
                Next i
                SubItemsSetText(x, 3, Convert.ToString(rs.Fields(3).Value) & Convert.ToString(rs.Fields(4).Value))
                rs.MoveNext()
            End While
        End If
    End Sub

    Private Sub DoSearchProduct()
        Dim filter As String
        filter = ""
        If txtCode.Text<>Nothing Then
            filter = "ProductId LIKE '%" & txtCode.Text & "%'"
        End If
        If txtName.Text<>Nothing Then
            If filter<>Nothing Then
                filter &= " AND "
            End If
            filter &= "ProductName LIKE '%" & txtName.Text & "%'"
        End If
        If filter<>Nothing Then
            filter = "Where " & filter
        End If
        ExecuteSql("Select ProductID, ProductName, UnitPrice, UnitsInStock, UnitsOnOrder, QuantityPerUnit, Unit from Products " & filter)
        lvProducts.Items.Clear()
        LogStatus("There are " & rs.RecordCount & " records with the selected criteria", Me)
        If rs.RecordCount>0 Then
            Dim x As ListViewItem
            While  Not rs.EOF
                x = lvProducts.Items.Add(Convert.ToString(rs.Fields(0).Value))
                For i = 1 To (rs.ColumnCount-1)
                    If  Not IsEmpty(rs.Fields(i).Value) Then
                        SubItemsSetText(x, i, Convert.ToString(rs.Fields(i).Value))
                    End If
                Next i
                rs.MoveNext()
            End While
            If lvProducts.Items.Count=1 Then
                lvProducts.FocusedItem = lvProducts.Items(1 - 1) : lvProducts.FocusedItem.Selected = True
            End If
        End If
    End Sub

    Private Sub AddProductToSet()

        If lvProducts.FocusedItem.Text<>Nothing Then
            Dim y As ListViewItem
            y = lvProducts.FocusedItem
            currentIdProduct = lvProducts.FocusedItem.Text
            Dim i As Integer
            Dim found As Boolean
            found = False
            For i = 1 To lvProductsBy.Items.Count
                If lvProductsBy.Items(i - 1).Text=currentIdProduct Then
                    lvProductsBy.FocusedItem = lvProductsBy.Items(i - 1) : lvProductsBy.FocusedItem.Selected = True
                    found = True
                    Exit For
                ElseIf lvProductsBy.Items(i - 1).Text>currentIdProduct Then
                    Exit For
                End If
            Next i
            If  Not found Then
                editingData = True
                If  Not Exists(productsStored, currentIdProduct) Then
                    If Exists(productsToDelete, currentIdProduct) Then
                        productsToDelete.Remove(currentIdProduct)
                    Else
                        AddToCollection(productsToAdd, currentIdProduct)
                    End If
                Else
                    If Exists(productsToDelete, currentIdProduct) Then
                        productsToDelete.Remove(currentIdProduct)
                    End If
                End If
                Dim x As ListViewItem
                x = lvProductsBy.Items.Insert(i-1, currentIdProduct)
                SubItemsSetText(x, 1, y.SubItems(1).Text)
                SubItemsSetText(x, 2, y.SubItems(2).Text)
                SubItemsSetText(x, 3, y.SubItems(5).Text & y.SubItems(6).Text)
            End If
        End If
    End Sub

'#Const defUse_ClearFields = True
#If defUse_ClearFields Then
    Private Sub ClearFields()
        codeGeneratedChange = True
        txtCode.Text = ""
        txtName.Text = ""
        lvProducts.Items.Clear()
        lvProductsBy.Items.Clear()
        txtCode.Focus()
        editingData = False
        codeGeneratedChange = False
    End Sub
#End If

End Class