﻿' This is a part of the VBto Converter (www.vbto.net). Copyright (C) 2005-2016 StressSoft Company Ltd. All rights reserved.
' version 1.1	2016.10.21

Imports System
Imports System.Windows.Forms
Imports System.Drawing
Imports System.Drawing.Drawing2D
Imports System.ComponentModel
Imports System.Runtime.CompilerServices
Imports Microsoft.VisualBasic.Compatibility.VB6

Namespace VBtoFigures

    <Browsable(False)> _
    Partial Public Class TransparentControl
        Inherits UserControl

        Public Sub New()
            SetStyle(ControlStyles.SupportsTransparentBackColor, True)
            SetStyle(ControlStyles.Opaque, True)
            'InitializeComponent()
        End Sub

        Protected Overrides ReadOnly Property CreateParams() As CreateParams
            Get
                Dim cp As CreateParams = MyBase.CreateParams
                cp.ExStyle = cp.ExStyle Or &H20
                Return cp
            End Get
        End Property

    End Class

    Partial Public Class Line
        Inherits TransparentControl

        Public Sub New()
            AddHandler Paint, AddressOf VBtoLine_Paint
            _X1 = 0 : _Y1 = 0
            _X2 = 0 : _Y2 = 0
        End Sub

        Public Sub New(ByVal container As IContainer)
            AddHandler Paint, AddressOf VBtoLine_Paint
            _X1 = 0 : _Y1 = 0
            _X2 = 0 : _Y2 = 0
            container.Add(Me)
        End Sub

        Private Sub VBtoLine_Paint(ByVal sender As Object, ByVal e As PaintEventArgs)
            e.Graphics.SmoothingMode = SmoothingMode.HighQuality
            e.Graphics.DrawLine(mPen, _X1 - Left, _Y1 - Top, _X2 - Left, _Y2 - Top)
        End Sub

#Region "Pen"

        Private mLineColor As Color = Color.Black
        <Browsable(True)> _
        Public Property LineColor() As Color
            Get
                Return mLineColor
            End Get
            Set(ByVal value As Color)
                If mLineColor <> value Then
                    mLineColor = value
                    RefreshPen()
                End If
            End Set
        End Property

        Private mLineStyle As DashStyle = DashStyle.Solid
        <Browsable(True)> _
        Public Shadows Property LineStyle() As DashStyle
            Get
                Return mLineStyle
            End Get
            Set(ByVal value As DashStyle)
                mLineStyle = value
                RefreshPen()
            End Set
        End Property

        Private mLineWidth As Integer = 1
        <Browsable(True)> _
        Public Property LineWidth() As Integer
            Get
                Return mLineWidth
            End Get
            Set(ByVal value As Integer)
                mLineWidth = value
                RefreshPen()
            End Set
        End Property

        Private mPen As Pen = Pens.Black
        Private Sub RefreshPen()
            mPen = New Pen(mLineColor, mLineWidth)
            mPen.DashStyle = mLineStyle
            If Parent IsNot Nothing Then
                Parent.Invalidate(New Rectangle(Left, Top, Width, Height), True)
            End If
        End Sub

#End Region

#Region "X1,Y1, X2,Y2"

        Private _X1, _Y1, _X2, _Y2 As Single

        Private Sub ResetX()
            If _X1 < _X2 Then
                Width = _X2 - _X1 : Left = _X1
            Else
                Width = _X1 - _X2 : Left = _X2
            End If
            If Width < LineWidth Then Width = LineWidth
            Refresh()
        End Sub
        Private Sub ResetY()
            If _Y1 < _Y2 Then
                Height = _Y2 - _Y1 : Top = _Y1
            Else
                Height = _Y1 - _Y2 : Top = _Y2
            End If
            If Height < LineWidth Then Height = LineWidth
            Refresh()
        End Sub

        <Browsable(True)> _
        Public Property X1() As Single
            Get
                Return _X1
            End Get
            Set(ByVal value As Single)
                _X1 = value : ResetX()
            End Set
        End Property
        <Browsable(True)> _
        Public Property Y1() As Single
            Get
                Return _Y1
            End Get
            Set(ByVal value As Single)
                _Y1 = value : ResetY()
            End Set
        End Property

        <Browsable(True)> _
        Public Property X2() As Single
            Get
                Return _X2
            End Get
            Set(ByVal value As Single)
                _X2 = value : ResetX()
            End Set
        End Property
        <Browsable(True)> _
        Public Property Y2() As Single
            Get
                Return _Y2
            End Get
            Set(ByVal value As Single)
                _Y2 = value : ResetY()
            End Set
        End Property

#End Region

    End Class

    <ProvideProperty("Index", GetType(Line))> _
    Public Class LineArray
        Inherits BaseControlArray
        Implements IExtenderProvider
        Private ClickEvent As EventHandler
        Private DoubleClickEvent As EventHandler
        Private MouseClickEvent As MouseEventHandler
        Private MouseDoubleClickEvent As MouseEventHandler
        Private MouseDownEvent As MouseEventHandler
        Private MouseEnterEvent As EventHandler
        Private MouseHoverEvent As EventHandler
        Private MouseLeaveEvent As EventHandler
        Private MouseMoveEvent As MouseEventHandler
        Private MouseUpEvent As MouseEventHandler

        Public Custom Event Click As EventHandler
            AddHandler(ByVal value As EventHandler)
                ClickEvent = DirectCast([Delegate].Combine(ClickEvent, value), EventHandler)
            End AddHandler
            RemoveHandler(ByVal value As EventHandler)
                ClickEvent = DirectCast([Delegate].Remove(ClickEvent, value), EventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As EventArgs)
                CType(Events("ClickEvent"), EventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event DoubleClick As EventHandler
            AddHandler(ByVal value As EventHandler)
                DoubleClickEvent = DirectCast([Delegate].Combine(DoubleClickEvent, value), EventHandler)
            End AddHandler
            RemoveHandler(ByVal value As EventHandler)
                DoubleClickEvent = DirectCast([Delegate].Remove(DoubleClickEvent, value), EventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As EventArgs)
                CType(Events("DoubleClickEvent"), EventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseClick As MouseEventHandler
            AddHandler(ByVal value As MouseEventHandler)
                MouseClickEvent = DirectCast([Delegate].Combine(MouseClickEvent, value), MouseEventHandler)
            End AddHandler
            RemoveHandler(ByVal value As MouseEventHandler)
                MouseClickEvent = DirectCast([Delegate].Remove(MouseClickEvent, value), MouseEventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As MouseEventArgs)
                CType(Events("MouseClickEvent"), MouseEventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseDoubleClick As MouseEventHandler
            AddHandler(ByVal value As MouseEventHandler)
                MouseDoubleClickEvent = DirectCast([Delegate].Combine(MouseDoubleClickEvent, value), MouseEventHandler)
            End AddHandler
            RemoveHandler(ByVal value As MouseEventHandler)
                MouseDoubleClickEvent = DirectCast([Delegate].Remove(MouseDoubleClickEvent, value), MouseEventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As MouseEventArgs)
                CType(Events("MouseDoubleClickEvent"), MouseEventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseDown As MouseEventHandler
            AddHandler(ByVal value As MouseEventHandler)
                MouseDownEvent = DirectCast([Delegate].Combine(MouseDownEvent, value), MouseEventHandler)
            End AddHandler
            RemoveHandler(ByVal value As MouseEventHandler)
                MouseDownEvent = DirectCast([Delegate].Remove(MouseDownEvent, value), MouseEventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As MouseEventArgs)
                CType(Events("MouseDownEvent"), MouseEventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseEnter As EventHandler
            AddHandler(ByVal value As EventHandler)
                MouseEnterEvent = DirectCast([Delegate].Combine(MouseEnterEvent, value), EventHandler)
            End AddHandler
            RemoveHandler(ByVal value As EventHandler)
                MouseEnterEvent = DirectCast([Delegate].Remove(MouseEnterEvent, value), EventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As EventArgs)
                CType(Events("MouseEnterEvent"), EventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseHover As EventHandler
            AddHandler(ByVal value As EventHandler)
                MouseHoverEvent = DirectCast([Delegate].Combine(MouseHoverEvent, value), EventHandler)
            End AddHandler
            RemoveHandler(ByVal value As EventHandler)
                MouseHoverEvent = DirectCast([Delegate].Remove(MouseHoverEvent, value), EventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As EventArgs)
                CType(Events("MouseHoverEvent"), EventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseLeave As EventHandler
            AddHandler(ByVal value As EventHandler)
                MouseLeaveEvent = DirectCast([Delegate].Combine(MouseLeaveEvent, value), EventHandler)
            End AddHandler
            RemoveHandler(ByVal value As EventHandler)
                MouseLeaveEvent = DirectCast([Delegate].Remove(MouseLeaveEvent, value), EventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As EventArgs)
                CType(Events("MouseLeaveEvent"), EventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseMove As MouseEventHandler
            AddHandler(ByVal value As MouseEventHandler)
                MouseMoveEvent = DirectCast([Delegate].Combine(MouseMoveEvent, value), MouseEventHandler)
            End AddHandler
            RemoveHandler(ByVal value As MouseEventHandler)
                MouseMoveEvent = DirectCast([Delegate].Remove(MouseMoveEvent, value), MouseEventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As MouseEventArgs)
                CType(Events("MouseMoveEvent"), MouseEventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Public Custom Event MouseUp As MouseEventHandler
            AddHandler(ByVal value As MouseEventHandler)
                MouseUpEvent = DirectCast([Delegate].Combine(MouseUpEvent, value), MouseEventHandler)
            End AddHandler
            RemoveHandler(ByVal value As MouseEventHandler)
                MouseUpEvent = DirectCast([Delegate].Remove(MouseUpEvent, value), MouseEventHandler)
            End RemoveHandler
            RaiseEvent(ByVal sender As Object, ByVal e As MouseEventArgs)
                CType(Events("MouseUpEvent"), MouseEventHandler).Invoke(sender, e)
            End RaiseEvent
        End Event

        Default Public ReadOnly Property Item(ByVal Index As Short) As Line
            Get
                Return DirectCast(BaseGetItem(Index), Line)
            End Get
        End Property

        <EditorBrowsable(EditorBrowsableState.Never)> _
        Private Function IExtenderProvider_CanExtend(ByVal target As Object) As Boolean Implements IExtenderProvider.CanExtend
            If TypeOf target Is Line Then
                Return BaseCanExtend(RuntimeHelpers.GetObjectValue(target))
            End If
            Return False
        End Function

        Public Function GetIndex(ByVal pLine As Line) As Short
            Return BaseGetIndex(pLine)
        End Function

        <EditorBrowsable(EditorBrowsableState.Never)> _
        Public Sub SetIndex(ByVal pLine As Line, ByVal Index As Short)
            BaseSetIndex(pLine, Index, False)
        End Sub

        <EditorBrowsable(EditorBrowsableState.Never)> _
        Public Function ShouldSerializeIndex(ByVal pLine As Line) As Boolean
            Return BaseShouldSerializeIndex(pLine)
        End Function

        <EditorBrowsable(EditorBrowsableState.Never)> _
        Public Sub ResetIndex(ByVal pLine As Line)
            BaseResetIndex(pLine)
        End Sub

        Public Sub New()
        End Sub

        Public Sub New(ByVal Container As IContainer)
            MyBase.New(Container)
        End Sub

        Protected Overrides Sub HookUpControlEvents(ByVal obj As Object)
            Dim pLine As Line = DirectCast(obj, Line)
            If ClickEvent IsNot Nothing Then AddHandler pLine.Click, ClickEvent
            If DoubleClickEvent IsNot Nothing Then AddHandler pLine.DoubleClick, DoubleClickEvent
            If MouseClickEvent IsNot Nothing Then AddHandler pLine.MouseClick, MouseClickEvent
            If MouseDoubleClickEvent IsNot Nothing Then AddHandler pLine.MouseDoubleClick, MouseDoubleClickEvent
            If MouseDownEvent IsNot Nothing Then AddHandler pLine.MouseDown, MouseDownEvent
            If MouseEnterEvent IsNot Nothing Then AddHandler pLine.MouseEnter, MouseEnterEvent
            If MouseHoverEvent IsNot Nothing Then AddHandler pLine.MouseHover, MouseHoverEvent
            If MouseLeaveEvent IsNot Nothing Then AddHandler pLine.MouseLeave, MouseLeaveEvent
            If MouseMoveEvent IsNot Nothing Then AddHandler pLine.MouseMove, MouseMoveEvent
            If MouseUpEvent IsNot Nothing Then AddHandler pLine.MouseUp, MouseUpEvent
        End Sub

        Protected Overrides Function GetControlInstanceType() As Type
            Return GetType(Line)
        End Function

        Public Shadows Function UBound() As Integer
            Return IIf(Count() = 0, 0, MyBase.UBound())
        End Function

        Public Shadows Sub Load(ByVal Index As Short)
            BaseSetIndex(New Line(), Index, True)
        End Sub

        Public Sub Add(ByVal pLine As Line, ByVal index As Short)
            BaseSetIndex(pLine, index, True)
        End Sub

    End Class

End Namespace
